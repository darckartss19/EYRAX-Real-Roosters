# alpha.9 / checkpoint v18

Base: alpha.8 v17 source ZIP, branch eyrax/alpha8-combat-v17,
commit c2f561b9ac36e1a34d45bb63b1183e2de23de9dd.

## Corrections

Pending whistle challenges are cancelled in their saved dimension, including
when the initiating player has moved elsewhere. Lookup only uses loaded
entities and preserves the initiator UUID check. Invalid or unavailable
dimensions are ignored safely; no chunks are force-loaded.

The missing Gradle wrapper JAR is restored from Gradle v9.2.1 and checked
against the official SHA256:
423cb469ccc0ecc31f0e4e1c309976198ccb734cdcbb7029d4bda0f18f57e8d9.
Documentation, version and QA dependency ranges now refer to alpha.9.

## Verification on Windows, 2026-10-18

- Regression reproduced before the fix: 12 combat tests passed, the new
  cross-dimension cancellation test failed with a surviving challenge.
- After the fix: all 13 required Minecraft server GameTests passed.
- Static validators passed: Gecko assets, render budgets, release structure,
  and all 12 visual-polish regression tests.
- Java 21 / Gradle 9.2.1 build passed; final package inspection recorded with
  the delivery artifacts.
- All 33 geometry/animation/texture assets match alpha.8 byte-for-byte.

Local server tests skipped the client asset download and used a local
build/moddev asset reference to the existing cache. This is server-only
verification; it does not validate a rendered client. CI retains the full
asset download, server smoke test and client visual harness.

Not performed here: interactive client rendering, real two-client portal
travel, full modpack compatibility, production installation or release.
OpenCode advisor inference remained unavailable (free-tier access rejected);
no independent OpenCode review is claimed.