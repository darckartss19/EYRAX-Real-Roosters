# EYRAX Real Roosters — 0.3.0-alpha.9

Technical corrections based on alpha.8 / combat checkpoint v17.
Minecraft 1.21.1, NeoForge 21.1.248, Java 21, Gradle 9.2.1.

## Changes

- Cancelling a pending whistle challenge after changing dimension clears the
  request on the rival in the original dimension. Only the initiating player
  can clear that request. No chunks are loaded for this lookup.
- Includes the official Gradle 9.2.1 wrapper JAR, missing from the alpha.8
  source archive, so the included launchers can run.
- Corrects source-package documentation and artifact version labels.

Geometry, animations and textures are preserved byte-for-byte from alpha.8:
43 bones, 152 cubes, six animations, 24 breed/sex/age textures, five overlays
and two item textures. Entity IDs, genetics and Fowl API remain unchanged.

## Build

Install Java 21, then run `./gradlew build` (Windows: `gradlew.bat build`).
Outputs are `build/libs/eyrax_real_roosters-0.3.0-alpha.9.jar` and the separate
`build/libs/eyrax-fowl-api-1.0.0.jar`. Both client and server also need GeckoLib
4.9.2 or a compatible 4.x version for NeoForge / Minecraft 1.21.1.

## Verification

Install Pillow 11.3.0 and matplotlib 3.10.6 for the Python checks:

```sh
python tools/validate_gecko_assets.py
python tools/validate_render_budget.py
python tools/validate_release_structure.py
python tools/validate_visual_polish.py
./gradlew runGameTestServer -Peyrax.combatQa=true --no-configuration-cache
```

GameTests use a disposable development world and a separate QA source set;
QA classes are excluded from distributed JARs. The suite has 13 combat tests,
including cancellation after a dimension change. The optional client visual
harness remains available with `-Peyrax.visualQa=true`.

Do not rerun historical asset generation/migration scripts to build this
release: the checked-in alpha.8 resources are the intended appearance.
See CHECKPOINT_STATUS.md for actual validation results and remaining checks.

## Controls

Use seeds to tame/breed. Right-click an animal with the analyzer for its record.
Use the whistle on adult roosters to change Passive/Defend/Guard Owner.
Sneak + whistle selects your rooster, then a rival; a rival owned by another
player needs that owner's acceptance. Sneak + whistle in the air cancels a
pending selection/request. Sneak + empty hand orders a tamed bird to sit.