# EYRAX Real Roosters — combate alpha.8

Minecraft 1.21.1 / NeoForge 21.1.248 / GeckoLib 4.9.2 / EYRAX Fowl API 1.0.0.

## Controles

1. Domestica dos gallos adultos y ponlos de pie. Agacharse y usar la mano vacía alterna sentado/de pie.
2. Mantén agacharse y usa el silbato en el primer gallo; después, en el rival. La selección caduca a los 30 segundos.
3. Los gallos deben verse, estar en el suelo, libres de otro duelo y a 8 bloques o menos entre sí.
4. Si ambos son tuyos, comienza la preparación. Si el rival pertenece a otro jugador, su dueño acepta agachándose y usando el silbato en su propio gallo. En creativo se pueden controlar ambos como administrador.
5. Durante tres segundos se orientan hacia el rival y muestran una postura de amenaza con aleteo. Después comienza el combate.
6. Usar el silbato en un participante detiene a ambos. Agacharse y usarlo al aire cancela una selección o un reto pendiente.

Fuera del duelo, el uso normal del silbato alterna las posturas originales: Pasivo, Proteger dueño y Defenderse. Defenderse conserva el ordinal 2 que antes aparecía como DUEL.

## Movimiento e impactos

- El picotazo comienza su animación y comprueba el impacto tres ticks después (0,15 s).
- El ataque con salto impulsa físicamente al gallo, abre las alas y adelanta las patas. Comprueba el impacto cinco ticks después (0,25 s). Solo se elige desde el suelo y con espacio superior.
- Ambos usan el daño, los atributos, la armadura y los eventos normales de Minecraft. Tienen recuperación y una pequeña variación de cadencia.
- En el impacto se vuelven a comprobar objetivo, distancia y visibilidad. Cambiar de objetivo, alejarse, sentarse o cancelar puede hacer fallar el ataque.
- El duelo se cancela al retirar un participante, cambiar su dueño, separarlos más de 16 bloques o recibir daño externo. Los estados del duelo y ataques pendientes no se guardan al recargar.

Esta versión cubre inicio, ataques y cancelación. Mantiene la salud normal de Minecraft: no añade protección contra muerte, premios ni una condición de victoria por retirada. Esas reglas siguen pendientes de diseño.

## Referencia de comportamiento

La revisión solicitada se centró en posturas y movimiento de Gallus, antes de terminar la implementación. El etograma de Katajamaa et al. registra amenazas con plumas del cuello levantadas, aleteos, acercamientos, picotazos, saltos y persecuciones:
https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0204303

Favati et al. observaron que numerosos encuentros entre machos se resolvían mediante exhibición y evitación, incluso sin contacto:
https://doi.org/10.1098/rsos.201213

La cuenta atrás, el silbato, la frecuencia de ataques y sus tiempos son decisiones de juego, no parámetros biológicos. Las animaciones adaptan movimientos usando los huesos existentes; no se añadió geometría para plumas erizadas.

## Verificación reproducible

```
python3 tools/validate_gecko_assets.py
python3 tools/validate_render_budget.py
python3 tools/validate_release_structure.py
python3 tools/validate_visual_polish.py
gradle build --no-daemon
gradle runGameTestServer -Peyrax.combatQa=true --no-configuration-cache --no-daemon
```

Las pruebas de combate se cargan exclusivamente con la propiedad combatQa. Comprueban impactos, obstáculos, recuperación, preparación, aceptación por dueño, cancelación, restricciones, retirada de entidades y compatibilidad de posturas guardadas. No forman parte del JAR distribuido.
