package com.eyrax.visualqa;

import com.eyrax.fowlapi.api.FowlBreed;
import com.eyrax.fowlapi.api.FowlSex;
import com.eyrax.fowlapi.api.PlumagePattern;
import com.eyrax.realroosters.client.BreedAnalyzerScreen;
import com.eyrax.realroosters.entity.HeritageChicken;
import com.eyrax.realroosters.entity.CombatStance;
import com.eyrax.realroosters.entity.RoosterCombat;
import com.eyrax.realroosters.registry.ModEntities;
import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.ScreenEvent;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import net.neoforged.neoforge.common.NeoForge;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Runs only in the opt-in visualQa source set, never in a delivered EYRAX JAR. */
@Mod(value = "eyrax_visual_qa", dist = Dist.CLIENT)
public final class AnalyzerVisualQa {
    private static final String[] NAMES = {"00-alpha6-blurred", "01-alpha8-fixed",
            "02-alpha8-compact", "03-alpha8-compact-scrolled"};
    private HeritageChicken specimen;
    private Screen testedScreen;
    private int stage = -1, frames, backgroundPasses, readyTicks;
    private boolean advance, finished;
    private boolean combatPreview, captureFrame;
    private volatile boolean combatReady;
    private int combatTicks, combatFrames;

    public AnalyzerVisualQa() {
        NeoForge.EVENT_BUS.addListener(this::tick);
        NeoForge.EVENT_BUS.addListener(this::beforeRender);
        NeoForge.EVENT_BUS.addListener(this::backgroundRendered);
        NeoForge.EVENT_BUS.addListener(this::afterRender);
        NeoForge.EVENT_BUS.addListener(this::captureCombat);
    }

    private void tick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (finished || mc.level == null || mc.player == null) return;
        if (combatPreview) {
            if (combatReady && ++combatTicks % 3 == 0) captureFrame = true;
            if (combatFrames >= 48) {
                finished = true;
                System.out.println("EYRAX_VISUAL_QA_SUCCESS: analyzer=4 screenshots; combat=48 real Minecraft frames");
                mc.stop();
            }
            return;
        }
        if (stage < 0) {
            if (mc.screen != null || ++readyTicks < 40) return;
            specimen = new HeritageChicken(ModEntities.HERITAGE_CHICKEN.get(), mc.level);
            specimen.setBreed(FowlBreed.LEGHORN);
            specimen.setSex(FowlSex.ROOSTER);
            specimen.setPlumage(PlumagePattern.SOLID);
            specimen.setVitality(67);
            stage = 0;
            open(mc);
        } else if (advance) {
            advance = false;
            stage++;
            if (stage == NAMES.length) {
                startCombatPreview(mc);
            } else if (stage == 3) {
                if (!testedScreen.keyPressed(GLFW.GLFW_KEY_PAGE_DOWN, 0, 0)) {
                    throw new AssertionError("Compact analyzer did not handle Page Down");
                }
                frames = 0;
            } else {
                open(mc);
            }
        }
    }

    private void startCombatPreview(Minecraft mc) {
        combatPreview = true;
        testedScreen = null;
        mc.setScreen(null);
        mc.options.guiScale().set(2);
        mc.resizeDisplay();
        BlockPos center = mc.player.blockPosition().above(6);
        var server = mc.getSingleplayerServer();
        var playerId = mc.player.getUUID();
        server.execute(() -> {
            var player = server.getPlayerList().getPlayer(playerId);
            ServerLevel level = player.serverLevel();
            for (int x = -6; x <= 6; x++) for (int z = -6; z <= 6; z++) {
                for (int y = 0; y <= 6; y++) {
                    level.setBlock(center.offset(x, y, z),
                            (y == 0 ? Blocks.SMOOTH_STONE : Blocks.AIR).defaultBlockState(), 3);
                }
            }
            level.setDayTime(1000);
            level.setWeatherParameters(6000, 0, false, false);
            player.setGameMode(GameType.SPECTATOR);
            player.connection.teleport(center.getX() + .5, center.getY() + 2.4,
                    center.getZ() + 4.5, 180, 18);
            HeritageChicken a = new HeritageChicken(ModEntities.HERITAGE_CHICKEN.get(), level);
            HeritageChicken b = new HeritageChicken(ModEntities.HERITAGE_CHICKEN.get(), level);
            for (HeritageChicken bird : new HeritageChicken[]{a, b}) {
                bird.setSex(FowlSex.ROOSTER);
                bird.setAge(0);
                bird.tame(player);
                bird.setStance(CombatStance.DEFEND);
                bird.setHealth(bird.getMaxHealth());
                bird.setOnGround(true);
            }
            a.setBreed(FowlBreed.CRIOLLO_DOMINICANO);
            b.setBreed(FowlBreed.RHODE_ISLAND_RED);
            a.moveTo(center.getX() - .4, center.getY() + 1, center.getZ() + .5, 270, 0);
            b.moveTo(center.getX() + 1.4, center.getY() + 1, center.getZ() + .5, 90, 0);
            level.addFreshEntity(a); level.addFreshEntity(b);
            if (!RoosterCombat.startDuel(a, b)) throw new AssertionError("Visual duel did not start");
            combatReady = true;
        });
    }

    private void captureCombat(RenderGuiEvent.Post event) {
        if (!combatPreview || !combatReady || !captureFrame || finished) return;
        captureFrame = false;
        Minecraft mc = Minecraft.getInstance();
        Path directory = mc.gameDirectory.toPath().resolve("visual-qa/combat");
        event.getGuiGraphics().flush();
        try (NativeImage image = Screenshot.takeScreenshot(mc.getMainRenderTarget())) {
            Files.createDirectories(directory);
            image.writeToFile(directory.resolve(String.format("frame-%03d.png", combatFrames++)));
        } catch (IOException error) {
            throw new RuntimeException("Cannot record combat preview", error);
        }
    }

    private void open(Minecraft mc) {
        mc.options.guiScale().set(stage < 2 ? 2 : 4);
        mc.resizeDisplay();
        testedScreen = stage == 0 ? new BlurredBaselineScreen(specimen) : new BreedAnalyzerScreen(specimen);
        mc.setScreen(testedScreen);
        frames = 0;
    }

    private void beforeRender(ScreenEvent.Render.Pre event) {
        if (event.getScreen() == testedScreen) backgroundPasses = 0;
    }

    @SuppressWarnings("removal")
    private void backgroundRendered(ScreenEvent.BackgroundRendered event) {
        if (event.getScreen() == testedScreen) backgroundPasses++;
    }

    private void afterRender(ScreenEvent.Render.Post event) {
        if (event.getScreen() != testedScreen || finished || advance || ++frames < 30) return;
        int expected = stage == 0 ? 2 : 1;
        if (backgroundPasses != expected) {
            throw new AssertionError("Stage " + stage + " expected " + expected
                    + " background passes, found " + backgroundPasses);
        }
        Minecraft mc = Minecraft.getInstance();
        Path directory = mc.gameDirectory.toPath().resolve("visual-qa");
        event.getGuiGraphics().flush();
        try (NativeImage image = Screenshot.takeScreenshot(mc.getMainRenderTarget())) {
            Files.createDirectories(directory);
            image.writeToFile(directory.resolve(NAMES[stage] + ".png"));
        } catch (IOException error) {
            throw new RuntimeException("Cannot save visual QA screenshot", error);
        }
        System.out.println("EYRAX_VISUAL_QA_STAGE " + NAMES[stage] + " backgroundPasses=" + backgroundPasses);
        advance = true;
    }
}
