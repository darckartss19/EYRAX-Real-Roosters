"""Reproducible 16x6x16 GameTest scene: stone floor, clear air above it."""
import gzip
import struct
from pathlib import Path

def string(value):
    raw = value.encode('utf-8')
    return struct.pack('>H', len(raw)) + raw

def tag(kind, name, data):
    return bytes([kind]) + string(name) + data

def integer(value):
    return struct.pack('>i', value)

def items(kind, values):
    return bytes([kind]) + integer(len(values)) + b''.join(values)

def ints(values):
    return items(3, [integer(n) for n in values])

palette = [tag(8, 'Name', string(name)) + b'\0' for name in ('minecraft:stone', 'minecraft:air')]
blocks = [tag(9, 'pos', ints((x, y, z))) + tag(3, 'state', integer(0 if y == 0 else 1)) + b'\0'
          for x in range(16) for y in range(6) for z in range(16)]
root = (tag(3, 'DataVersion', integer(3955)) + tag(9, 'size', ints((16, 6, 16)))
        + tag(9, 'palette', items(10, palette)) + tag(9, 'blocks', items(10, blocks))
        + tag(9, 'entities', items(10, [])) + b'\0')
output = Path(__file__).resolve().parent / 'combat-qa/resources/data/eyrax_real_roosters/structure/combat.nbt'
output.parent.mkdir(parents=True, exist_ok=True)
output.write_bytes(gzip.compress(tag(10, '', root), mtime=0))
print(output)
