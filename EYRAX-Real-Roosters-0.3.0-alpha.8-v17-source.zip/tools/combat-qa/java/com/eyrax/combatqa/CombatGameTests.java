package com.eyrax.combatqa;

import com.eyrax.fowlapi.api.FowlSex;
import com.eyrax.realroosters.entity.CombatStance;
import com.eyrax.realroosters.entity.HeritageChicken;
import com.eyrax.realroosters.entity.RoosterCombat;
import com.eyrax.realroosters.item.TrainingWhistleItem;
import com.eyrax.realroosters.registry.ModEntities;
import com.eyrax.realroosters.registry.ModItems;
import com.mojang.authlib.GameProfile;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.common.util.FakePlayerFactory;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

@GameTestHolder("eyrax_real_roosters")
@PrefixGameTestTemplate(false)
public final class CombatGameTests {
    private static TrainingWhistleItem whistle() { return (TrainingWhistleItem) ModItems.TRAINING_WHISTLE.get(); }

    private static Player owner(GameTestHelper h) {
        var player = FakePlayerFactory.get(h.getLevel(), new GameProfile(UUID.randomUUID(), "CombatQa"));
        player.setGameMode(GameType.SURVIVAL);
        BlockPos pos = h.absolutePos(new BlockPos(4, 2, 4));
        player.setPos(pos.getX(), pos.getY(), pos.getZ());
        player.setShiftKeyDown(true);
        h.getLevel().addNewPlayer(player);
        h.assertTrue(h.getLevel().getPlayerByUUID(player.getUUID()) == player,
                "Fixture owner is not registered in the world");
        h.assertTrue(!player.isSpectator() && !player.isCreative() && player.isShiftKeyDown(),
                "Fixture requires a sneaking survival player");
        return player;
    }

    private static HeritageChicken bird(GameTestHelper h, double x, Player owner) {
        HeritageChicken bird = new HeritageChicken(ModEntities.HERITAGE_CHICKEN.get(), h.getLevel());
        // GameTest's anchor includes the structure block; the template floor is at relative Y=1.
        BlockPos origin = h.absolutePos(new BlockPos(0, 2, 4));
        bird.setPos(origin.getX() + x, origin.getY(), origin.getZ() + .5);
        bird.setSex(FowlSex.ROOSTER);
        bird.setAge(0);
        bird.setStance(CombatStance.DEFEND);
        bird.setNoAi(true);
        bird.setOnGround(true);
        if (owner != null) {
            bird.tame(owner);
            h.assertTrue(bird.isOwnedBy(owner), "Fixture cannot resolve the rooster's owner");
        }
        h.assertTrue(h.getLevel().addFreshEntity(bird), "Fixture entity was not added");
        return bird;
    }

    private static String status(HeritageChicken a, HeritageChicken b) {
        return "eligible=" + a.getCombat().isEligible() + ",canFight=" + a.getCombat().canFight()
                + ",target=" + a.getCombat().canAttackTarget(b) + ",reach=" + a.getCombat().inReach(b)
                + ",los=" + a.hasLineOfSight(b) + ",ground=" + a.onGround()
                + ",alive=" + a.isAlive() + ",rooster=" + a.isRooster() + ",baby=" + a.isBaby()
                + ",sit=" + a.isOrderedToSit() + ",block=" + a.level().getBlockState(a.blockPosition());
    }

    private static void queuePeck(GameTestHelper h, HeritageChicken a, HeritageChicken b) {
        a.setTarget(b);
        a.setOnGround(false); // Explicitly choose the grounded peck fallback, not the random hop.
        h.assertTrue(a.doHurtTarget(b), "Attack should be queued: " + status(a, b));
    }

    @GameTest(template = "combat", timeoutTicks = 40)
    public static void impactIsDelayedAndCannotStack(GameTestHelper h) {
        HeritageChicken a = bird(h, 4, null), b = bird(h, 4.8, null);
        float health = b.getHealth();
        queuePeck(h, a, b);
        h.assertTrue(b.getHealth() == health, "Damage occurred before animation wind-up");
        h.assertTrue(!a.doHurtTarget(b), "Two hits were queued in the same tick");
        h.runAfterDelay(2, () -> h.assertTrue(b.getHealth() == health, "Peck landed too early"));
        h.runAfterDelay(8, () -> {
            h.assertTrue(b.getHealth() < health, "Queued peck never landed");
            float afterHit = b.getHealth();
            h.assertTrue(!a.doHurtTarget(b), "Recovery/cooldown allowed an early second hit");
            h.runAfterDelay(5, () -> {
                h.assertTrue(b.getHealth() == afterHit, "One attack caused repeated damage");
                h.succeed();
            });
        });
    }

    @GameTest(template = "combat", timeoutTicks = 40)
    public static void movingAwayCancelsImpact(GameTestHelper h) {
        HeritageChicken a = bird(h, 4, null), b = bird(h, 4.8, null);
        float health = b.getHealth();
        queuePeck(h, a, b);
        b.setPos(b.getX() + 4, b.getY(), b.getZ());
        h.runAfterDelay(8, () -> {
            h.assertTrue(b.getHealth() == health, "Out-of-range attack landed");
            h.assertTrue(!a.getCombat().hasPendingHit(), "Missed attack was not consumed");
            h.succeed();
        });
    }

    @GameTest(template = "combat", timeoutTicks = 40)
    public static void obstacleCancelsImpact(GameTestHelper h) {
        HeritageChicken a = bird(h, 4.99, null), b = bird(h, 5.87, null);
        float health = b.getHealth();
        queuePeck(h, a, b);
        h.setBlock(new BlockPos(5, 2, 4), Blocks.GLASS_PANE);
        h.runAfterDelay(8, () -> {
            h.assertTrue(!a.hasLineOfSight(b), "Fixture did not block visibility");
            h.assertTrue(b.getHealth() == health, "Attack landed through an obstacle");
            h.succeed();
        });
    }

    @GameTest(template = "combat", timeoutTicks = 40)
    public static void sittingCancelsQueuedAttack(GameTestHelper h) {
        HeritageChicken a = bird(h, 4, null), b = bird(h, 4.8, null);
        float health = b.getHealth();
        queuePeck(h, a, b);
        a.setOrderedToSit(true);
        h.runAfterDelay(8, () -> {
            h.assertTrue(b.getHealth() == health, "Sitting bird completed a queued attack");
            h.assertTrue(!a.getCombat().hasPendingHit(), "Sitting left a pending hit");
            h.succeed();
        });
    }

    @GameTest(template = "combat", timeoutTicks = 160)
    public static void whistlePreparesThenAiFights(GameTestHelper h) {
        Player owner = owner(h);
        HeritageChicken a = bird(h, 4, owner), b = bird(h, 6, owner);
        a.setNoAi(false); b.setNoAi(false);
        float healthA = a.getHealth(), healthB = b.getHealth();
        TrainingWhistleItem whistle = whistle();
        whistle.command(owner, a); whistle.command(owner, b);
        h.assertTrue(a.isCombatPreparing() && b.isCombatPreparing(), "Preparation was not synchronized");
        h.assertTrue(!a.doHurtTarget(b), "Attacked during preparation");
        h.runAfterDelay(55, () -> {
            h.assertTrue(a.getHealth() == healthA && b.getHealth() == healthB, "Preparation caused damage");
            h.assertTrue(a.getTarget() == null && b.getTarget() == null, "Target active before countdown finished");
        });
        h.runAfterDelay(105, () -> {
            h.assertTrue(!a.isCombatPreparing() && !b.isCombatPreparing(), "Preparation never ended");
            h.assertTrue(a.getHealth() < healthA || b.getHealth() < healthB, "AI never approached and hit its rival");
            a.getCombat().stopDuel();
            h.assertTrue(a.getStance() == CombatStance.DEFEND && b.getStance() == CombatStance.DEFEND,
                    "Duel overwrote saved stances");
            h.succeed();
        });
    }

    @GameTest(template = "combat", timeoutTicks = 40)
    public static void rivalOwnerMustAcceptAndCanCancel(GameTestHelper h) {
        Player alice = owner(h), bob = owner(h);
        HeritageChicken a = bird(h, 4, alice), b = bird(h, 6, bob);
        TrainingWhistleItem whistle = whistle();
        whistle.command(alice, a); whistle.command(alice, b);
        h.assertTrue(!a.getCombat().isInDuel() && !b.getCombat().isInDuel(), "Started without rival owner's acceptance");
        h.assertTrue(b.getCombat().challenge() != null, "Challenge not recorded");
        whistle.command(bob, b);
        h.assertTrue(a.getCombat().isInDuel() && b.getCombat().isInDuel(), "Acceptance did not pair both birds");
        whistle.command(alice, a);
        h.assertTrue(!a.isCombatPreparing() && !b.isCombatPreparing(), "Cancellation left the preparation pose");
        h.assertTrue(!a.getCombat().isInDuel() && !b.getCombat().isInDuel(), "Cancellation left a rival paired");
        h.assertTrue(a.getOwnerUUID().equals(alice.getUUID()) && b.getOwnerUUID().equals(bob.getUUID()), "Ownership changed");
        h.succeed();
    }

    @GameTest(template = "combat", timeoutTicks = 40)
    public static void cancelledRequestCannotBeAccepted(GameTestHelper h) {
        Player alice = owner(h), bob = owner(h);
        HeritageChicken a = bird(h, 4, alice), b = bird(h, 6, bob), c = bird(h, 8, bob);
        TrainingWhistleItem whistle = whistle();
        whistle.command(alice, a); whistle.command(alice, b); whistle.command(alice, c);
        h.assertTrue(b.getCombat().challenge() != null && c.getCombat().challenge() == null, "Multiple outgoing challenges allowed");
        whistle.use(h.getLevel(), alice, InteractionHand.MAIN_HAND);
        h.assertTrue(b.getCombat().challenge() == null, "Air cancellation left a challenge");
        whistle.command(bob, b);
        h.assertTrue(!a.getCombat().isInDuel() && !b.getCombat().isInDuel(), "Cancelled challenge still started");
        h.succeed();
    }

    @GameTest(template = "combat", timeoutTicks = 40)
    public static void ownershipChangeInvalidatesRequest(GameTestHelper h) {
        Player alice = owner(h), bob = owner(h), eve = owner(h);
        HeritageChicken a = bird(h, 4, alice), b = bird(h, 6, bob);
        TrainingWhistleItem whistle = whistle();
        whistle.command(alice, a); whistle.command(alice, b);
        h.assertTrue(b.getCombat().challenge() != null, "Ownership test requires a live challenge");
        a.tame(eve);
        whistle.command(bob, b);
        h.assertTrue(!a.getCombat().isInDuel() && !b.getCombat().isInDuel(), "Old owner authorized a transferred bird");
        h.assertTrue(b.getCombat().challenge() == null, "Invalid request remained active");
        h.succeed();
    }

    @GameTest(template = "combat", timeoutTicks = 40)
    public static void invalidBirdsAreRejected(GameTestHelper h) {
        Player owner = owner(h);
        HeritageChicken adult = bird(h, 4, owner), other = bird(h, 6, owner);
        other.setSex(FowlSex.HEN);
        h.assertTrue(!RoosterCombat.startDuel(adult, other), "Hen entered a duel");
        other.setSex(FowlSex.ROOSTER); other.setAge(-24000);
        h.assertTrue(!RoosterCombat.startDuel(adult, other), "Chick entered a duel");
        other.setAge(0); other.setOrderedToSit(true);
        h.assertTrue(!RoosterCombat.startDuel(adult, other), "Sitting rooster entered a duel");
        other.setOrderedToSit(false);
        HeritageChicken wild = bird(h, 8, null);
        TrainingWhistleItem whistle = whistle();
        whistle.command(owner, wild); whistle.command(owner, adult);
        h.assertTrue(!wild.getCombat().isInDuel(), "Survival player started a duel with an untamed bird");
        h.succeed();
    }

    @GameTest(template = "combat", timeoutTicks = 40)
    public static void removedRivalCleansBothSides(GameTestHelper h) {
        HeritageChicken a = bird(h, 4, null), b = bird(h, 6, null);
        h.assertTrue(RoosterCombat.startDuel(a, b), "Fixture could not start duel: " + status(a, b));
        b.discard();
        h.runAfterDelay(3, () -> {
            h.assertTrue(!a.getCombat().isInDuel() && !b.getCombat().isInDuel(), "Removed rival left a stale pair");
            h.assertTrue(!a.isCombatPreparing() && a.getTarget() == null, "Removed rival left active animation/target");
            h.succeed();
        });
    }

    @GameTest(template = "combat", timeoutTicks = 40)
    public static void hopHasLaterImpact(GameTestHelper h) {
        HeritageChicken a = bird(h, 4, null), b = bird(h, 4.8, null);
        // NoAI freezes vanilla travel as well as goals; the hop needs real entity physics.
        a.setNoAi(false);
        h.runAfterDelay(4, () -> {
            h.assertTrue(a.onGround(), "Hop fixture has not settled on the floor");
            // Select a deterministic random seed that chooses the hop branch.
            long seed = 0;
            do { a.getRandom().setSeed(seed++); } while (a.getRandom().nextInt(3) != 0);
            a.getRandom().setSeed(seed - 1);
            a.setTarget(b);
            float health = b.getHealth();
            double initialY = a.getY();
            h.assertTrue(a.doHurtTarget(b), "Hop not queued: " + status(a, b));
            h.runAfterDelay(4, () -> {
                h.assertTrue(a.getY() > initialY, "Hop did not move the entity: " + status(a, b)
                        + ",y=" + a.getY() + ",initialY=" + initialY + ",velocity=" + a.getDeltaMovement());
                h.assertTrue(b.getHealth() == health, "Hop damaged before the kicking pose");
            });
            h.runAfterDelay(9, () -> {
                h.assertTrue(b.getHealth() < health, "Hop never impacted");
                h.assertTrue(!a.doHurtTarget(b), "Hop recovery allowed another hit");
                h.succeed();
            });
        });
    }

    @GameTest(template = "combat", timeoutTicks = 40)
    public static void savedDefendOrdinalRemainsCompatible(GameTestHelper h) {
        HeritageChicken a = bird(h, 4, null), restored = bird(h, 6, null);
        HeritageChicken rival = bird(h, 8, null);
        h.assertTrue(RoosterCombat.startDuel(a, rival), "Reload test requires an active duel");
        CompoundTag tag = new CompoundTag();
        a.addAdditionalSaveData(tag);
        restored.readAdditionalSaveData(tag);
        h.assertTrue(CombatStance.DEFEND.ordinal() == 2 && restored.getStance() == CombatStance.DEFEND,
                "Old stance ordinal 2 no longer restores defense");
        h.assertTrue(!restored.getCombat().isInDuel() && !restored.isCombatPreparing(), "Transient duel survived reload");
        a.getCombat().stopDuel();
        h.succeed();
    }
}
