package com.eyrax.combatqa;

import net.neoforged.fml.common.Mod;

@Mod("eyrax_combat_qa")
public final class CombatQaMod {}
