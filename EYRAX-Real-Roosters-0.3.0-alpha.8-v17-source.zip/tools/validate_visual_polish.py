#!/usr/bin/env python3
"""Visual regressions and unchanged non-combat contracts. Combat uses real GameTests."""
import hashlib
import json
import re
import unittest
from pathlib import Path
from PIL import Image
from polish_visual_assets import mirror

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'src/main/resources/assets/eyrax_real_roosters'
JAVA = ROOT / 'src/main/java/com/eyrax/realroosters'


def methods(source):
    result = {}
    pattern = r'(?m)^    (?:public|protected|private)\s+(?:static\s+)?\S+\s+(\w+)\s*\('
    for match in re.finditer(pattern, source):
        start = source.index('{', match.end())
        end, depth = start + 1, 1
        while depth:
            depth += (source[end] == '{') - (source[end] == '}')
            end += 1
        result[match.group(1)] = source[match.start():end]
    return result


class VisualPolishTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.geo = json.loads((ASSETS / 'geo/heritage_chicken.geo.json').read_text())['minecraft:geometry'][0]
        cls.bones = {b['name']: b for b in cls.geo['bones']}
        cls.anim = json.loads((ASSETS / 'animations/heritage_chicken.animation.json').read_text())['animations']
        cls.entity = (JAVA / 'entity/HeritageChicken.java').read_text()
        cls.langs = {locale: json.loads((ASSETS / f'lang/{locale}.json').read_text()) for locale in ('es_es', 'en_us')}

    def test_geometry_budget_counts(self):
        self.assertEqual(43, len(self.bones))
        self.assertEqual(152, sum(len(b.get('cubes', [])) for b in self.bones.values()))

    def test_eyes_follow_head_and_clear_beak(self):
        for name, parent, beaks, cheek_x in (
            ('eyes', 'head', self.bones['beak']['cubes'], 2.6),
            ('chick_eyes', 'chick_head', [self.bones['chick_head']['cubes'][1]], 2.35),
        ):
            with self.subTest(name=name):
                bone = self.bones[name]
                self.assertEqual(parent, bone['parent'])
                self.assertEqual(2, len(bone['cubes']))
                for eye in bone['cubes']:
                    x, y, z = eye['origin']
                    self.assertGreater(y, max(b['origin'][1] + b['size'][1] for b in beaks))
                    self.assertGreater(z, max(b['origin'][2] + b['size'][2] for b in beaks))
                    self.assertGreater(max(abs(x), abs(x + eye['size'][0])), cheek_x)

    def test_bilateral_feet_and_rear_toes(self):
        for left, right in (('leg_left', 'leg_right'), ('chick_leg_left', 'chick_leg_right')):
            self.assertEqual(mirror(self.bones[left]['cubes']), self.bones[right]['cubes'])
            for name in (left, right):
                hallux = self.bones[name]['cubes'][-1]
                self.assertNotIn('rotation', hallux)
                self.assertGreater(hallux['origin'][2], 0)

    def test_eye_uv_and_beak_do_not_overlap(self):
        for name in ('eyes', 'chick_eyes'):
            for eye in self.bones[name]['cubes']:
                for face in eye['uv'].values():
                    self.assertEqual([52, 10], face['uv'])
                    self.assertEqual([4, 4], face['uv_size'])
        for beak in self.bones['beak']['cubes']:
            self.assertEqual(48, beak['uv'][0])

    def test_native_eye_pixels_and_overlay_transparency(self):
        for path in (ASSETS / 'textures/entity').rglob('*.png'):
            with self.subTest(path=path):
                with Image.open(path) as image:
                    self.assertEqual((128, 128), image.size)
                    if path.parent.name == 'overlay':
                        self.assertIsNone(image.crop((104, 20, 112, 28)).getchannel('A').getbbox())
                        self.assertIsNone(image.crop((96, 0, 128, 16)).getchannel('A').getbbox())
                    else:
                        self.assertEqual((10, 11, 13, 255), image.getpixel((107, 24)))
                        self.assertEqual((247, 233, 196, 255), image.getpixel((106, 22)))

    def test_attack_one_shot_channels(self):
        self.assertEqual(6, len(self.anim))
        attack = self.anim['animation.heritage_chicken.attack']
        self.assertIs(attack['loop'], False)
        self.assertEqual(.48, attack['animation_length'])
        for bone in ('head', 'neck', 'wing_left', 'wing_right', 'leg_left', 'leg_right'):
            self.assertIn(bone, attack['bones'])
        for channels in attack['bones'].values():
            for frames in channels.values():
                self.assertEqual(list(frames.values())[0], list(frames.values())[-1])
                self.assertLessEqual(max(map(float, frames)), attack['animation_length'])

    def test_combat_animations_and_damage_bridge(self):
        # The damage call still uses vanilla armor/events; runtime timing is tested in Minecraft.
        self.assertEqual(1, self.entity.count('super.doHurtTarget(target)'))
        register = methods(self.entity)['registerControllers']
        self.assertLess(register.index('"locomotion"'), register.index('"combat"'))
        kick = self.anim['animation.heritage_chicken.kick']
        self.assertIs(kick['loop'], False)
        self.assertTrue(self.anim['animation.heritage_chicken.threat']['loop'])
        for channels in kick['bones'].values():
            for frames in channels.values():
                self.assertEqual(list(frames.values())[0], list(frames.values())[-1])
                self.assertLessEqual(max(map(float, frames)), kick['animation_length'])

    def test_dynamic_names_and_custom_names(self):
        name = methods(self.entity)['getName']
        self.assertIn('if (customName != null) return customName;', name)
        self.assertIn('isBaby() ? "chick" : getSex().serializedName()', name)
        for locale, lang in self.langs.items():
            for stage in ('rooster', 'hen', 'chick'):
                self.assertIn('%1$s', lang['entity.eyrax_real_roosters.named.' + stage])
            self.assertNotIn('ave de raza', '\n'.join(lang.values()).lower())

    def test_localization_completeness(self):
        self.assertEqual(set(self.langs['es_es']), set(self.langs['en_us']))
        keys = ('title breed sex age plumage vitality agility power fertility temperament '
                'specialty stance not_applicable close snapshot sex.rooster sex.hen age.chick age.adult').split()
        for lang in self.langs.values():
            for key in keys:
                self.assertIn('screen.eyrax_real_roosters.analyzer.' + key, lang)

    def test_client_opening_is_local_only(self):
        events = (JAVA / 'client/ClientEvents.java').read_text()
        self.assertIn('value = Dist.CLIENT', events)
        opening = methods(events)['openAnalyzer']
        self.assertLess(opening.index('if (!event.getLevel().isClientSide) return;'), opening.index('Minecraft.getInstance()'))
        self.assertIn('event.getEntity() != minecraft.player', opening)
        self.assertIn('minecraft.screen != null', opening)
        common = (JAVA / 'item/BreedAnalyzerItem.java').read_text()
        self.assertNotIn('net.minecraft.client', common)
        self.assertNotIn('displayClientMessage', common)

    def test_screen_layout_and_snapshot_safety(self):
        screen = (JAVA / 'client/BreedAnalyzerScreen.java').read_text()
        for token in ('enableScissor', 'disableScissor', 'mouseScrolled', 'GLFW_KEY_PAGE_DOWN',
                      'font.split(specialty', 'getNarrationMessage', 'bird.getName().copy()'):
            self.assertIn(token, screen)
        self.assertIn('sex = tr("sex." + bird.getSex().serializedName())', screen)
        self.assertNotRegex(screen, r'private final HeritageChicken')

    def test_noncombat_gameplay_contract_matches_v14(self):
        contract = json.loads((ROOT / 'tools/v14_gameplay_contract.json').read_text())
        # Alpha.8 intentionally replaces these two combat files and six entity methods.
        # All breeding, genetics, API, resource IDs, recipes and derived attributes remain pinned.
        combat_files = {'src/main/java/com/eyrax/realroosters/entity/CombatStance.java',
                        'src/main/java/com/eyrax/realroosters/item/TrainingWhistleItem.java'}
        combat_methods = {'registerGoals', 'defineSynchedData', 'aiStep', 'canFight', 'canGuard', 'setStance'}
        for path, sha in contract['files'].items():
            if path in combat_files:
                continue
            self.assertEqual(sha, hashlib.sha256((ROOT / path).read_bytes()).hexdigest(), path)
        candidate = methods(self.entity)
        for name, sha in contract['methods'].items():
            if name in combat_methods:
                continue
            self.assertEqual(sha, hashlib.sha256(candidate[name].encode()).hexdigest(), name)
        self.assertEqual(set(candidate), set(contract['methods']) | {
            'registerControllers', 'getName', 'doHurtTarget', 'hurt', 'getCombat', 'isCombatPreparing'})


if __name__ == '__main__':
    unittest.main(verbosity=2)
