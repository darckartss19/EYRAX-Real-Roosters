package com.eyrax.realroosters.entity;

import com.eyrax.realroosters.config.RoostersConfig;
import java.util.Objects;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** Server-owned, transient combat state. No duel or unfinished hit survives a reload. */
public final class RoosterCombat {
    public static final int PREPARATION_TICKS = 60;
    public static final int IMPACT_TICKS = 3; // Picotazo peak: 0.16 seconds in the existing animation.
    public static final int RECOVERY_TICKS = 10;
    public static final int KICK_IMPACT_TICKS = 5;
    public static final int KICK_RECOVERY_TICKS = 16;
    public static final int ATTACK_INTERVAL_TICKS = 20;
    public static final double START_DISTANCE_SQR = 64;
    private final HeritageChicken bird;
    @Nullable private HeritageChicken opponent;
    @Nullable private UUID ownerAtStart, rivalOwnerAtStart;
    private long startsAt;
    @Nullable private LivingEntity pendingHit;
    private long impactAt, recoverUntil, nextAttackAt;
    private long jumpAt = -1;
    @Nullable private Challenge challenge;

    public record Challenge(UUID challenger, UUID initiator, @Nullable UUID challengerOwner,
                            @Nullable UUID recipientOwner, long expiresAt) {}

    public RoosterCombat(HeritageChicken bird) { this.bird = bird; }

    private long now() { return bird.level().getGameTime(); }

    public boolean isEligible() {
        return RoostersConfig.ROOSTER_COMBAT.get() && bird.isAlive()
                && bird.isRooster() && !bird.isBaby() && !bird.isOrderedToSit();
    }

    public boolean isInDuel() { return opponent != null; }
    public boolean isPreparing() { return isInDuel() && now() < startsAt; }
    public boolean isRecovering() { return now() < recoverUntil; }
    public boolean hasPendingHit() { return pendingHit != null; }
    @Nullable public HeritageChicken opponent() { return opponent; }

    public boolean canFight() {
        return isEligible() && (isInDuel() ? !isPreparing() : bird.getStance() != CombatStance.PASSIVE);
    }

    public boolean canAttackTarget(@Nullable LivingEntity target) {
        if (!canFight() || target == null || target == bird || !target.isAlive()
                || target.isRemoved() || target.level() != bird.level()) return false;
        if (isInDuel()) return target == opponent;
        if (target instanceof Player player && (player.isCreative() || player.isSpectator())) return false;
        if (target == bird.getOwner() || bird.isAlliedTo(target)) return false;
        if (target instanceof HeritageChicken other && other.getCombat().isInDuel()) return false;
        return !(bird.isTame() && target instanceof TamableAnimal other && other.isTame()
                && Objects.equals(bird.getOwnerUUID(), other.getOwnerUUID()));
    }

    public boolean inReach(LivingEntity target) {
        return bird.getBoundingBox().inflate(0.35D, 0.25D, 0.35D).intersects(target.getBoundingBox());
    }

    public boolean beginAttack(LivingEntity target) {
        if (bird.level().isClientSide || pendingHit != null || now() < nextAttackAt
                || !canAttackTarget(target) || !inReach(target)
                || !bird.hasLineOfSight(target)) return false;
        pendingHit = target;
        // Visual variety, with a short physical hop only where the ceiling permits it.
        boolean kick = bird.onGround() && bird.getRandom().nextInt(3) == 0
                && bird.level().noCollision(bird, bird.getBoundingBox().move(0, 0.6D, 0));
        impactAt = now() + (kick ? KICK_IMPACT_TICKS : IMPACT_TICKS);
        recoverUntil = now() + (kick ? KICK_RECOVERY_TICKS : RECOVERY_TICKS);
        nextAttackAt = now() + (kick ? 28 : ATTACK_INTERVAL_TICKS) + bird.getRandom().nextInt(5);
        jumpAt = kick ? now() + 2 : -1;
        bird.getNavigation().stop();
        bird.triggerAnim("combat", kick ? "kick" : "attack");
        return true;
    }

    public void cancelAttack() { pendingHit = null; jumpAt = -1; }

    public static boolean canStart(HeritageChicken first, HeritageChicken second) {
        return first != second && !first.level().isClientSide && first.level() == second.level()
                && first.getCombat().isEligible() && second.getCombat().isEligible()
                && !first.getCombat().isInDuel() && !second.getCombat().isInDuel()
                && first.onGround() && second.onGround()
                && first.distanceToSqr(second) <= START_DISTANCE_SQR
                && first.hasLineOfSight(second)
                && second.hasLineOfSight(first);
    }

    /** Call only after the whistle has checked control/acceptance for both birds. */
    public static boolean startDuel(HeritageChicken first, HeritageChicken second) {
        if (!canStart(first, second)) return false;
        long start = first.level().getGameTime() + PREPARATION_TICKS;
        first.getCombat().pair(second, start);
        second.getCombat().pair(first, start);
        first.getCombat().notifyOwners(Component.translatable("message.eyrax_real_roosters.duel_preparing",
                first.getName(), second.getName(), PREPARATION_TICKS / 20));
        return true;
    }

    private void pair(HeritageChicken other, long start) {
        opponent = other;
        ownerAtStart = bird.getOwnerUUID();
        rivalOwnerAtStart = other.getOwnerUUID();
        startsAt = start;
        nextAttackAt = start;
        recoverUntil = start;
        challenge = null;
        pendingHit = null;
        jumpAt = -1;
        bird.setCombatPreparing(true);
        bird.setTarget(null);
        bird.setLastHurtByMob(null);
        bird.getNavigation().stop();
    }

    public void requestChallenge(HeritageChicken challenger, Player initiator) {
        challenge = new Challenge(challenger.getUUID(), initiator.getUUID(), challenger.getOwnerUUID(), bird.getOwnerUUID(), now() + 600);
    }

    @Nullable public Challenge challenge() {
        if (challenge != null && now() > challenge.expiresAt()) challenge = null;
        return challenge;
    }

    public void clearChallenge() { challenge = null; }

    public void tick() {
        if (bird.level().isClientSide) return;
        if (opponent != null) {
            if (!isEligible() || !opponent.getCombat().isEligible() || opponent.isRemoved()
                    || opponent.level() != bird.level() || opponent.getCombat().opponent != bird
                    || bird.distanceToSqr(opponent) > 256
                    || !Objects.equals(ownerAtStart, bird.getOwnerUUID())
                    || !Objects.equals(rivalOwnerAtStart, opponent.getOwnerUUID())) {
                stopDuel();
            } else if (isPreparing()) {
                bird.setTarget(null);
                bird.getNavigation().stop();
                bird.getLookControl().setLookAt(opponent, 30, 30);
                long remaining = startsAt - now();
                if (bird.getId() < opponent.getId() && remaining < PREPARATION_TICKS && remaining % 20 == 0) {
                    notifyOwners(Component.translatable("message.eyrax_real_roosters.duel_countdown", remaining / 20));
                }
            } else {
                bird.setCombatPreparing(false);
                bird.setTarget(opponent);
                if (now() == startsAt && bird.getId() < opponent.getId()) {
                    notifyOwners(Component.translatable("message.eyrax_real_roosters.duel_started"));
                }
            }
        }
        if (pendingHit != null && (!canAttackTarget(pendingHit) || bird.getTarget() != pendingHit)) cancelAttack();
        if (pendingHit != null && jumpAt >= 0 && now() >= jumpAt) {
            jumpAt = -1;
            if (bird.onGround() && bird.level().noCollision(bird, bird.getBoundingBox().move(0, 0.6D, 0))) {
                bird.setDeltaMovement(new Vec3(0, 0.28D, 0));
                bird.hasImpulse = true;
            }
        }
        if (pendingHit != null && now() >= impactAt) {
            LivingEntity target = pendingHit;
            pendingHit = null; // Consume before damage events can re-enter this controller.
            if (canAttackTarget(target) && bird.getTarget() == target && inReach(target)
                    && bird.hasLineOfSight(target)) bird.applyCombatHit(target);
        }
        if (!canFight()) cancelAttack();
    }

    public void stopDuel() {
        HeritageChicken other = opponent;
        if (other == null) { cancelAttack(); return; }
        notifyOwners(Component.translatable("message.eyrax_real_roosters.duel_ended"));
        reset();
        if (other.getCombat().opponent == bird) other.getCombat().reset();
    }

    private void reset() {
        opponent = null;
        pendingHit = null;
        jumpAt = -1;
        bird.setCombatPreparing(false);
        challenge = null;
        ownerAtStart = rivalOwnerAtStart = null;
        bird.setTarget(null);
        bird.setLastHurtByMob(null);
        bird.getNavigation().stop();
    }

    private void notifyOwners(Component message) {
        if (!(bird.level() instanceof ServerLevel level)) return;
        Player first = bird.getOwnerUUID() == null ? null : level.getServer().getPlayerList().getPlayer(bird.getOwnerUUID());
        Player second = opponent == null || opponent.getOwnerUUID() == null ? null
                : level.getServer().getPlayerList().getPlayer(opponent.getOwnerUUID());
        if (first != null) first.displayClientMessage(message, true);
        if (second != null && second != first) second.displayClientMessage(message, true);
    }
}
