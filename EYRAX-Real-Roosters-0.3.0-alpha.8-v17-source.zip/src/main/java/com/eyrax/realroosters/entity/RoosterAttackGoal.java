package com.eyrax.realroosters.entity;

import java.util.EnumSet;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;

/** Approach, wind-up, impact and recovery share one server-owned attack controller. */
final class RoosterAttackGoal extends Goal {
    private final HeritageChicken bird;
    private int repathTicks;

    RoosterAttackGoal(HeritageChicken bird) {
        this.bird = bird;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override public boolean canUse() {
        LivingEntity target = bird.getTarget();
        double range = bird.getAttributeValue(Attributes.FOLLOW_RANGE);
        return bird.getCombat().canAttackTarget(target) && bird.distanceToSqr(target) <= range * range;
    }

    @Override public boolean canContinueToUse() { return canUse(); }
    @Override public boolean requiresUpdateEveryTick() { return true; }
    @Override public void start() { repathTicks = 0; }

    @Override public void stop() {
        bird.getNavigation().stop();
        bird.getCombat().cancelAttack();
    }

    @Override public void tick() {
        LivingEntity target = bird.getTarget();
        if (target == null) return;
        bird.getLookControl().setLookAt(target, 30, 30);
        if (bird.getCombat().isRecovering()) {
            bird.getNavigation().stop();
        } else if (bird.getCombat().inReach(target) && bird.getSensing().hasLineOfSight(target)) {
            bird.getNavigation().stop();
            bird.doHurtTarget(target);
        } else if (--repathTicks <= 0) {
            repathTicks = 10;
            bird.getNavigation().moveTo(target, 1.3D);
        }
    }
}
