package com.eyrax.realroosters.item;

import com.eyrax.realroosters.config.RoostersConfig;
import com.eyrax.realroosters.entity.CombatStance;
import com.eyrax.realroosters.entity.HeritageChicken;
import com.eyrax.realroosters.entity.RoosterCombat;
import java.util.List;
import java.util.Objects;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

public class TrainingWhistleItem extends Item {
    private static final String SELECTION = "eyrax_real_roosters_duel_selection";
    private static final String PREFIX = "message.eyrax_real_roosters.";
    public TrainingWhistleItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (target instanceof HeritageChicken chicken) {
            return command(player, chicken);
        }
        return InteractionResult.PASS;
    }

    public InteractionResult command(Player player, HeritageChicken chicken) {
        if (player.isSpectator()) return InteractionResult.PASS;
        if (player.level().isClientSide) return InteractionResult.SUCCESS;
        if (!chicken.isAlive() || chicken.isBaby() || chicken.isHen()) return message(player, "roosters_only");
        if (player.level() != chicken.level() || player.distanceToSqr(chicken) > 64) return InteractionResult.PASS;
        if (chicken.getCombat().isInDuel()) {
            if (!canControl(player, chicken)) return message(player, "not_owner");
            chicken.getCombat().stopDuel();
            cancelSelection(player);
            return message(player, "duel_cancelled");
        }
        if (player.isShiftKeyDown()) return selectForDuel(player, chicken);
        if (chicken.isTame() && !canControl(player, chicken)) return message(player, "not_owner");
        cancelSelection(player);
        CombatStance next = chicken.getStance().next();
        chicken.setStance(next);
        chicken.setOrderedToSit(next == CombatStance.PASSIVE);
        chicken.getNavigation().stop();
        return message(player, "stance_changed", Component.translatable("stance.eyrax_real_roosters." + next.serializedName()));
    }

    private InteractionResult selectForDuel(Player player, HeritageChicken chicken) {
        if (!RoostersConfig.ROOSTER_COMBAT.get()) return message(player, "duel_disabled");
        if (!chicken.isTame() && !player.isCreative()) return message(player, "duel_tame_first");
        if (chicken.isOrderedToSit()) return message(player, "duel_stand_first");
        ServerLevel level = (ServerLevel) player.level();
        RoosterCombat.Challenge challenge = chicken.getCombat().challenge();
        if (challenge != null && canControl(player, chicken)) {
            if (!(level.getEntity(challenge.challenger()) instanceof HeritageChicken first)
                    || !Objects.equals(challenge.challengerOwner(), first.getOwnerUUID())
                    || !Objects.equals(challenge.recipientOwner(), chicken.getOwnerUUID())) {
                chicken.getCombat().clearChallenge();
                return message(player, "duel_request_expired");
            }
            if (!RoosterCombat.startDuel(first, chicken)) return message(player, "duel_not_ready");
            cancelSelection(player);
            Player initiator = level.getServer().getPlayerList().getPlayer(challenge.initiator());
            if (initiator != null) clearMatchingSelection(initiator, first);
            return message(player, "duel_accepted");
        }
        CompoundTag selection = selection(player);
        if (selection == null) {
            if (!canControl(player, chicken)) return message(player, "not_owner");
            CompoundTag data = new CompoundTag();
            data.putUUID("Bird", chicken.getUUID());
            data.putString("Dimension", level.dimension().location().toString());
            data.putLong("Expires", level.getGameTime() + 600);
            player.getPersistentData().put(SELECTION, data);
            return message(player, "duel_selected", chicken.getName());
        }
        if (selection.getUUID("Bird").equals(chicken.getUUID())) {
            cancelSelection(player);
            return message(player, "duel_selection_cleared");
        }
        if (!(level.getEntity(selection.getUUID("Bird")) instanceof HeritageChicken first)
                || !canControl(player, first)) {
            cancelSelection(player);
            return message(player, "duel_request_expired");
        }
        // One outgoing request per player; changing rivals requires cancellation first.
        if (selection.hasUUID("Rival")) {
            return message(player, "duel_outgoing_pending");
        }
        if (!RoosterCombat.canStart(first, chicken)) return message(player, "duel_not_ready");
        if (canControl(player, chicken)) {
            cancelSelection(player);
            RoosterCombat.startDuel(first, chicken);
            return message(player, "duel_pair_ready", first.getName(), chicken.getName());
        }
        if (challenge != null) return message(player, "duel_request_busy");
        chicken.getCombat().requestChallenge(first, player);
        selection.putUUID("Rival", chicken.getUUID());
        if (chicken.getOwner() instanceof Player owner) {
            message(owner, "duel_challenged", player.getName(), chicken.getName());
        }
        return message(player, "duel_waiting_owner", chicken.getName());
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        if (!player.isShiftKeyDown()) return super.use(level, player, hand);
        if (!level.isClientSide) {
            cancelSelection(player);
            message(player, "duel_selection_cleared");
        }
        return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> lines, TooltipFlag flag) {
        for (String key : List.of("whistle_stance", "whistle_duel", "whistle_cancel")) {
            lines.add(Component.translatable("tooltip.eyrax_real_roosters." + key).withStyle(ChatFormatting.GRAY));
        }
    }

    private static boolean canControl(Player player, HeritageChicken bird) {
        return player.isCreative() || bird.isTame() && bird.isOwnedBy(player);
    }

    @Nullable private static CompoundTag selection(Player player) {
        CompoundTag data = player.getPersistentData().getCompound(SELECTION);
        if (!data.hasUUID("Bird") || data.getLong("Expires") < player.level().getGameTime()
                || !data.getString("Dimension").equals(player.level().dimension().location().toString())) {
            cancelSelection(player);
            return null;
        }
        return data;
    }

    private static void clearMatchingSelection(Player player, HeritageChicken first) {
        CompoundTag data = player.getPersistentData().getCompound(SELECTION);
        if (data.hasUUID("Bird") && data.getUUID("Bird").equals(first.getUUID())) cancelSelection(player);
    }

    private static void cancelSelection(Player player) {
        CompoundTag data = player.getPersistentData().getCompound(SELECTION);
        if (data.hasUUID("Rival") && player.level() instanceof ServerLevel level
                && data.getString("Dimension").equals(level.dimension().location().toString())
                && level.getEntity(data.getUUID("Rival")) instanceof HeritageChicken rival) {
            RoosterCombat.Challenge pending = rival.getCombat().challenge();
            if (pending != null && pending.initiator().equals(player.getUUID())) rival.getCombat().clearChallenge();
        }
        player.getPersistentData().remove(SELECTION);
    }

    private static InteractionResult message(Player player, String key, Object... values) {
        player.displayClientMessage(Component.translatable(PREFIX + key, values).withStyle(ChatFormatting.YELLOW), true);
        return InteractionResult.CONSUME;
    }
}
