# EYRAX Real Roosters — 0.3.0-alpha.10

Minecraft 1.21.1 / NeoForge 21.1.248 / Java 21 / Gradle 9.2.1.
Based on alpha.9, with all 33 alpha.8 visual resources preserved byte-for-byte.

## Improvements

- Pending challenges no longer block a new request when their challenger is
  gone or ownership of either rooster has changed. Valid requests retain
  the existing owner-acceptance flow and expiration time.
- Startup logs use the actual mod metadata version instead of a fixed alpha.4.
- Retains alpha.9 cancellation across dimensions and its Gradle wrapper fix.

## Build and tests

Run `./gradlew build`, or `gradlew.bat build` on Windows. Outputs in build/libs:
`eyrax_real_roosters-0.3.0-alpha.10.jar` and `eyrax-fowl-api-1.0.0.jar`.
Both clients and servers require Fowl API 1.0.0 and compatible NeoForge
GeckoLib 4.x (build baseline 4.9.2).

Python checks require Pillow 11.3.0 and matplotlib 3.10.6:

```sh
python tools/validate_gecko_assets.py
python tools/validate_render_budget.py
python tools/validate_release_structure.py
python tools/validate_visual_polish.py
./gradlew runGameTestServer -Peyrax.combatQa=true --no-configuration-cache
```

15 server GameTests cover combat and pending requests. QA source sets are
excluded from the shipped mod. See CHECKPOINT_STATUS.md for validation scope.
Historical asset generators are not part of the build; use the bundled assets.

## Controls

Seeds tame/breed. The analyzer opens the animal record. The whistle changes
adult rooster stance; sneak + whistle selects a rooster and rival, or accepts
an incoming challenge. Sneak + whistle in air cancels an outgoing request.
Sneak + empty hand toggles sitting for an owned bird.