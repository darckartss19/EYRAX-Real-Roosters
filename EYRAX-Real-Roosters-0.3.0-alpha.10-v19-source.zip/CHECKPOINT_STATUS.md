# alpha.10 / checkpoint v19 — 2026-10-22

Base: alpha.9 v18 source, merged into eyrax/alpha8-combat-v17 at fdc40e5.
Scope: release invalid pending challenges and correct startup version logging.
No geometry, animation, texture, genetics, IDs, API or dependency changes.

Local verification on Windows / Java21 / Gradle9.2.1:
- RED: removed/transferred challenger cases fail; 13 existing GameTests pass.
- GREEN: all 15 required GameTests pass after the correction.
- Normal build, asset validator, render budget and release structure pass.
- All 12 static visual/noncombat checks pass. Historical registration hash
  comparison normalizes only the intentional startup-log change.
- Runtime log now reports 0.3.0-alpha.10 from mod metadata.
- Visual assets are compared to alpha.9 during packaging and JAR inspection.

Server-only local tests skip client asset downloads using the existing cache
reference. CI retains full downloads, dedicated server and client visual QA.
CI results are tracked in the PR, separate from this source checkpoint.
Full-modpack multiplayer/manual testing remains pending. No live instance
installation or merge is performed by this change.

OpenCode remains recorded as blocked by its free-tier provider. No new
inference or independent OpenCode review is claimed.