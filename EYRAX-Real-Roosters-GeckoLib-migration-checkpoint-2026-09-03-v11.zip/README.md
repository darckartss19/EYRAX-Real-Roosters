# EYRAX Real Roosters

NeoForge 1.21.1 mod that adds realistic heritage roosters, hens and chicks as a separate breeding and combat system. It does not replace the resource-producing chickens from Modern Chickens.

## Version 0.3.0-alpha.4 — 128px texture-layer test

This release is split into two required files:

- `eyrax-fowl-api-1.0.0.jar`: shared breed, sex, plumage and genetics contracts.
- `eyrax_real_roosters-0.3.0-alpha.4.jar`: entities, gameplay and visual assets.

Both JARs must be installed on the client and server. The main mod intentionally
refuses to load without EYRAX Fowl API.

### Visual changes

- 24 original 128×128 base textures covering eight breeds and all life stages.
- Five reusable transparent genetics layers preserve all six plumage outcomes.
- More realistic layered wings, individual toes and rear toes.
- Curved segmented rooster tail feathers, hackles and saddle streamers.
- Breed-specific combs, earlobes, collars, keel volume, posture and silhouette.
- Clearer visual differences between rooster, hen and chick.
- Smaller, better-proportioned adult heads and more detailed breed silhouettes.
- Silkie facial muffs, rooster tail coverts, heavy-hen cushions and feathered toes.
- Eight color-coded spawn eggs that each guarantee one specific breed.
- Tapered layered wings with four distinct primary-feather lengths.
- A neck mantle that softens the head-to-body transition.
- More pronounced curvature through all three rooster tail segments.
- Independent idle pecking and feather-shaking animations.
- A synchronized rooster challenge pose during combat.
- Native micro-feather marks, edge highlights and higher-resolution breed signatures.
- Correct 2× texture density: physical 128×128 PNGs mapped over Minecraft's
  logical 64×64 model UV space.
- Reduced texture count from 144 to 29 without removing visual combinations.
- Original EYRAX models, UV layouts, palettes and textures; see `ASSET_CREDITS.md`.

### Existing gameplay

- Eight breeds and six inherited plumage patterns.
- Separate male, female and chick presentation.
- Rebuilt articulated model with a dedicated chick mesh.
- Breed-specific proportions, posture, combs, tails and feathering.
- Five-feather rooster tails, three-feather hen tails, feet and visible spurs.
- Brahma shoulders and feathered legs; Silkie crest, fluff and pom tail.
- Five inherited traits: vitality, agility, power, fertility and temperament.
- Adult roosters can defend themselves or guard their owner.
- Hens reproduce and lay ordinary eggs; roosters do not.
- Breed Analyzer and Training Whistle.
- Natural flocks now share one breed instead of spawning as a random mixed collection.
- Natural flocks favor hens while retaining adult roosters.
- Fixed a crash while naturally generating multi-animal flocks and new chunks.
- The analyzer explains the practical specialty of every breed.
- Optional compatibility metadata for Modern Chickens, Critter Armory, Apotheosis and EYRAX Apothic Animals.

## Controls

- Feed seeds to tame and breed heritage chickens.
- Use the analyzer on an animal to inspect its genes.
- Use the whistle on an adult rooster to rotate Passive, Defend and Guard Owner.
- Sneak + empty-hand interaction orders a tamed animal to sit.

Requires Minecraft 1.21.1, NeoForge 21.1.248 or newer, and Java 21.

This alpha focuses on the visual and API foundation. Corn feed, a separate
mating item and the Analyzer screen belong to later phases.

For development validation, run `python3 tools/validate_model_uv.py` before
building. It verifies that constant cuboids remain inside the logical atlas.
