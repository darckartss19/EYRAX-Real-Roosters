# EYRAX Real Roosters — visual migration checkpoint v11

Date: 2026-09-03

## Verified

- The pre-HD Gecko migration compiled cleanly on Java 21 and NeoForge 21.1.248.
- EYRAX Fowl API 1.0.0 builds as an independent JAR/source set.
- EYRAX Real Roosters requires EYRAX Fowl API and GeckoLib 4.9.2.
- Dedicated development server loads all three modules and reaches `Done` on a new world.
- Main JAR contains no duplicated `com.eyrax.fowlapi` classes.
- Gecko geometry validates 40 unique bones, 150 cubes and three animations.
- Entity textures remain 29 shared assets: 24 breed/sex/age bases and five plumage overlays.
- Entity textures are physical 128x128 images using a logical 64x64 Gecko atlas.
- Shared anatomy now separates rooster and hen silhouettes: slimmer common torso,
  tapered neck/head, longer shanks, layered wings, hackles, saddle and hen belly.
- All eight breeds use thin silhouette detail groups instead of duplicate full-body boxes.
- Static QA renderer consumes the actual Gecko geometry and real breed textures.
- Static QA now converts Bedrock Y-up/down authoring coordinates correctly into
  Matplotlib's Z-up view; earlier sideways silhouette reports are obsolete.
- Rooster tails use paired rising/falling segments to form visible sickle arcs.
- Shared wings and flanks include thin layered feather plates.
- Criollo Dominicano no longer carries the obsolete duplicate body shell.
- All 29 textures were regenerated and confirmed as physical 128x128 PNGs.
- Leghorn, Brahma and Ayam Cemani now use sex-specific visual groups where required.
- Brahma uses a low pea comb; the Leghorn hen has a smaller leaning comb.
- Ayam Cemani hens no longer inherit male sickles or spurs.
- Chicks use layered bodies, cheeks, wings and juvenile tails instead of two large boxes.
- Brahma and Silkie chicks have distinct feathered feet/crest geometry.
- Static render budgets are enforced at 70 rooster, 65 hen and 30 chick cubes;
  current maximums are 67, 60 and 27 respectively.
- Silkie and Leghorn replace incompatible generic comb/tail parts at render time.
- Public Gradle repositories are now the default; the restricted localhost mirror is opt-in.
- GitHub Actions provisions Java 21 and Gradle 9.2.1 without relying on the absent wrapper JAR.
- Release validation now protects the stable entity ID, legacy egg, eight breed eggs,
  bilingual names, API separation and required API/GeckoLib metadata.

## Still pending before a public/test release

- Compile the exact HD alpha.4 source and inspect both generated JARs.
- Review and refine all eight breed silhouettes from real in-game captures.
- Correct deprecated NeoForge/GeckoLib calls where practical.
- Client-side visual test: all breeds, sexes, chicks, overlays, animation transitions and spawn eggs.
- Save/reload, breeding and update-from-0.2.1 regression tests.
- Compatibility check with Critter Armory and the target modpack.
- Performance/entity-density tests at 25, 50 and 100 birds.

This checkpoint is source-only and is not a release candidate.
