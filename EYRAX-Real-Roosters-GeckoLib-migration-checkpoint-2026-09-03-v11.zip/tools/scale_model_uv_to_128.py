#!/usr/bin/env python3
"""Deprecated compatibility entry point for the corrected HD UV migration."""

from __future__ import annotations

from configure_hd_texture_uv import main


if __name__ == "__main__":
    main()
