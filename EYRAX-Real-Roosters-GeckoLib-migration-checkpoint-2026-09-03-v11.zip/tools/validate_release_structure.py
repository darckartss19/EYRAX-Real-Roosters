#!/usr/bin/env python3
"""Validate release-critical IDs, dependencies and breed assets."""

from __future__ import annotations

import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "src/main/resources/assets/eyrax_real_roosters"
BREEDS = (
    "criollo_dominicano",
    "rhode_island_red",
    "leghorn",
    "plymouth_rock",
    "brahma",
    "silkie",
    "ayam_cemani",
    "sussex",
)


def require(condition: bool, message: str) -> None:
    if not condition:
        raise SystemExit(message)


def main() -> None:
    properties = (ROOT / "gradle.properties").read_text(encoding="utf-8")
    require("minecraft_version=1.21.1" in properties, "Minecraft version changed")
    require("neo_version=21.1.248" in properties, "NeoForge baseline changed")
    require("fowl_api_version=1.0.0" in properties, "Fowl API version changed")
    require("geckolib_version=4.9.2" in properties, "GeckoLib version changed")

    metadata = (ROOT / "src/main/templates/META-INF/neoforge.mods.toml").read_text(
        encoding="utf-8"
    )
    for dependency in ("eyrax_fowl_api", "geckolib"):
        require(
            re.search(rf'modId="{dependency}"\s+type="required"', metadata) is not None,
            f"Required dependency missing from metadata: {dependency}",
        )

    entity_source = (ROOT / "src/main/java/com/eyrax/realroosters/registry/ModEntities.java").read_text(
        encoding="utf-8"
    )
    require('register("heritage_chicken"' in entity_source, "Stable entity ID changed")

    item_source = (ROOT / "src/main/java/com/eyrax/realroosters/registry/ModItems.java").read_text(
        encoding="utf-8"
    )
    require(
        '"heritage_chicken_spawn_egg"' in item_source,
        "Legacy generic spawn egg ID changed",
    )

    langs = {
        locale: json.loads((ASSETS / f"lang/{locale}.json").read_text(encoding="utf-8"))
        for locale in ("en_us", "es_es")
    }
    for breed in BREEDS:
        model = ASSETS / f"models/item/{breed}_spawn_egg.json"
        require(model.is_file(), f"Spawn egg model missing: {breed}")
        key = f"item.eyrax_real_roosters.{breed}_spawn_egg"
        for locale, translations in langs.items():
            require(key in translations, f"Missing {locale} translation: {key}")
        for life_stage in ("rooster", "hen", "chick"):
            texture = ASSETS / f"textures/entity/{life_stage}/{breed}.png"
            require(texture.is_file(), f"Breed texture missing: {life_stage}/{breed}")

    main_sources = ROOT / "src/main/java"
    require(
        not any((main_sources / "com/eyrax/fowlapi").rglob("*.java")),
        "Fowl API sources leaked into the main source set",
    )

    print(
        "Release structure valid: stable entity ID, legacy egg, 8 breed eggs, "
        "bilingual names, separate API, and required dependencies."
    )


if __name__ == "__main__":
    main()
