#!/usr/bin/env python3
"""Map the Gecko model onto the logical 64x64 atlas used by physical 128x128 textures."""

from __future__ import annotations

import json
from pathlib import Path

PATH = Path(__file__).resolve().parents[1] / "src/main/resources/assets/eyrax_real_roosters/geo/heritage_chicken.geo.json"

UVS: dict[str, list[list[int]]] = {
    "body": [[0, 18], [0, 26], [18, 22], [18, 22], [44, 20], [44, 20], [44, 20], [44, 20]],
    "breast": [[0, 18], [0, 33], [8, 16]],
    "neck": [[0, 6], [8, 16], [8, 16]],
    "head": [[0, 0], [4, 10], [4, 10]],
    "beak": [[18, 0], [18, 4]],
    "wattles": [[38, 0], [38, 0]],
    "wing_left": [[34, 18], [44, 20], [44, 20], [44, 20], [44, 20], [44, 20]],
    "wing_right": [[34, 18], [44, 20], [44, 20], [44, 20], [44, 20], [44, 20]],
    "leg_left": [[0, 38], [6, 38], [6, 38], [6, 38], [10, 40]],
    "leg_right": [[0, 38], [6, 38], [6, 38], [6, 38], [10, 40]],
    "comb_rooster": [[28, 0], [31, 1], [31, 1], [31, 1], [31, 1]],
    "rooster_details": [[8, 16], [8, 16], [8, 16], [18, 22]],
    "tail_rooster": [[24, 38], [24, 38], [24, 38], [24, 38], [40, 38], [40, 38], [24, 38], [24, 38], [24, 38]],
    "criollo_details": [[18, 22], [0, 33], [24, 38], [24, 38], [10, 40], [10, 40]],
    "brahma_details": [[8, 16], [44, 20], [44, 20], [0, 38], [0, 38], [6, 38], [6, 38]],
    "brahma_rooster_details": [[28, 0], [28, 0], [28, 0]],
    "brahma_hen_details": [[28, 0], [28, 0]],
    "silkie_details": [[8, 16], [8, 16], [8, 16], [44, 20], [44, 20], [40, 38], [0, 38], [0, 38]],
    "leghorn_details": [[8, 16]],
    "leghorn_rooster_details": [[28, 0], [31, 1], [31, 1], [31, 1]],
    "leghorn_hen_details": [[28, 0], [31, 1]],
    "ayam_cemani_details": [[8, 16]],
    "ayam_cemani_rooster_details": [[24, 38], [24, 38], [10, 40], [10, 40]],
    "rhode_island_red_details": [[0, 33], [8, 16], [18, 22]],
    "plymouth_rock_details": [[0, 33], [44, 20], [44, 20], [18, 22]],
    "sussex_details": [[8, 16], [0, 33], [18, 22]],
    "brahma_chick_details": [[0, 38], [0, 38], [6, 38], [6, 38]],
    "silkie_chick_details": [[8, 16], [8, 16], [0, 38], [0, 38]],
    "comb_hen": [[28, 0], [31, 1]],
    "hen_details": [[0, 33], [8, 16], [18, 22]],
    "tail_hen": [[40, 38], [40, 38], [40, 38], [40, 38], [40, 38]],
    "chick_body": [[0, 18], [0, 24], [18, 22], [18, 22], [40, 38], [40, 38]],
    "chick_head": [[0, 0], [18, 0], [4, 10], [4, 10], [8, 16]],
    "chick_wing_left": [[34, 18], [44, 20], [44, 20]],
    "chick_wing_right": [[34, 18], [44, 20], [44, 20]],
    "chick_leg_left": [[0, 38], [6, 38], [10, 40]],
    "chick_leg_right": [[0, 38], [6, 38], [10, 40]],
}

MIRRORED = {
    ("head", 2), ("wattles", 1),
    ("body", 6), ("body", 7),
    ("wing_right", 0), ("wing_right", 1), ("wing_right", 2),
    ("wing_right", 3), ("wing_right", 4), ("wing_right", 5),
    ("leg_right", 0), ("leg_right", 1), ("leg_right", 2), ("leg_right", 3), ("leg_right", 4),
    ("tail_rooster", 2), ("tail_rooster", 3), ("tail_rooster", 5), ("tail_rooster", 7),
    ("rooster_details", 2),
    ("criollo_details", 3), ("criollo_details", 5),
    ("brahma_details", 4), ("brahma_details", 6),
    ("brahma_rooster_details", 2), ("brahma_hen_details", 1),
    ("silkie_details", 4), ("silkie_details", 7),
    ("ayam_cemani_rooster_details", 1), ("ayam_cemani_rooster_details", 3),
    ("plymouth_rock_details", 2),
    ("brahma_chick_details", 1), ("brahma_chick_details", 3),
    ("silkie_chick_details", 3),
    ("tail_hen", 1), ("tail_hen", 4),
    ("chick_body", 5), ("chick_head", 3),
    ("chick_wing_right", 0), ("chick_wing_right", 1),
    ("chick_wing_right", 2),
    ("chick_leg_right", 0), ("chick_leg_right", 1), ("chick_leg_right", 2),
}

def main() -> None:
    data = json.loads(PATH.read_text(encoding="utf-8"))
    definition = data["minecraft:geometry"][0]
    definition["description"]["texture_width"] = 64
    definition["description"]["texture_height"] = 64
    seen: set[str] = set()
    for bone in definition["bones"]:
        name = bone["name"]
        cubes = bone.get("cubes", [])
        if name not in UVS:
            if cubes:
                raise SystemExit(f"No HD UV mapping declared for {name!r}")
            continue
        expected = UVS[name]
        if len(cubes) != len(expected):
            raise SystemExit(f"Cube count changed for {name!r}: {len(cubes)} != {len(expected)}")
        seen.add(name)
        for index, (cube, uv) in enumerate(zip(cubes, expected, strict=True)):
            cube["uv"] = uv
            if (name, index) in MIRRORED:
                cube["mirror"] = True
            else:
                cube.pop("mirror", None)
    missing = UVS.keys() - seen
    if missing:
        raise SystemExit(f"Mapped bones missing from geometry: {sorted(missing)}")
    PATH.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Configured {sum(map(len, UVS.values()))} cubes for the logical 64x64 HD atlas.")

if __name__ == "__main__":
    main()
