#!/usr/bin/env python3
"""Configure 128px entity textures over Minecraft's logical 64px UV atlas.

Minecraft normalizes baked model UVs using the LayerDefinition dimensions. Keeping
the logical atlas at 64x64 while supplying 128x128 PNGs yields true 2x texture
density. Declaring both as 128x128 would only sample half-sized UV islands.
"""

from __future__ import annotations

import re
from pathlib import Path


MODEL = Path(__file__).resolve().parents[1] / (
    "src/main/java/com/eyrax/realroosters/client/HeritageChickenModel.java"
)


def main() -> None:
    source = MODEL.read_text(encoding="utf-8")
    if "LayerDefinition.create(mesh, 64, 64)" in source:
        print("HD logical UV layout is already configured")
        return
    if "LayerDefinition.create(mesh, 128, 128)" not in source:
        raise SystemExit("Unexpected model texture size; migration stopped")

    source = re.sub(
        r"texOffs\((\d+),\s*(\d+)\)",
        lambda match: f"texOffs({int(match.group(1)) // 2}, {int(match.group(2)) // 2})",
        source,
    )
    source = source.replace(
        "LayerDefinition.create(mesh, 128, 128)",
        "LayerDefinition.create(mesh, 64, 64)",
    )
    MODEL.write_text(source, encoding="utf-8")
    print("Configured 128px textures over the logical 64px model atlas")


if __name__ == "__main__":
    main()
