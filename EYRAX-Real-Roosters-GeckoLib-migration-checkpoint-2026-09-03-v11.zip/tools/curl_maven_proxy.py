#!/usr/bin/env python3
"""Read-only localhost mirror that delegates external transfers to curl."""

from __future__ import annotations

import argparse
import hashlib
import mimetypes
from pathlib import Path
import tempfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import quote, urlsplit

import requests
from requests.adapters import HTTPAdapter


REMOTE_BASES = {
    "neoforge": "https://maven.neoforged.net/releases/",
    "mojangmeta": "https://maven.neoforged.net/mojang-meta/",
    "central": "https://repo1.maven.org/maven2/",
    "plugins": "https://plugins.gradle.org/m2/",
    "minecraft": "https://libraries.minecraft.net/",
    "geckolib": "https://dl.cloudsmith.io/public/geckolib3/geckolib/maven/",
    "launchermeta": "https://launchermeta.mojang.com/",
    "pistonmeta": "https://piston-meta.mojang.com/",
    "pistondata": "https://piston-data.mojang.com/",
}

JSON_URL_REWRITES = {
    b"https://launchermeta.mojang.com/": b"http://127.0.0.1:18080/launchermeta/",
    b"https://piston-meta.mojang.com/": b"http://127.0.0.1:18080/pistonmeta/",
    b"https://piston-data.mojang.com/": b"http://127.0.0.1:18080/pistondata/",
    b"https://libraries.minecraft.net/": b"http://127.0.0.1:18080/minecraft/",
}

REQUEST_SESSION = requests.Session()
REQUEST_SESSION.mount("https://", HTTPAdapter(pool_connections=32, pool_maxsize=32, max_retries=1))


class MirrorHandler(BaseHTTPRequestHandler):
    server_version = "EYRAXCurlMirror/1.1"

    def do_HEAD(self) -> None:
        self._serve(False)

    def do_GET(self) -> None:
        self._serve(True)

    def _serve(self, send_body: bool) -> None:
        request_path = urlsplit(self.path).path.lstrip("/")
        prefix, separator, relative = request_path.partition("/")
        if not separator or prefix not in REMOTE_BASES or not relative:
            self.send_error(404, "Unknown repository path")
            return
        parts = [part for part in relative.split("/") if part not in ("", ".", "..")]
        if "/".join(parts) != relative:
            self.send_error(400, "Invalid path")
            return

        cache = self.server.cache_root / prefix / Path(*parts)  # type: ignore[attr-defined]
        if not cache.is_file():
            for alternate_prefix in REMOTE_BASES:
                alternate = self.server.cache_root / alternate_prefix / Path(*parts)  # type: ignore[attr-defined]
                if alternate.is_file():
                    cache = alternate
                    break

        checksums = {".sha1": "sha1", ".sha256": "sha256", ".sha512": "sha512", ".md5": "md5"}
        if not cache.is_file():
            for suffix, algorithm in checksums.items():
                if relative.endswith(suffix):
                    source_relative = relative[:-len(suffix)]
                    for alternate_prefix in REMOTE_BASES:
                        source = self.server.cache_root / alternate_prefix / Path(*source_relative.split("/"))  # type: ignore[attr-defined]
                        if source.is_file():
                            with source.open("rb") as handle:
                                digest = hashlib.file_digest(handle, algorithm).hexdigest().encode("ascii")
                            cache.parent.mkdir(parents=True, exist_ok=True)
                            cache.write_bytes(digest)
                            break
                    break

        if not cache.is_file():
            cache.parent.mkdir(parents=True, exist_ok=True)
            with tempfile.NamedTemporaryFile(dir=cache.parent, delete=False) as temporary:
                temporary_path = Path(temporary.name)
            try:
                if relative.startswith(("net/neoforged/", "io/codechicken/", "net/minecraftforge/")):
                    maven_order = ("neoforge", "central", "minecraft")
                elif relative.startswith(("com/mojang/", "net/minecraft/")):
                    maven_order = ("minecraft", "neoforge", "central")
                else:
                    maven_order = ("central", "neoforge", "minecraft")
                fallback = {
                    "minecraft": maven_order,
                    "neoforge": maven_order,
                    "central": maven_order,
                    "plugins": ("plugins",) + tuple(repo for repo in maven_order if repo != "plugins"),
                    "mojangmeta": ("mojangmeta",),
                    "launchermeta": ("launchermeta",),
                    "pistonmeta": ("pistonmeta",),
                    "pistondata": ("pistondata",),
                    "geckolib": ("geckolib",),
                }
                encoded = "/".join(quote(part) for part in parts)
                fetched = False
                for remote_prefix in fallback[prefix]:
                    try:
                        with REQUEST_SESSION.get(
                                REMOTE_BASES[remote_prefix] + encoded,
                                stream=True,
                                timeout=(20, 120)) as response:
                            if response.status_code != 200:
                                continue
                            with temporary_path.open("wb") as destination:
                                for chunk in response.iter_content(1024 * 1024):
                                    if chunk:
                                        destination.write(chunk)
                            fetched = True
                            break
                    except requests.RequestException:
                        continue
                if not fetched:
                    temporary_path.unlink(missing_ok=True)
                    self.send_error(404, "Artifact unavailable")
                    return
                temporary_path.replace(cache)
            finally:
                temporary_path.unlink(missing_ok=True)

        body = None
        if cache.suffix == ".json" and prefix in {"launchermeta", "pistonmeta"}:
            body = cache.read_bytes()
            for public, local in JSON_URL_REWRITES.items():
                body = body.replace(public, local)
        size = len(body) if body is not None else cache.stat().st_size
        self.send_response(200)
        self.send_header("Content-Type", mimetypes.guess_type(cache.name)[0] or "application/octet-stream")
        self.send_header("Content-Length", str(size))
        self.send_header("Cache-Control", "public, max-age=31536000, immutable")
        self.end_headers()
        if send_body:
            if body is not None:
                self.wfile.write(body)
            else:
                with cache.open("rb") as handle:
                    while chunk := handle.read(1024 * 1024):
                        self.wfile.write(chunk)

    def log_message(self, format_string: str, *args: object) -> None:
        print(f"[{self.log_date_time_string()}] {format_string % args}", flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=18080)
    parser.add_argument("--cache", type=Path, required=True)
    args = parser.parse_args()
    args.cache.mkdir(parents=True, exist_ok=True)
    server = ThreadingHTTPServer(("127.0.0.1", args.port), MirrorHandler)
    server.cache_root = args.cache  # type: ignore[attr-defined]
    server.serve_forever()


if __name__ == "__main__":
    main()
