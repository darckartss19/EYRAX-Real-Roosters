#!/usr/bin/env python3
"""Refine the shared Gecko chicken anatomy without touching gameplay data."""

from __future__ import annotations

import json
from pathlib import Path

PATH = Path(__file__).resolve().parents[1] / "src/main/resources/assets/eyrax_real_roosters/geo/heritage_chicken.geo.json"


def cube(origin, size, uv, *, inflate=None, rotation=None, pivot=None, mirror=False):
    value = {"origin": origin, "size": size, "uv": uv}
    if inflate is not None:
        value["inflate"] = inflate
    if rotation is not None:
        value["rotation"] = rotation
    if pivot is not None:
        value["pivot"] = pivot
    if mirror:
        value["mirror"] = True
    return value


COMMON = {
    "body": [
        cube([-4.0, 11.2, -3.8], [8.0, 6.2, 9.2], [0, 18]),
        cube([-3.45, 10.0, -2.7], [6.9, 2.1, 7.8], [0, 26], inflate=.08),
        cube([-3.35, 16.8, -2.4], [6.7, 1.8, 7.3], [18, 22], inflate=.08),
        cube([-3.75, 11.8, 3.8], [7.5, 5.2, 3.1], [18, 22], inflate=.06),
        cube([3.85, 12.0, -2.8], [.35, 2.2, 4.2], [44, 20], rotation=[0, 0, -4], pivot=[4, 13, -1]),
        cube([3.95, 14.0, -1.5], [.3, 2.2, 4.0], [44, 20], rotation=[4, 0, -6], pivot=[4, 15, .5]),
        cube([-4.2, 12.0, -2.8], [.35, 2.2, 4.2], [44, 20], rotation=[0, 0, 4], pivot=[-4, 13, -1], mirror=True),
        cube([-4.25, 14.0, -1.5], [.3, 2.2, 4.0], [44, 20], rotation=[4, 0, 6], pivot=[-4, 15, .5], mirror=True),
    ],
    "breast": [
        cube([-3.55, 11.0, -6.7], [7.1, 6.1, 3.7], [0, 18]),
        cube([-2.85, 15.8, -7.25], [5.7, 1.8, 2.9], [0, 33], inflate=.08),
        cube([-3.05, 12.0, -7.35], [6.1, 4.5, .8], [8, 16], rotation=[-5, 0, 0], pivot=[0, 14, -7]),
    ],
    "neck": [
        cube([-2.75, 7.0, -6.0], [5.5, 5.6, 3.5], [0, 6], rotation=[-8, 0, 0], pivot=[0, 10, -5]),
        cube([-2.35, 3.9, -7.1], [4.7, 5.2, 3.8], [0, 6], rotation=[-4, 0, 0], pivot=[0, 7, -5.5]),
        cube([-2.8, 7.8, -5.9], [5.6, 4.5, .8], [8, 16], rotation=[-10, 0, 0], pivot=[0, 10, -5.5]),
    ],
    "head": [
        cube([-2.3, 1.4, -8.4], [4.6, 4.8, 4.8], [0, 0]),
        cube([-2.6, 2.6, -8.05], [.65, 2.4, 3.2], [4, 10]),
        cube([1.95, 2.6, -8.05], [.65, 2.4, 3.2], [4, 10], mirror=True),
    ],
    "beak": [
        cube([-1.7, 4.4, -10.8], [3.4, 1.45, 2.6], [18, 0]),
        cube([-1.25, 5.72, -10.25], [2.5, .7, 1.9], [18, 4]),
    ],
    "wattles": [
        cube([-1.45, 5.9, -8.95], [1.0, 3.0, .8], [38, 0]),
        cube([.45, 5.9, -8.95], [1.0, 3.0, .8], [38, 0], mirror=True),
    ],
    "wing_left": [
        cube([3.45, 11.4, -2.5], [1.25, 5.8, 7.5], [34, 18]),
        cube([4.15, 12.8, -.6], [.8, 4.0, 5.8], [44, 20], inflate=.08),
        cube([4.25, 14.0, 1.6], [.6, 2.8, 3.8], [44, 20], rotation=[9, 0, -5], pivot=[4.2, 14, 2]),
        cube([4.45, 12.1, 1.0], [.42, 2.0, 5.0], [44, 20], rotation=[12, 0, -7], pivot=[4.4, 13, 2]),
        cube([4.4, 13.5, 2.0], [.4, 1.8, 4.6], [44, 20], rotation=[16, 0, -5], pivot=[4.35, 14.2, 3]),
        cube([4.3, 15.0, 2.7], [.38, 1.5, 4.0], [44, 20], rotation=[20, 0, -3], pivot=[4.3, 15.5, 3.5]),
    ],
    "wing_right": [
        cube([-4.7, 11.4, -2.5], [1.25, 5.8, 7.5], [34, 18], mirror=True),
        cube([-4.95, 12.8, -.6], [.8, 4.0, 5.8], [44, 20], inflate=.08, mirror=True),
        cube([-4.85, 14.0, 1.6], [.6, 2.8, 3.8], [44, 20], rotation=[9, 0, 5], pivot=[-4.2, 14, 2], mirror=True),
        cube([-4.87, 12.1, 1.0], [.42, 2.0, 5.0], [44, 20], rotation=[12, 0, 7], pivot=[-4.4, 13, 2], mirror=True),
        cube([-4.8, 13.5, 2.0], [.4, 1.8, 4.6], [44, 20], rotation=[16, 0, 5], pivot=[-4.35, 14.2, 3], mirror=True),
        cube([-4.68, 15.0, 2.7], [.38, 1.5, 4.0], [44, 20], rotation=[20, 0, 3], pivot=[-4.3, 15.5, 3.5], mirror=True),
    ],
    "leg_left": [
        cube([1.55, 17.2, -.55], [1.15, 5.6, 1.15], [0, 38]),
        cube([1.7, 22.0, -3.1], [.9, .7, 4.2], [6, 38]),
        cube([.8, 22.05, -2.5], [.75, .65, 3.1], [6, 38], rotation=[0, -12, 0], pivot=[1.5, 22.2, -.2]),
        cube([2.75, 22.05, -2.5], [.75, .65, 3.1], [6, 38], rotation=[0, 12, 0], pivot=[2.6, 22.2, -.2]),
        cube([1.72, 22.05, .25], [.85, .65, 2.0], [10, 40], rotation=[0, 180, 0], pivot=[2.2, 22.2, .4]),
    ],
    "leg_right": [
        cube([-2.7, 17.2, -.55], [1.15, 5.6, 1.15], [0, 38], mirror=True),
        cube([-2.6, 22.0, -3.1], [.9, .7, 4.2], [6, 38], mirror=True),
        cube([-1.55, 22.05, -2.5], [.75, .65, 3.1], [6, 38], rotation=[0, 12, 0], pivot=[-1.5, 22.2, -.2], mirror=True),
        cube([-3.5, 22.05, -2.5], [.75, .65, 3.1], [6, 38], rotation=[0, -12, 0], pivot=[-2.6, 22.2, -.2], mirror=True),
        cube([-2.57, 22.05, .25], [.85, .65, 2.0], [10, 40], rotation=[0, 180, 0], pivot=[-2.2, 22.2, .4], mirror=True),
    ],
    "comb_rooster": [
        cube([-.55, -.7, -7.1], [1.1, 3.4, 5.5], [28, 0]),
        cube([-.8, -1.9, -6.5], [1.6, 1.5, 1.3], [31, 1]),
        cube([-.85, -2.5, -5.0], [1.7, 2.1, 1.3], [31, 1]),
        cube([-.85, -2.8, -3.5], [1.7, 2.4, 1.3], [31, 1]),
        cube([-.8, -2.0, -2.0], [1.6, 1.6, 1.2], [31, 1]),
    ],
    "rooster_details": [
        cube([-3.15, 6.8, -6.35], [6.3, 6.8, .65], [8, 16], rotation=[-10, 0, 0], pivot=[0, 10, -5.8]),
        cube([-3.5, 9.1, -4.5], [.7, 6.0, 5.8], [8, 16], rotation=[0, 0, 7], pivot=[-3.1, 12, -2]),
        cube([2.8, 9.1, -4.5], [.7, 6.0, 5.8], [8, 16], rotation=[0, 0, -7], pivot=[3.1, 12, -2], mirror=True),
        cube([-3.1, 10.6, 3.5], [6.2, 5.2, .7], [18, 22], rotation=[14, 0, 0], pivot=[0, 13, 4]),
    ],
    "tail_rooster": [
        # Three paired sickles, each made of a rising and a falling segment.
        cube([-2.7, 6.8, 8.1], [1.15, 6.8, 1.15], [24, 38], rotation=[-22, 0, -8], pivot=[-2.1, 6.8, 8.1]),
        cube([-2.7, 6.8, 8.1], [1.15, 9.2, 1.15], [24, 38], rotation=[22, 0, -10], pivot=[-2.1, 6.8, 8.1]),
        cube([1.55, 6.8, 8.1], [1.15, 6.8, 1.15], [24, 38], rotation=[-22, 0, 8], pivot=[2.1, 6.8, 8.1], mirror=True),
        cube([1.55, 6.8, 8.1], [1.15, 9.2, 1.15], [24, 38], rotation=[22, 0, 10], pivot=[2.1, 6.8, 8.1], mirror=True),
        cube([-.6, 5.5, 8.6], [1.2, 8.0, 1.2], [24, 38], rotation=[-20, 0, 0], pivot=[0, 5.5, 8.6]),
        cube([-.6, 5.5, 8.6], [1.2, 11.0, 1.2], [24, 38], rotation=[24, 0, 0], pivot=[0, 5.5, 8.6]),
        # Broad coverts fill the attachment without hiding the sickle outline.
        cube([-3.4, 8.5, 5.6], [2.7, 6.3, 2.2], [40, 38], rotation=[-18, 0, -12], pivot=[-1.8, 13.0, 6.0]),
        cube([.7, 8.5, 5.6], [2.7, 6.3, 2.2], [40, 38], rotation=[-18, 0, 12], pivot=[1.8, 13.0, 6.0], mirror=True),
        cube([-1.7, 7.5, 6.2], [3.4, 6.0, 2.0], [40, 38], rotation=[-24, 0, 0], pivot=[0, 12.5, 6.2]),
    ],
    "comb_hen": [
        cube([-.5, .6, -6.4], [1.0, 2.2, 4.2], [28, 0]),
        cube([-.6, -.1, -4.8], [1.2, .9, 1.2], [31, 1]),
    ],
    "hen_details": [
        cube([-3.75, 15.5, -3.1], [7.5, 2.6, 8.0], [0, 33], inflate=.08),
        cube([-3.3, 11.6, -6.9], [6.6, 5.4, .65], [8, 16], rotation=[-5, 0, 0], pivot=[0, 14, -6.5]),
        cube([-3.45, 13.2, 4.2], [6.9, 3.8, .8], [18, 22], rotation=[15, 0, 0], pivot=[0, 15, 4.5]),
    ],
    "criollo_details": [
        cube([-3.25, 9.2, -5.9], [6.5, 5.8, .55], [8, 16], rotation=[-11, 0, 0], pivot=[0, 12, -5.4]),
        cube([-3.0, 10.2, 3.7], [6.0, 5.0, .55], [18, 22], rotation=[16, 0, 0], pivot=[0, 13, 4.1]),
        cube([-2.8, 7.8, 6.1], [1.0, 11.2, 1.0], [24, 38], rotation=[33, 0, -14], pivot=[-1.9, 13, 6]),
        cube([1.8, 7.8, 6.1], [1.0, 11.2, 1.0], [24, 38], rotation=[33, 0, 14], pivot=[1.9, 13, 6], mirror=True),
        cube([-2.75, 19.7, .45], [.9, .65, 2.8], [10, 40], rotation=[-27, 0, 0], pivot=[-2.2, 20.2, 1]),
        cube([1.85, 19.7, .45], [.9, .65, 2.8], [10, 40], rotation=[-27, 0, 0], pivot=[2.2, 20.2, 1], mirror=True),
    ],
    "tail_hen": [
        cube([-3.0, 8.0, 5.7], [2.4, 6.0, 2.2], [40, 38], rotation=[-25, 0, -13], pivot=[-1.6, 13, 6]),
        cube([.6, 8.0, 5.7], [2.4, 6.0, 2.2], [40, 38], rotation=[-25, 0, 13], pivot=[1.6, 13, 6], mirror=True),
        cube([-1.6, 6.8, 6.4], [3.2, 6.2, 2.0], [40, 38], rotation=[-30, 0, 0], pivot=[0, 12.5, 6.3]),
        cube([-3.4, 9.2, 5.2], [1.4, 5.2, 1.8], [40, 38], rotation=[-20, 0, -18], pivot=[-2.3, 13, 5.8]),
        cube([2.0, 9.2, 5.2], [1.4, 5.2, 1.8], [40, 38], rotation=[-20, 0, 18], pivot=[2.3, 13, 5.8], mirror=True),
    ],
    "chick_body": [
        cube([-3.35, 15.1, -3.2], [6.7, 4.9, 6.8], [0, 18]),
        cube([-2.85, 14.1, -2.5], [5.7, 1.8, 5.7], [0, 24], inflate=.12),
        cube([-2.9, 19.2, -2.0], [5.8, 1.5, 5.2], [18, 22], inflate=.08),
        cube([-2.9, 15.7, 3.0], [5.8, 3.8, 2.4], [18, 22], inflate=.06),
        cube([-1.8, 14.8, 4.7], [1.1, 3.8, 1.0], [40, 38], rotation=[-22, 0, -12], pivot=[-1.2, 18, 4.5]),
        cube([.7, 14.8, 4.7], [1.1, 3.8, 1.0], [40, 38], rotation=[-22, 0, 12], pivot=[1.2, 18, 4.5], mirror=True),
    ],
    "chick_head": [
        cube([-2.35, 10.7, -6.25], [4.7, 4.6, 4.8], [0, 0]),
        cube([-1.25, 13.0, -8.1], [2.5, 1.15, 1.95], [18, 0]),
        cube([-2.6, 11.8, -5.9], [.65, 2.4, 3.2], [4, 10]),
        cube([1.95, 11.8, -5.9], [.65, 2.4, 3.2], [4, 10], mirror=True),
        cube([-2.1, 14.7, -5.2], [4.2, 1.0, 2.4], [8, 16], inflate=.06),
    ],
    "chick_wing_left": [
        cube([2.9, 15.7, -1.9], [1.0, 3.4, 4.6], [34, 18]),
        cube([3.45, 16.7, -.5], [.65, 2.2, 3.4], [44, 20]),
        cube([3.5, 17.7, .7], [.5, 1.5, 2.7], [44, 20], rotation=[8, 0, -5], pivot=[3.5, 18, 1]),
    ],
    "chick_wing_right": [
        cube([-3.9, 15.7, -1.9], [1.0, 3.4, 4.6], [34, 18], mirror=True),
        cube([-4.1, 16.7, -.5], [.65, 2.2, 3.4], [44, 20], mirror=True),
        cube([-4.0, 17.7, .7], [.5, 1.5, 2.7], [44, 20], rotation=[8, 0, 5], pivot=[-3.5, 18, 1], mirror=True),
    ],
    "chick_leg_left": [
        cube([1.1, 20.0, -.45], [.9, 2.8, .9], [0, 38]),
        cube([1.0, 22.0, -1.7], [1.2, .55, 2.2], [6, 38]),
        cube([1.25, 22.0, .1], [.7, .5, 1.2], [10, 40]),
    ],
    "chick_leg_right": [
        cube([-2.0, 20.0, -.45], [.9, 2.8, .9], [0, 38], mirror=True),
        cube([-2.2, 22.0, -1.7], [1.2, .55, 2.2], [6, 38], mirror=True),
        cube([-1.95, 22.0, .1], [.7, .5, 1.2], [10, 40], mirror=True),
    ],
}


def main() -> None:
    data = json.loads(PATH.read_text(encoding="utf-8"))
    bones = data["minecraft:geometry"][0]["bones"]
    by_name = {bone["name"]: bone for bone in bones}
    missing = set(COMMON) - by_name.keys()
    if missing:
        raise SystemExit(f"Missing common bones: {sorted(missing)}")
    for name, cubes in COMMON.items():
        by_name[name]["cubes"] = cubes
    # Tail curves are authored per cube; a second bone-wide rotation would
    # flatten the arc and shift the attachment away from the rump.
    by_name["tail_rooster"].pop("rotation", None)
    by_name["tail_hen"].pop("rotation", None)
    PATH.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Refined {len(COMMON)} shared bones with {sum(map(len, COMMON.values()))} cubes.")


if __name__ == "__main__":
    main()
