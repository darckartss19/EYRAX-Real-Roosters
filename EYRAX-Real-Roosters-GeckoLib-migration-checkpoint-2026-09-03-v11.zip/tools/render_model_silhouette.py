#!/usr/bin/env python3
"""Render a lightweight three-view QA sheet from constant model cuboids.

This is not a Minecraft renderer. It intentionally ignores textures and animation;
its job is to expose proportion, overlap and silhouette problems before an in-game
test build is produced.
"""

from __future__ import annotations

import argparse
import math
import re
from dataclasses import dataclass
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d.art3d import Poly3DCollection


ROOT = Path(__file__).resolve().parents[1]
MODEL = ROOT / "src/main/java/com/eyrax/realroosters/client/HeritageChickenModel.java"

NUMBER = r"-?\d+(?:\.\d+)?F?"
BOX = re.compile(
    rf"addBox\(\s*(?P<x>{NUMBER})\s*,\s*(?P<y>{NUMBER})\s*,\s*(?P<z>{NUMBER})\s*,\s*"
    rf"(?P<dx>{NUMBER})\s*,\s*(?P<dy>{NUMBER})\s*,\s*(?P<dz>{NUMBER})"
)
POSE = re.compile(
    rf"PartPose\.(?P<kind>offset|offsetAndRotation)\(\s*"
    rf"(?P<x>{NUMBER})\s*,\s*(?P<y>{NUMBER})\s*,\s*(?P<z>{NUMBER})"
    rf"(?:\s*,\s*(?P<rx>{NUMBER})\s*,\s*(?P<ry>{NUMBER})\s*,\s*(?P<rz>{NUMBER}))?\s*\)"
)


@dataclass
class Cuboid:
    part: str
    origin: np.ndarray
    size: np.ndarray
    pose: np.ndarray
    rotation: np.ndarray


def value(token: str | None) -> float:
    return 0.0 if token is None else float(token.removesuffix("F"))


def call_extent(source: str, start: int) -> int:
    opening = source.index("(", start)
    depth = 0
    for index in range(opening, len(source)):
        char = source[index]
        if char == "(":
            depth += 1
        elif char == ")":
            depth -= 1
            if depth == 0:
                return index + 1
    raise ValueError(f"Unclosed model definition at offset {start}")


def parse_root_cuboids() -> list[Cuboid]:
    source = MODEL.read_text(encoding="utf-8")
    marker = re.compile(r'(?:PartDefinition\s+\w+\s*=\s*)?root\.addOrReplaceChild\("([^"]+)"')
    cuboids: list[Cuboid] = []
    for match in marker.finditer(source):
        end = call_extent(source, match.start())
        chunk = source[match.start():end]
        pose_match = POSE.search(chunk)
        if pose_match is None:
            continue
        pose = np.array([value(pose_match.group(axis)) for axis in ("x", "y", "z")])
        rotation = np.array([value(pose_match.group(axis)) for axis in ("rx", "ry", "rz")])
        for box in BOX.finditer(chunk):
            cuboids.append(
                Cuboid(
                    match.group(1),
                    np.array([value(box.group(axis)) for axis in ("x", "y", "z")]),
                    np.array([value(box.group(axis)) for axis in ("dx", "dy", "dz")]),
                    pose,
                    rotation,
                )
            )
    return cuboids


def rotation_matrix(rotation: np.ndarray) -> np.ndarray:
    rx, ry, rz = rotation
    cx, sx = math.cos(rx), math.sin(rx)
    cy, sy = math.cos(ry), math.sin(ry)
    cz, sz = math.cos(rz), math.sin(rz)
    mx = np.array(((1, 0, 0), (0, cx, -sx), (0, sx, cx)))
    my = np.array(((cy, 0, sy), (0, 1, 0), (-sy, 0, cy)))
    mz = np.array(((cz, -sz, 0), (sz, cz, 0), (0, 0, 1)))
    return mz @ my @ mx


def vertices(cuboid: Cuboid, scale: np.ndarray) -> np.ndarray:
    x, y, z = cuboid.origin
    dx, dy, dz = cuboid.size
    points = np.array([
        (x, y, z), (x + dx, y, z), (x + dx, y + dy, z), (x, y + dy, z),
        (x, y, z + dz), (x + dx, y, z + dz),
        (x + dx, y + dy, z + dz), (x, y + dy, z + dz),
    ])
    points *= scale
    return points @ rotation_matrix(cuboid.rotation).T + cuboid.pose


FACES = ((0, 1, 2, 3), (4, 5, 6, 7), (0, 1, 5, 4),
         (2, 3, 7, 6), (1, 2, 6, 5), (0, 3, 7, 4))


COMMON = {
    "saddle", "neck", "neck_mantle", "neck_feather_fringe",
    "head", "right_leg", "left_leg", "right_wing", "left_wing",
    "right_wing_coverts", "left_wing_coverts",
}
ROOSTER = {"rooster_body_contour", "rooster_breast_contour", "rooster_feather_skirt",
           "rooster_hackle", "saddle_streamers", "rooster_tail_coverts", "right_spur", "left_spur"}
HEN = {"hen_body_contour", "hen_belly_contour", "hen_feather_skirt", "hen_cushion"}
CHICK = {"chick_down_fluff", "chick_head", "chick_right_wing",
         "chick_left_wing", "chick_right_leg", "chick_left_leg", "chick_tail"}


def part_scale(part: str, profile: str) -> np.ndarray:
    if profile == "athletic" and any(word in part for word in ("body", "breast", "skirt")):
        return np.array((0.94, 1.04, 1.10))
    if profile == "robust" and any(word in part for word in ("body", "breast", "skirt")):
        return np.array((1.12, 1.10, 1.08))
    if profile == "giant" and any(word in part for word in ("body", "breast", "skirt")):
        return np.array((1.22, 1.18, 1.14))
    if profile == "silkie" and any(word in part for word in ("body", "breast", "skirt")):
        return np.array((1.14, 1.12, 1.10))
    return np.ones(3)


def render(sex: str, profile: str, output: Path) -> None:
    selected = CHICK if sex == "chick" else COMMON | (ROOSTER if sex == "rooster" else HEN)
    cuboids = [cube for cube in parse_root_cuboids() if cube.part in selected]
    colors = {
        "core": "#98512d", "contour": "#c8783d", "feather": "#d89a55",
        "head": "#b85f35", "leg": "#d6a53c", "wing": "#74402d",
    }

    figure = plt.figure(figsize=(13, 4.8), facecolor="#16191d")
    views = ((15, -55, "Perspective"), (0, -90, "Side"), (0, 0, "Front"))
    all_points: list[np.ndarray] = []
    prepared: list[tuple[Cuboid, np.ndarray]] = []
    for cube in cuboids:
        points = vertices(cube, part_scale(cube.part, profile))
        prepared.append((cube, points))
        all_points.append(points)
    cloud = np.concatenate(all_points) if all_points else np.zeros((1, 3))

    for index, (elevation, azimuth, title) in enumerate(views, 1):
        axis = figure.add_subplot(1, 3, index, projection="3d")
        axis.set_facecolor("#16191d")
        for cube, points in prepared:
            kind = "core"
            if "contour" in cube.part: kind = "contour"
            elif "feather" in cube.part or "fluff" in cube.part: kind = "feather"
            elif "head" in cube.part or "neck" in cube.part: kind = "head"
            elif "leg" in cube.part or "spur" in cube.part: kind = "leg"
            elif "wing" in cube.part: kind = "wing"
            faces = [[points[i] for i in face] for face in FACES]
            axis.add_collection3d(Poly3DCollection(
                faces, facecolor=colors[kind], edgecolor="#24170f", linewidth=0.35, alpha=0.80
            ))
        center = (cloud.min(axis=0) + cloud.max(axis=0)) / 2
        radius = max(np.ptp(cloud, axis=0)) * 0.58
        axis.set_xlim(center[0] - radius, center[0] + radius)
        axis.set_ylim(center[1] - radius, center[1] + radius)
        axis.set_zlim(center[2] - radius, center[2] + radius)
        axis.view_init(elev=elevation, azim=azimuth)
        axis.invert_zaxis()
        axis.set_axis_off()
        axis.set_title(title, color="white", pad=4)
    figure.suptitle(f"EYRAX silhouette QA — {sex} / {profile}", color="white", fontsize=14)
    figure.tight_layout()
    figure.savefig(output, dpi=180, facecolor=figure.get_facecolor())
    plt.close(figure)
    print(output)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sex", choices=("rooster", "hen", "chick"), default="rooster")
    parser.add_argument("--profile", choices=("athletic", "robust", "giant", "silkie"), default="athletic")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    render(args.sex, args.profile, args.output)


if __name__ == "__main__":
    main()
