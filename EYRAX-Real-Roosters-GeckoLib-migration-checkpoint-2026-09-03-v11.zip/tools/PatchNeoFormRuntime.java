import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.LdcInsnNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.jar.JarEntry;
import java.util.jar.JarInputStream;
import java.util.jar.JarOutputStream;

/** Build-sandbox compatibility patch for NFRT 2.0.24. */
public final class PatchNeoFormRuntime {
    private static final String ENGINE = "net/neoforged/neoform/runtime/engine/NeoFormEngine.class";
    private static final String TOOL = "net/neoforged/neoform/runtime/actions/ExternalJavaToolAction.class";

    public static void main(String[] args) throws Exception {
        if (args.length != 2) throw new IllegalArgumentException("Usage: PatchNeoFormRuntime <jar> <java>");
        Path jar = Path.of(args[0]);
        Path patched = Files.createTempFile(jar.getParent(), "nfrt-patched-", ".jar");
        int replacements = 0;
        try (InputStream fileIn = Files.newInputStream(jar); JarInputStream input = new JarInputStream(fileIn);
             OutputStream fileOut = Files.newOutputStream(patched);
             JarOutputStream output = new JarOutputStream(fileOut, input.getManifest())) {
            JarEntry entry;
            while ((entry = input.getNextJarEntry()) != null) {
                if ("META-INF/MANIFEST.MF".equals(entry.getName())) continue;
                byte[] bytes = input.readAllBytes();
                if (ENGINE.equals(entry.getName())) {
                    PatchResult result = patch(bytes, args[1], "<init>");
                    bytes = result.bytes(); replacements += result.count();
                } else if (TOOL.equals(entry.getName())) {
                    PatchResult result = patch(bytes, args[1], "run");
                    bytes = result.bytes(); replacements += result.count();
                }
                JarEntry replacement = new JarEntry(entry.getName());
                replacement.setTime(entry.getTime()); output.putNextEntry(replacement);
                output.write(bytes); output.closeEntry();
            }
        }
        if (replacements == 0) {
            Files.deleteIfExists(patched);
            throw new IllegalStateException("No Optional.orElseThrow ProcessHandle call found");
        }
        Files.move(patched, jar, StandardCopyOption.REPLACE_EXISTING);
        System.out.println("Patched " + jar);
    }

    private static PatchResult patch(byte[] original, String javaExecutable, String methodName) {
        ClassNode node = new ClassNode(); new ClassReader(original).accept(node, 0);
        int count = 0;
        for (MethodNode method : node.methods) {
            if (!methodName.equals(method.name)) continue;
            for (AbstractInsnNode instruction : method.instructions.toArray()) {
                if (instruction instanceof MethodInsnNode call
                        && "java/util/Optional".equals(call.owner)
                        && "orElseThrow".equals(call.name)
                        && "()Ljava/lang/Object;".equals(call.desc)) {
                    method.instructions.insertBefore(call, new LdcInsnNode(javaExecutable));
                    call.name = "orElse"; call.desc = "(Ljava/lang/Object;)Ljava/lang/Object;"; count++;
                }
            }
        }
        ClassWriter writer = new ClassWriter(ClassWriter.COMPUTE_MAXS); node.accept(writer);
        return new PatchResult(writer.toByteArray(), count);
    }

    private record PatchResult(byte[] bytes, int count) {}
}
