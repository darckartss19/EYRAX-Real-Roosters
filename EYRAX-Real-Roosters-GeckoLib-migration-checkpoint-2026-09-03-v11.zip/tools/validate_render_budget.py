#!/usr/bin/env python3
"""Enforce the per-entity static cube budget for the Gecko visual rebuild."""

from __future__ import annotations

import json
from pathlib import Path

from render_static_breed_preview import BREEDS, visible

ROOT = Path(__file__).resolve().parents[1]
GEO = ROOT / "src/main/resources/assets/eyrax_real_roosters/geo/heritage_chicken.geo.json"

LIMITS = {"rooster": 70, "hen": 65, "chick": 30}


def main() -> None:
    bones = json.loads(GEO.read_text(encoding="utf-8"))["minecraft:geometry"][0]["bones"]
    maximums = {sex: 0 for sex in LIMITS}
    failures: list[str] = []
    for breed in BREEDS:
        for sex, limit in LIMITS.items():
            count = sum(
                len(bone.get("cubes", []))
                for bone in bones
                if visible(bone["name"], breed, sex)
            )
            maximums[sex] = max(maximums[sex], count)
            if count > limit:
                failures.append(f"{breed}/{sex}: {count} > {limit}")
    if failures:
        raise SystemExit("Render budget exceeded: " + ", ".join(failures))
    print(
        "Render budget valid: "
        + ", ".join(f"{sex} max {maximums[sex]}/{LIMITS[sex]}" for sex in LIMITS)
    )


if __name__ == "__main__":
    main()
