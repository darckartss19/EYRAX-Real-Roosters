#!/usr/bin/env python3
"""Check constant cuboid UV islands against the logical model atlas."""

from __future__ import annotations

import re
from pathlib import Path


MODEL = Path(__file__).resolve().parents[1] / (
    "src/main/java/com/eyrax/realroosters/client/HeritageChickenModel.java"
)
TOKEN = re.compile(
    r"texOffs\((?P<u>\d+),\s*(?P<v>\d+)\)"
    r"|addBox\(\s*(?:-?\d+(?:\.\d+)?F?\s*,\s*){3}"
    r"(?P<dx>\d+(?:\.\d+)?F?)\s*,\s*"
    r"(?P<dy>\d+(?:\.\d+)?F?)\s*,\s*"
    r"(?P<dz>\d+(?:\.\d+)?F?)",
    re.DOTALL,
)


def number(value: str) -> float:
    return float(value.removesuffix("F"))


def main() -> None:
    source = MODEL.read_text(encoding="utf-8")
    atlas_match = re.search(r"LayerDefinition\.create\(mesh,\s*(\d+),\s*(\d+)\)", source)
    if atlas_match is None:
        raise SystemExit("Could not find LayerDefinition atlas dimensions")
    atlas_width, atlas_height = map(int, atlas_match.groups())

    u = v = 0
    checked = 0
    failures: list[str] = []
    for token in TOKEN.finditer(source):
        if token.group("u") is not None:
            u, v = int(token.group("u")), int(token.group("v"))
            continue
        dx, dy, dz = (number(token.group(name)) for name in ("dx", "dy", "dz"))
        # CubeListBuilder's unfolded cuboid uses 2*depth + 2*width by depth + height.
        max_u = u + 2 * dz + 2 * dx
        max_v = v + dz + dy
        checked += 1
        if max_u > atlas_width + 1e-5 or max_v > atlas_height + 1e-5:
            line = source.count("\n", 0, token.start()) + 1
            failures.append(
                f"line {line}: UV ({u},{v}) + box ({dx},{dy},{dz}) reaches "
                f"({max_u:.2f},{max_v:.2f}) outside {atlas_width}x{atlas_height}"
            )

    if failures:
        raise SystemExit("\n".join(failures))
    print(f"Validated {checked} constant cuboids inside {atlas_width}x{atlas_height} logical UV space")


if __name__ == "__main__":
    main()
