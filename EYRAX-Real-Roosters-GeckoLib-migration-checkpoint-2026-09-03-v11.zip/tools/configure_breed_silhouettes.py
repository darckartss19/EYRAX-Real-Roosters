#!/usr/bin/env python3
"""Install the seven non-Criollo adult breed silhouette detail groups."""

from __future__ import annotations

import json
from pathlib import Path

PATH = Path(__file__).resolve().parents[1] / "src/main/resources/assets/eyrax_real_roosters/geo/heritage_chicken.geo.json"


def cube(origin, size, uv, *, inflate=None, rotation=None, pivot=None, mirror=False):
    value = {"origin": origin, "size": size, "uv": uv}
    if inflate is not None:
        value["inflate"] = inflate
    if rotation is not None:
        value["rotation"] = rotation
    if pivot is not None:
        value["pivot"] = pivot
    if mirror:
        value["mirror"] = True
    return value


DETAILS = {
    "brahma_details": [
        # Heavy hackles and feathered shanks define Brahma without wrapping the torso in a second box.
        cube([-3.3, 7.0, -6.2], [6.6, 5.8, 1.0], [8, 16], rotation=[-9, 0, 0], pivot=[0, 10, -5.5]),
        cube([-3.8, 9.0, -4.8], [1.1, 6.0, 6.4], [44, 20], rotation=[0, 0, 8], pivot=[-3.2, 12, -1]),
        cube([2.7, 9.0, -4.8], [1.1, 6.0, 6.4], [44, 20], rotation=[0, 0, -8], pivot=[3.2, 12, -1], mirror=True),
        cube([.7, 17.5, -1.3], [2.7, 5.3, 2.6], [0, 38], inflate=.12),
        cube([-3.4, 17.5, -1.3], [2.7, 5.3, 2.6], [0, 38], inflate=.12, mirror=True),
        cube([.2, 21.2, -2.8], [3.8, 1.4, 4.6], [6, 38], inflate=.08),
        cube([-4.0, 21.2, -2.8], [3.8, 1.4, 4.6], [6, 38], inflate=.08, mirror=True),
    ],
    "brahma_rooster_details": [
        # Low triple-ridged pea comb, characteristic of Brahma males.
        cube([-1.35, .15, -6.9], [.7, 1.25, 3.9], [28, 0], rotation=[0, 0, -5], pivot=[0, 1, -5]),
        cube([-.35, -.15, -7.0], [.7, 1.45, 4.1], [28, 0]),
        cube([.65, .15, -6.9], [.7, 1.25, 3.9], [28, 0], rotation=[0, 0, 5], pivot=[0, 1, -5], mirror=True),
    ],
    "brahma_hen_details": [
        cube([-.85, .65, -6.6], [.55, .75, 3.1], [28, 0], rotation=[0, 0, -4], pivot=[0, 1, -5]),
        cube([.3, .65, -6.6], [.55, .75, 3.1], [28, 0], rotation=[0, 0, 4], pivot=[0, 1, -5], mirror=True),
    ],
    "silkie_details": [
        # Crest, beard, soft flank tufts and compact pom-pom tail.
        cube([-3.0, -.8, -7.1], [6.0, 2.0, 4.4], [8, 16], inflate=.24),
        cube([-2.0, -1.8, -6.3], [4.0, 1.5, 3.0], [8, 16], inflate=.2),
        cube([-3.2, 5.7, -9.0], [6.4, 3.8, 2.0], [8, 16], inflate=.22),
        cube([-4.9, 11.0, -2.8], [1.2, 6.8, 7.5], [44, 20], inflate=.18),
        cube([3.7, 11.0, -2.8], [1.2, 6.8, 7.5], [44, 20], inflate=.18, mirror=True),
        cube([-3.2, 8.2, 5.0], [6.4, 5.8, 4.0], [40, 38], inflate=.28, rotation=[25, 0, 0], pivot=[0, 12, 6]),
        cube([.75, 18.0, -1.2], [2.5, 4.8, 2.4], [0, 38], inflate=.2),
        cube([-3.25, 18.0, -1.2], [2.5, 4.8, 2.4], [0, 38], inflate=.2, mirror=True),
    ],
    "leghorn_details": [
        # Thin neck feather line shared by both sexes.
        cube([-3.0, 7.0, -6.1], [6.0, 5.8, .8], [8, 16], rotation=[-8, 0, 0], pivot=[0, 10, -5.5]),
    ],
    "leghorn_rooster_details": [
        # Tall upright leaf comb.
        cube([-0.8, -1.4, -7.1], [1.6, 4.5, 6.2], [28, 0]),
        cube([-0.95, -2.7, -6.4], [1.9, 1.7, 1.5], [31, 1]),
        cube([-0.95, -3.0, -4.4], [1.9, 2.0, 1.5], [31, 1]),
        cube([-0.95, -2.5, -2.4], [1.9, 1.5, 1.5], [31, 1]),
    ],
    "leghorn_hen_details": [
        # Smaller comb leaning to one side.
        cube([-.55, -.05, -6.8], [1.1, 2.5, 4.5], [28, 0], rotation=[0, 0, 9], pivot=[0, 1.5, -5]),
        cube([-.65, -.75, -5.8], [1.3, 1.15, 1.4], [31, 1], rotation=[0, 0, 12], pivot=[0, .5, -5]),
    ],
    "ayam_cemani_details": [
        # Subtle neck sheen shared by both sexes.
        cube([-2.9, 7.0, -6.15], [5.8, 5.6, .65], [8, 16], rotation=[-9, 0, 0], pivot=[0, 10, -5.6]),
    ],
    "ayam_cemani_rooster_details": [
        # Long glossy sickles and small rear spurs emphasize its upright gamefowl silhouette.
        cube([-2.6, 6.4, 6.0], [1.25, 12.5, 1.3], [24, 38], rotation=[34, 0, -12], pivot=[-1.8, 13, 6]),
        cube([1.35, 6.4, 6.0], [1.25, 12.5, 1.3], [24, 38], rotation=[34, 0, 12], pivot=[1.8, 13, 6], mirror=True),
        cube([-2.8, 20.0, 0.5], [1.0, 0.8, 2.7], [10, 40], rotation=[-26, 0, 0], pivot=[-2.2, 20.4, 1]),
        cube([1.8, 20.0, 0.5], [1.0, 0.8, 2.7], [10, 40], rotation=[-26, 0, 0], pivot=[2.2, 20.4, 1], mirror=True),
    ],
    "rhode_island_red_details": [
        cube([-4.45, 15.4, -3.4], [8.9, 2.0, 8.8], [0, 33], inflate=.08),
        cube([-3.4, 11.0, -7.25], [6.8, 5.8, .9], [8, 16], rotation=[-7, 0, 0], pivot=[0, 14, -6.8]),
        cube([-3.8, 14.0, 4.4], [7.6, 3.2, 2.2], [18, 22], rotation=[12, 0, 0], pivot=[0, 15, 5]),
    ],
    "plymouth_rock_details": [
        cube([-4.65, 15.0, -3.2], [9.3, 2.5, 8.8], [0, 33], inflate=.12),
        cube([4.55, 11.8, -2.2], [1.0, 6.2, 7.8], [44, 20], inflate=.12),
        cube([-5.55, 11.8, -2.2], [1.0, 6.2, 7.8], [44, 20], inflate=.12, mirror=True),
        cube([-3.6, 13.7, 4.2], [7.2, 3.4, 2.3], [18, 22], rotation=[13, 0, 0], pivot=[0, 15, 5]),
    ],
    "sussex_details": [
        cube([-3.45, 6.3, -6.2], [6.9, 6.2, .9], [8, 16], rotation=[-9, 0, 0], pivot=[0, 10, -5.7]),
        cube([-4.45, 15.0, -3.4], [8.9, 2.3, 8.8], [0, 33], inflate=.08),
        cube([-3.7, 13.7, 4.2], [7.4, 3.4, 2.4], [18, 22], rotation=[13, 0, 0], pivot=[0, 15, 5]),
    ],
    "brahma_chick_details": [
        cube([.55, 19.3, -1.0], [2.15, 3.3, 2.1], [0, 38], inflate=.14),
        cube([-2.7, 19.3, -1.0], [2.15, 3.3, 2.1], [0, 38], inflate=.14, mirror=True),
        cube([.15, 21.2, -2.2], [3.0, 1.0, 3.8], [6, 38], inflate=.08),
        cube([-3.15, 21.2, -2.2], [3.0, 1.0, 3.8], [6, 38], inflate=.08, mirror=True),
    ],
    "silkie_chick_details": [
        cube([-2.6, 9.7, -5.9], [5.2, 1.3, 4.1], [8, 16], inflate=.2),
        cube([-1.65, 8.8, -5.4], [3.3, 1.2, 2.8], [8, 16], inflate=.16),
        cube([.55, 19.5, -.9], [2.0, 3.0, 1.9], [0, 38], inflate=.16),
        cube([-2.55, 19.5, -.9], [2.0, 3.0, 1.9], [0, 38], inflate=.16, mirror=True),
    ],
}


def main() -> None:
    data = json.loads(PATH.read_text(encoding="utf-8"))
    bones = data["minecraft:geometry"][0]["bones"]
    names = set(DETAILS)
    bones[:] = [bone for bone in bones if bone["name"] not in names]
    adult_additions = [
        {
            "name": name,
            "parent": "adult",
            "pivot": [0, 13, 0],
            "cubes": cubes,
        }
        for name, cubes in DETAILS.items()
        if not name.endswith("_chick_details")
    ]
    chick_additions = [
        {"name": name, "parent": "chick", "pivot": [0, 18, 0], "cubes": cubes}
        for name, cubes in DETAILS.items()
        if name.endswith("_chick_details")
    ]
    insert_at = next(i for i, bone in enumerate(bones) if bone["name"] == "hen_details")
    bones[insert_at:insert_at] = adult_additions
    bones.extend(chick_additions)
    PATH.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Installed {len(adult_additions) + len(chick_additions)} breed groups "
          f"with {sum(map(len, DETAILS.values()))} detail cubes.")


if __name__ == "__main__":
    main()
