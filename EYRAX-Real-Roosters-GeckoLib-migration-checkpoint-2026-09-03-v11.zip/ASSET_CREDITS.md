# Asset credits

All entity models, UV layouts, textures, palettes and item artwork included in
EYRAX Real Roosters are original EYRAX assets created specifically for this
project. No model, texture or animation has been copied or derived from another
Minecraft mod, marketplace pack or third-party game.

The breed names refer to real-world poultry breeds and do not imply ownership
of third-party photographs or visual assets. Reference material is used only
for general anatomical traits such as body proportion, comb type, feathered
legs and typical plumage colors.

Minecraft and NeoForge belong to their respective owners. Their APIs and
runtime are not redistributed as original EYRAX artwork.
