package com.eyrax.realroosters.registry;

import com.eyrax.fowlapi.api.FowlBreed;
import com.eyrax.realroosters.EyraxRealRoosters;
import com.eyrax.realroosters.item.BreedAnalyzerItem;
import com.eyrax.realroosters.item.TrainingWhistleItem;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.component.CustomData;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(EyraxRealRoosters.MOD_ID);

    public static final DeferredItem<Item> BREED_ANALYZER = ITEMS.register(
            "breed_analyzer", () -> new BreedAnalyzerItem(new Item.Properties().stacksTo(1)));

    public static final DeferredItem<Item> TRAINING_WHISTLE = ITEMS.register(
            "training_whistle", () -> new TrainingWhistleItem(new Item.Properties().stacksTo(1)));

    public static final DeferredItem<DeferredSpawnEggItem> HERITAGE_CHICKEN_SPAWN_EGG = ITEMS.register(
            "heritage_chicken_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.HERITAGE_CHICKEN, 0x8A3E22, 0xD9B45B, new Item.Properties()));

    public static final DeferredItem<DeferredSpawnEggItem> CRIOLLO_DOMINICANO_SPAWN_EGG = breedEgg(
            FowlBreed.CRIOLLO_DOMINICANO, 0x8C3F24, 0xE2B34F);
    public static final DeferredItem<DeferredSpawnEggItem> RHODE_ISLAND_RED_SPAWN_EGG = breedEgg(
            FowlBreed.RHODE_ISLAND_RED, 0x7A2018, 0xD86B32);
    public static final DeferredItem<DeferredSpawnEggItem> LEGHORN_SPAWN_EGG = breedEgg(
            FowlBreed.LEGHORN, 0xF2EEE0, 0xD6B83F);
    public static final DeferredItem<DeferredSpawnEggItem> PLYMOUTH_ROCK_SPAWN_EGG = breedEgg(
            FowlBreed.PLYMOUTH_ROCK, 0x3D4148, 0xD7D9D5);
    public static final DeferredItem<DeferredSpawnEggItem> BRAHMA_SPAWN_EGG = breedEgg(
            FowlBreed.BRAHMA, 0xC5AA82, 0x3F352F);
    public static final DeferredItem<DeferredSpawnEggItem> SILKIE_SPAWN_EGG = breedEgg(
            FowlBreed.SILKIE, 0xE6E2D7, 0x65778A);
    public static final DeferredItem<DeferredSpawnEggItem> AYAM_CEMANI_SPAWN_EGG = breedEgg(
            FowlBreed.AYAM_CEMANI, 0x101317, 0x394B48);
    public static final DeferredItem<DeferredSpawnEggItem> SUSSEX_SPAWN_EGG = breedEgg(
            FowlBreed.SUSSEX, 0xE8DFCC, 0x3A302C);

    private static DeferredItem<DeferredSpawnEggItem> breedEgg(FowlBreed breed, int shell, int spots) {
        CompoundTag entityData = new CompoundTag();
        entityData.putInt("Breed", breed.ordinal());
        Item.Properties properties = new Item.Properties()
                .component(DataComponents.ENTITY_DATA, CustomData.of(entityData));
        return ITEMS.register(breed.serializedName() + "_spawn_egg",
                () -> new DeferredSpawnEggItem(ModEntities.HERITAGE_CHICKEN, shell, spots, properties));
    }

    private ModItems() {}
}
