package com.eyrax.realroosters.client;

import com.eyrax.realroosters.entity.HeritageChicken;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public final class HeritageChickenGeoRenderer extends GeoEntityRenderer<HeritageChicken> {
    public HeritageChickenGeoRenderer(EntityRendererProvider.Context context) {
        super(context, new HeritageChickenGeoModel());
        this.shadowRadius = 0.40F;
        addRenderLayer(new HeritagePlumageGeoLayer(this));
    }
}
