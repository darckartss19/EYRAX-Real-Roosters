package com.eyrax.realroosters.client;

import com.eyrax.fowlapi.api.FowlBreed;
import com.eyrax.realroosters.EyraxRealRoosters;
import com.eyrax.realroosters.entity.HeritageChicken;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.animation.AnimationState;
import software.bernie.geckolib.cache.object.GeoBone;
import software.bernie.geckolib.model.GeoModel;

/** GeckoLib model bridge. Geometry stays shared while breed, sex and age select visible silhouettes. */
public final class HeritageChickenGeoModel extends GeoModel<HeritageChicken> {
    private static final ResourceLocation MODEL = id("geo/heritage_chicken.geo.json");
    private static final ResourceLocation ANIMATIONS = id("animations/heritage_chicken.animation.json");

    @Override
    public ResourceLocation getModelResource(HeritageChicken chicken) {
        return MODEL;
    }

    @Override
    public ResourceLocation getTextureResource(HeritageChicken chicken) {
        String age = chicken.isBaby() ? "chick" : chicken.getSex().serializedName();
        return id("textures/entity/" + age + "/" + chicken.getBreed().serializedName() + ".png");
    }

    @Override
    public ResourceLocation getAnimationResource(HeritageChicken chicken) {
        return ANIMATIONS;
    }

    @Override
    public void setCustomAnimations(HeritageChicken chicken, long instanceId,
                                    AnimationState<HeritageChicken> state) {
        super.setCustomAnimations(chicken, instanceId, state);

        boolean chick = chicken.isBaby();
        boolean rooster = chicken.isRooster();
        FowlBreed breed = chicken.getBreed();
        boolean silkie = breed == FowlBreed.SILKIE;
        boolean leghorn = breed == FowlBreed.LEGHORN;
        setHidden("adult", chick);
        setHidden("chick", !chick);
        setHidden("rooster_details", chick || !rooster);
        setHidden("hen_details", chick || rooster);
        boolean brahma = breed == FowlBreed.BRAHMA;
        setHidden("comb_rooster", chick || !rooster || silkie || leghorn || brahma);
        setHidden("comb_hen", chick || rooster || silkie || leghorn || brahma);
        setHidden("tail_rooster", chick || !rooster || silkie);
        setHidden("tail_hen", chick || rooster || silkie);
        setHidden("wattles", chick || silkie);
        setHidden("criollo_details", chick || !rooster || breed != FowlBreed.CRIOLLO_DOMINICANO);
        setHidden("brahma_details", chick || breed != FowlBreed.BRAHMA);
        setHidden("brahma_rooster_details", chick || !rooster || breed != FowlBreed.BRAHMA);
        setHidden("brahma_hen_details", chick || rooster || breed != FowlBreed.BRAHMA);
        setHidden("silkie_details", chick || breed != FowlBreed.SILKIE);
        setHidden("leghorn_details", chick || breed != FowlBreed.LEGHORN);
        setHidden("leghorn_rooster_details", chick || !rooster || breed != FowlBreed.LEGHORN);
        setHidden("leghorn_hen_details", chick || rooster || breed != FowlBreed.LEGHORN);
        setHidden("ayam_cemani_details", chick || breed != FowlBreed.AYAM_CEMANI);
        setHidden("ayam_cemani_rooster_details", chick || !rooster || breed != FowlBreed.AYAM_CEMANI);
        setHidden("rhode_island_red_details", chick || breed != FowlBreed.RHODE_ISLAND_RED);
        setHidden("plymouth_rock_details", chick || breed != FowlBreed.PLYMOUTH_ROCK);
        setHidden("sussex_details", chick || breed != FowlBreed.SUSSEX);
        setHidden("brahma_chick_details", !chick || breed != FowlBreed.BRAHMA);
        setHidden("silkie_chick_details", !chick || breed != FowlBreed.SILKIE);

        // Breed proportions are deliberately subtle; unique geometry will be introduced one archetype at a time.
        float width = 1.0F;
        float height = 1.0F;
        float length = 1.0F;
        switch (breed) {
            case CRIOLLO_DOMINICANO -> { width = 0.98F; height = 1.06F; length = 0.98F; }
            case RHODE_ISLAND_RED -> { width = 1.08F; height = 0.99F; length = 1.06F; }
            case LEGHORN -> { width = 0.91F; height = 1.08F; length = 0.93F; }
            case PLYMOUTH_ROCK -> { width = 1.09F; height = 0.98F; length = 1.07F; }
            case BRAHMA -> { width = 1.18F; height = 1.13F; length = 1.17F; }
            case SILKIE -> { width = 0.96F; height = 0.91F; length = 0.99F; }
            case AYAM_CEMANI -> { width = 0.95F; height = 1.06F; length = 0.95F; }
            case SUSSEX -> { width = 1.06F; height = 1.00F; length = 1.05F; }
        }

        GeoBone root = getAnimationProcessor().getBone("root");
        if (root != null) {
            float babyScale = chick ? 0.72F : 1.0F;
            root.setScaleX(width * babyScale);
            root.setScaleY(height * babyScale);
            root.setScaleZ(length * babyScale);
        }
    }

    private void setHidden(String name, boolean hidden) {
        GeoBone bone = getAnimationProcessor().getBone(name);
        if (bone != null) {
            bone.setHidden(hidden);
            bone.setChildrenHidden(hidden);
        }
    }

    private static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(EyraxRealRoosters.MOD_ID, path);
    }
}
