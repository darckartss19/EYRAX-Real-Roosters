package com.eyrax.realroosters.client;

import com.eyrax.fowlapi.api.FowlBreed;
import com.eyrax.realroosters.entity.HeritageChicken;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

/** Articulated heritage-fowl model with sex, age and breed-specific silhouettes. */
public final class HeritageChickenModel extends EntityModel<HeritageChicken> {
    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart breast;
    private final ModelPart saddle;
    private final ModelPart roosterBodyContour;
    private final ModelPart roosterBreastContour;
    private final ModelPart roosterFeatherSkirt;
    private final ModelPart henBodyContour;
    private final ModelPart henBellyContour;
    private final ModelPart henFeatherSkirt;
    private final ModelPart neck;
    private final ModelPart neckMantle;
    private final ModelPart neckFeatherFringe;
    private final ModelPart head;
    private final ModelPart faceFeathers;
    private final ModelPart rightLeg;
    private final ModelPart leftLeg;
    private final ModelPart rightWing;
    private final ModelPart leftWing;
    private final ModelPart rightWingCoverts;
    private final ModelPart leftWingCoverts;
    private final ModelPart largeComb;
    private final ModelPart smallComb;
    private final ModelPart peaComb;
    private final ModelPart wattles;
    private final ModelPart leghornComb;
    private final ModelPart walnutComb;
    private final ModelPart whiteEarlobes;
    private final ModelPart silkieCrest;
    private final ModelPart silkieFaceMuffs;
    private final ModelPart silkieBodyFluff;
    private final ModelPart brahmaShoulders;
    private final ModelPart gamefowlCape;
    private final ModelPart heavyKeel;
    private final ModelPart sussexCollar;
    private final ModelPart roosterHackle;
    private final ModelPart saddleStreamers;
    private final ModelPart roosterTailCoverts;
    private final ModelPart henCushion;
    private final ModelPart rightSpur;
    private final ModelPart leftSpur;
    private final ModelPart rightLegFeathers;
    private final ModelPart leftLegFeathers;
    private final ModelPart rightToeFeathers;
    private final ModelPart leftToeFeathers;

    private final ModelPart roosterTailCenter;
    private final ModelPart roosterTailLeft;
    private final ModelPart roosterTailRight;
    private final ModelPart roosterTailOuterLeft;
    private final ModelPart roosterTailOuterRight;
    private final ModelPart henTailCenter;
    private final ModelPart henTailLeft;
    private final ModelPart henTailRight;
    private final ModelPart silkieTail;

    private final ModelPart chickBody;
    private final ModelPart chickDownFluff;
    private final ModelPart chickHead;
    private final ModelPart chickRightWing;
    private final ModelPart chickLeftWing;
    private final ModelPart chickRightLeg;
    private final ModelPart chickLeftLeg;
    private final ModelPart chickTail;

    public HeritageChickenModel(ModelPart root) {
        this.root = root;
        body = root.getChild("body");
        breast = root.getChild("breast");
        saddle = root.getChild("saddle");
        roosterBodyContour = root.getChild("rooster_body_contour");
        roosterBreastContour = root.getChild("rooster_breast_contour");
        roosterFeatherSkirt = root.getChild("rooster_feather_skirt");
        henBodyContour = root.getChild("hen_body_contour");
        henBellyContour = root.getChild("hen_belly_contour");
        henFeatherSkirt = root.getChild("hen_feather_skirt");
        neck = root.getChild("neck");
        neckMantle = root.getChild("neck_mantle");
        neckFeatherFringe = root.getChild("neck_feather_fringe");
        head = root.getChild("head");
        faceFeathers = head.getChild("face_feathers");
        rightLeg = root.getChild("right_leg");
        leftLeg = root.getChild("left_leg");
        rightWing = root.getChild("right_wing");
        leftWing = root.getChild("left_wing");
        rightWingCoverts = root.getChild("right_wing_coverts");
        leftWingCoverts = root.getChild("left_wing_coverts");
        largeComb = head.getChild("large_comb");
        smallComb = head.getChild("small_comb");
        peaComb = head.getChild("pea_comb");
        wattles = head.getChild("wattles");
        leghornComb = head.getChild("leghorn_comb");
        walnutComb = head.getChild("walnut_comb");
        whiteEarlobes = head.getChild("white_earlobes");
        silkieCrest = head.getChild("silkie_crest");
        silkieFaceMuffs = head.getChild("silkie_face_muffs");
        silkieBodyFluff = root.getChild("silkie_body_fluff");
        brahmaShoulders = root.getChild("brahma_shoulders");
        gamefowlCape = root.getChild("gamefowl_cape");
        heavyKeel = root.getChild("heavy_keel");
        sussexCollar = root.getChild("sussex_collar");
        roosterHackle = root.getChild("rooster_hackle");
        saddleStreamers = root.getChild("saddle_streamers");
        roosterTailCoverts = root.getChild("rooster_tail_coverts");
        henCushion = root.getChild("hen_cushion");
        rightSpur = root.getChild("right_spur");
        leftSpur = root.getChild("left_spur");
        rightLegFeathers = root.getChild("right_leg_feathers");
        leftLegFeathers = root.getChild("left_leg_feathers");
        rightToeFeathers = root.getChild("right_toe_feathers");
        leftToeFeathers = root.getChild("left_toe_feathers");
        roosterTailCenter = root.getChild("rooster_tail_center");
        roosterTailLeft = root.getChild("rooster_tail_left");
        roosterTailRight = root.getChild("rooster_tail_right");
        roosterTailOuterLeft = root.getChild("rooster_tail_outer_left");
        roosterTailOuterRight = root.getChild("rooster_tail_outer_right");
        henTailCenter = root.getChild("hen_tail_center");
        henTailLeft = root.getChild("hen_tail_left");
        henTailRight = root.getChild("hen_tail_right");
        silkieTail = root.getChild("silkie_tail");
        chickBody = root.getChild("chick_body");
        chickDownFluff = root.getChild("chick_down_fluff");
        chickHead = root.getChild("chick_head");
        chickRightWing = root.getChild("chick_right_wing");
        chickLeftWing = root.getChild("chick_left_wing");
        chickRightLeg = root.getChild("chick_right_leg");
        chickLeftLeg = root.getChild("chick_left_leg");
        chickTail = root.getChild("chick_tail");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 18)
                        .addBox(-2.90F, -3.25F, -3.75F, 5.8F, 6.5F, 7.5F, new CubeDeformation(0.12F)),
                PartPose.offsetAndRotation(0.0F, 15.2F, 0.4F, 1.34F, 0.0F, 0.0F));
        root.addOrReplaceChild("breast", CubeListBuilder.create().texOffs(0, 18)
                        .addBox(-2.78F, -2.65F, -2.45F, 5.56F, 5.30F, 4.90F, new CubeDeformation(0.18F)),
                PartPose.offsetAndRotation(0.0F, 15.3F, -2.55F, 1.14F, 0.0F, 0.0F));
        root.addOrReplaceChild("saddle", CubeListBuilder.create().texOffs(18, 22)
                        .addBox(-2.68F, -2.35F, -2.55F, 5.36F, 4.70F, 5.10F, new CubeDeformation(0.11F)),
                PartPose.offsetAndRotation(0.0F, 14.7F, 2.75F, 1.43F, 0.0F, 0.0F));

        // Roosters carry a high, angular breast and a tapered rear. These shells are
        // deliberately built from overlapping feather rows instead of one large cube.
        root.addOrReplaceChild("rooster_body_contour", CubeListBuilder.create().texOffs(0, 26)
                        .addBox(-3.32F, -3.15F, -3.95F, 6.64F, 5.35F, 7.90F, new CubeDeformation(0.14F))
                        .texOffs(15, 28).addBox(-3.02F, 1.35F, -3.50F, 6.04F, 1.55F, 6.85F,
                                new CubeDeformation(0.13F)),
                PartPose.offsetAndRotation(0.0F, 14.85F, 0.55F, 1.34F, 0.0F, 0.0F));
        root.addOrReplaceChild("rooster_breast_contour", CubeListBuilder.create().texOffs(0, 33)
                        .addBox(-3.18F, -3.0F, -2.65F, 6.36F, 5.55F, 5.3F, new CubeDeformation(0.22F))
                        .texOffs(14, 33).addBox(-2.78F, 1.75F, -2.28F, 5.56F, 1.40F, 4.56F,
                                new CubeDeformation(0.14F)),
                PartPose.offsetAndRotation(0.0F, 15.0F, -2.62F, 1.10F, 0.0F, 0.0F));
        root.addOrReplaceChild("rooster_feather_skirt", CubeListBuilder.create().texOffs(28, 31)
                        .addBox(-3.05F, -0.45F, -3.10F, 1.75F, 2.15F, 2.60F, new CubeDeformation(0.08F))
                        .addBox(-1.18F, -0.38F, -3.28F, 2.36F, 2.42F, 2.72F, new CubeDeformation(0.10F))
                        .addBox(1.30F, -0.45F, -3.10F, 1.75F, 2.15F, 2.60F, new CubeDeformation(0.08F))
                        .texOffs(36, 31).addBox(-2.65F, -0.15F, -0.72F, 2.20F, 2.08F, 2.65F,
                                new CubeDeformation(0.07F))
                        .addBox(0.45F, -0.15F, -0.72F, 2.20F, 2.08F, 2.65F,
                                new CubeDeformation(0.07F)),
                PartPose.offsetAndRotation(0.0F, 17.45F, 0.15F, 1.30F, 0.0F, 0.0F));

        // Hens have a lower, broader body with a rounded laying abdomen and cushion.
        root.addOrReplaceChild("hen_body_contour", CubeListBuilder.create().texOffs(0, 26)
                        .addBox(-3.56F, -3.08F, -4.05F, 7.12F, 5.75F, 8.10F, new CubeDeformation(0.19F))
                        .texOffs(16, 27).addBox(-3.22F, 1.82F, -3.52F, 6.44F, 1.58F, 7.04F,
                                new CubeDeformation(0.17F)),
                PartPose.offsetAndRotation(0.0F, 15.38F, 0.65F, 1.39F, 0.0F, 0.0F));
        root.addOrReplaceChild("hen_belly_contour", CubeListBuilder.create().texOffs(0, 33)
                        .addBox(-3.52F, -2.75F, -2.88F, 7.04F, 5.90F, 5.76F, new CubeDeformation(0.27F))
                        .texOffs(15, 34).addBox(-3.08F, 2.20F, -2.35F, 6.16F, 1.40F, 4.70F,
                                new CubeDeformation(0.18F)),
                PartPose.offsetAndRotation(0.0F, 15.65F, -2.35F, 1.17F, 0.0F, 0.0F));
        root.addOrReplaceChild("hen_feather_skirt", CubeListBuilder.create().texOffs(28, 31)
                        .addBox(-3.32F, -0.35F, -3.20F, 2.02F, 2.10F, 2.72F, new CubeDeformation(0.10F))
                        .addBox(-1.18F, -0.30F, -3.35F, 2.36F, 2.35F, 2.82F, new CubeDeformation(0.12F))
                        .addBox(1.30F, -0.35F, -3.20F, 2.02F, 2.10F, 2.72F, new CubeDeformation(0.10F))
                        .texOffs(36, 31).addBox(-2.90F, -0.08F, -0.72F, 2.35F, 2.00F, 2.75F,
                                new CubeDeformation(0.09F))
                        .addBox(0.55F, -0.08F, -0.72F, 2.35F, 2.00F, 2.75F,
                                new CubeDeformation(0.09F)),
                PartPose.offsetAndRotation(0.0F, 18.0F, 0.12F, 1.34F, 0.0F, 0.0F));
        root.addOrReplaceChild("neck", CubeListBuilder.create().texOffs(0, 6)
                        .addBox(-2.35F, -3.2F, -2.25F, 4.7F, 6.4F, 4.5F, new CubeDeformation(0.10F)),
                PartPose.offsetAndRotation(0.0F, 12.0F, -3.1F, -0.20F, 0.0F, 0.0F));
        root.addOrReplaceChild("neck_mantle", CubeListBuilder.create().texOffs(0, 6)
                        .addBox(-2.75F, -1.8F, -2.6F, 5.5F, 3.9F, 5.2F, new CubeDeformation(0.14F))
                        .texOffs(18, 22).addBox(-3.05F, 1.25F, -2.25F, 6.1F, 1.7F, 4.5F,
                                new CubeDeformation(0.10F)),
                PartPose.offsetAndRotation(0.0F, 12.9F, -2.7F, 0.58F, 0.0F, 0.0F));
        root.addOrReplaceChild("neck_feather_fringe", CubeListBuilder.create().texOffs(8, 16)
                        .addBox(-2.62F, -1.15F, -2.45F, 1.55F, 2.25F, 4.90F, new CubeDeformation(0.07F))
                        .addBox(-0.78F, -0.85F, -2.62F, 1.56F, 2.55F, 5.24F, new CubeDeformation(0.09F))
                        .addBox(1.07F, -1.15F, -2.45F, 1.55F, 2.25F, 4.90F, new CubeDeformation(0.07F)),
                PartPose.offsetAndRotation(0.0F, 13.55F, -2.72F, 0.63F, 0.0F, 0.0F));

        PartDefinition head = root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0)
                        .addBox(-1.92F, -2.88F, -1.95F, 3.84F, 4.25F, 3.90F, new CubeDeformation(0.05F))
                        .texOffs(18, 0).addBox(-1.42F, -1.02F, -3.78F, 2.84F, 1.30F, 1.82F)
                        .texOffs(18, 4).addBox(-1.03F, 0.18F, -3.57F, 2.06F, 0.58F, 1.48F),
                PartPose.offset(0.0F, 8.8F, -4.55F));
        head.addOrReplaceChild("face_feathers", CubeListBuilder.create().texOffs(4, 10)
                        .addBox(-2.10F, -1.30F, -1.55F, 0.62F, 2.38F, 2.72F, new CubeDeformation(0.07F))
                        .addBox(1.48F, -1.30F, -1.55F, 0.62F, 2.38F, 2.72F, new CubeDeformation(0.07F))
                        .addBox(-1.33F, 0.63F, -1.92F, 2.66F, 0.62F, 2.52F, new CubeDeformation(0.05F)),
                PartPose.offset(0.0F, 0.0F, 0.0F));
        head.addOrReplaceChild("large_comb", CubeListBuilder.create().texOffs(28, 0)
                        .addBox(-0.55F, -3.1F, -1.45F, 1.1F, 3.1F, 4.6F, new CubeDeformation(0.07F))
                        .texOffs(31, 1).addBox(-0.50F, -4.0F, -0.7F, 1.0F, 1.25F, 1.2F)
                        .texOffs(31, 1).addBox(-0.50F, -3.8F, 0.8F, 1.0F, 1.15F, 1.2F),
                PartPose.offset(0.0F, -3.15F, -0.65F));
        head.addOrReplaceChild("small_comb", CubeListBuilder.create().texOffs(28, 0)
                        .addBox(-0.45F, -1.5F, -0.65F, 0.9F, 1.5F, 3.0F),
                PartPose.offset(0.0F, -3.2F, -0.55F));
        head.addOrReplaceChild("pea_comb", CubeListBuilder.create().texOffs(28, 0)
                        .addBox(-1.25F, -0.8F, -1.4F, 2.5F, 0.8F, 3.2F, new CubeDeformation(0.10F)),
                PartPose.offset(0.0F, -3.25F, -0.2F));
        head.addOrReplaceChild("leghorn_comb", CubeListBuilder.create().texOffs(28, 0)
                        .addBox(-0.45F, -3.0F, -1.6F, 0.9F, 3.0F, 4.8F, new CubeDeformation(0.08F))
                        .texOffs(31, 1).addBox(-0.35F, -4.2F, -0.85F, 0.8F, 1.55F, 1.15F)
                        .texOffs(31, 1).addBox(-0.25F, -4.0F, 0.65F, 0.8F, 1.45F, 1.15F)
                        .texOffs(31, 1).addBox(0.15F, -3.55F, 1.85F, 0.8F, 1.35F, 1.0F),
                PartPose.offsetAndRotation(0.20F, -3.1F, -0.65F, 0.0F, 0.0F, -0.17F));
        head.addOrReplaceChild("walnut_comb", CubeListBuilder.create().texOffs(28, 0)
                        .addBox(-1.15F, -0.75F, -1.15F, 2.3F, 0.75F, 2.5F, new CubeDeformation(0.18F))
                        .addBox(-0.75F, -1.10F, -0.55F, 1.5F, 0.55F, 1.45F, new CubeDeformation(0.10F)),
                PartPose.offset(0.0F, -3.2F, -0.2F));
        head.addOrReplaceChild("wattles", CubeListBuilder.create().texOffs(38, 0)
                        .addBox(-1.35F, 0.0F, -0.45F, 1.15F, 2.6F, 0.9F)
                        .addBox(0.20F, 0.0F, -0.45F, 1.15F, 2.6F, 0.9F),
                PartPose.offset(0.0F, 0.65F, -3.25F));
        head.addOrReplaceChild("white_earlobes", CubeListBuilder.create().texOffs(50, 0)
                        .addBox(-2.18F, -0.42F, -0.50F, 0.32F, 1.16F, 1.12F)
                        .addBox(1.86F, -0.42F, -0.50F, 0.32F, 1.16F, 1.12F),
                PartPose.offset(0.0F, -0.10F, -1.55F));
        head.addOrReplaceChild("silkie_crest", CubeListBuilder.create().texOffs(0, 10)
                        .addBox(-2.8F, -1.4F, -2.4F, 5.6F, 2.8F, 4.8F, new CubeDeformation(0.34F)),
                PartPose.offset(0.0F, -3.65F, 0.0F));
        head.addOrReplaceChild("silkie_face_muffs", CubeListBuilder.create().texOffs(0, 10)
                        .addBox(-3.05F, -1.15F, -1.65F, 1.25F, 2.65F, 3.15F, new CubeDeformation(0.22F))
                        .addBox(1.80F, -1.15F, -1.65F, 1.25F, 2.65F, 3.15F, new CubeDeformation(0.22F))
                        .addBox(-1.55F, 0.65F, -2.35F, 3.10F, 1.15F, 2.45F, new CubeDeformation(0.16F)),
                PartPose.offset(0.0F, -0.15F, -0.25F));

        PartDefinition rightLeg = root.addOrReplaceChild("right_leg", CubeListBuilder.create().texOffs(0, 38)
                        .addBox(-0.65F, 0.0F, -0.65F, 1.3F, 5.0F, 1.3F),
                PartPose.offset(-2.0F, 18.6F, 0.75F));
        rightLeg.addOrReplaceChild("foot", CubeListBuilder.create().texOffs(6, 38)
                        .addBox(-0.32F, -0.28F, -2.65F, 0.64F, 0.56F, 3.5F)
                        .addBox(-1.20F, -0.24F, -2.25F, 0.58F, 0.48F, 2.8F)
                        .addBox(0.62F, -0.24F, -2.25F, 0.58F, 0.48F, 2.8F)
                        .addBox(-0.30F, -0.22F, 0.45F, 0.60F, 0.44F, 1.65F),
                PartPose.offset(0.0F, 5.0F, 0.0F));
        PartDefinition leftLeg = root.addOrReplaceChild("left_leg", CubeListBuilder.create().texOffs(0, 38).mirror()
                        .addBox(-0.65F, 0.0F, -0.65F, 1.3F, 5.0F, 1.3F),
                PartPose.offset(2.0F, 18.6F, 0.75F));
        leftLeg.addOrReplaceChild("foot", CubeListBuilder.create().texOffs(6, 38).mirror()
                        .addBox(-0.32F, -0.28F, -2.65F, 0.64F, 0.56F, 3.5F)
                        .addBox(-1.20F, -0.24F, -2.25F, 0.58F, 0.48F, 2.8F)
                        .addBox(0.62F, -0.24F, -2.25F, 0.58F, 0.48F, 2.8F)
                        .addBox(-0.30F, -0.22F, 0.45F, 0.60F, 0.44F, 1.65F),
                PartPose.offset(0.0F, 5.0F, 0.0F));

        root.addOrReplaceChild("right_wing", CubeListBuilder.create().texOffs(34, 18)
                        .addBox(-1.0F, -3.25F, -3.15F, 1.1F, 5.8F, 5.7F, new CubeDeformation(0.09F))
                        .texOffs(44, 20).addBox(-1.18F, -1.65F, -2.15F, 0.72F, 5.35F, 1.65F)
                        .texOffs(48, 24).addBox(-1.20F, -1.15F, -0.75F, 0.66F, 5.15F, 1.55F)
                        .texOffs(52, 28).addBox(-1.18F, -0.55F, 0.55F, 0.60F, 4.65F, 1.45F)
                        .texOffs(52, 28).addBox(-1.12F, 0.05F, 1.75F, 0.54F, 3.85F, 1.20F),
                PartPose.offsetAndRotation(-3.65F, 14.65F, 0.0F, -0.06F, -0.12F, 0.10F));
        root.addOrReplaceChild("left_wing", CubeListBuilder.create().texOffs(34, 18).mirror()
                        .addBox(-0.10F, -3.25F, -3.15F, 1.1F, 5.8F, 5.7F, new CubeDeformation(0.09F))
                        .texOffs(44, 20).addBox(0.46F, -1.65F, -2.15F, 0.72F, 5.35F, 1.65F)
                        .texOffs(48, 24).addBox(0.54F, -1.15F, -0.75F, 0.66F, 5.15F, 1.55F)
                        .texOffs(52, 28).addBox(0.58F, -0.55F, 0.55F, 0.60F, 4.65F, 1.45F)
                        .texOffs(52, 28).addBox(0.58F, 0.05F, 1.75F, 0.54F, 3.85F, 1.20F),
                PartPose.offsetAndRotation(3.65F, 14.65F, 0.0F, -0.06F, 0.12F, -0.10F));
        root.addOrReplaceChild("right_wing_coverts", CubeListBuilder.create().texOffs(44, 34)
                        .addBox(-0.72F, -2.62F, -2.65F, 0.72F, 2.20F, 2.20F, new CubeDeformation(0.08F))
                        .addBox(-0.78F, -1.08F, -1.95F, 0.70F, 2.42F, 2.15F, new CubeDeformation(0.07F))
                        .addBox(-0.76F, 0.62F, -1.05F, 0.64F, 2.48F, 2.05F, new CubeDeformation(0.06F)),
                PartPose.offsetAndRotation(-4.02F, 14.55F, -0.25F, -0.06F, -0.12F, 0.10F));
        root.addOrReplaceChild("left_wing_coverts", CubeListBuilder.create().texOffs(44, 34).mirror()
                        .addBox(0.0F, -2.62F, -2.65F, 0.72F, 2.20F, 2.20F, new CubeDeformation(0.08F))
                        .addBox(0.08F, -1.08F, -1.95F, 0.70F, 2.42F, 2.15F, new CubeDeformation(0.07F))
                        .addBox(0.12F, 0.62F, -1.05F, 0.64F, 2.48F, 2.05F, new CubeDeformation(0.06F)),
                PartPose.offsetAndRotation(4.02F, 14.55F, -0.25F, -0.06F, 0.12F, -0.10F));

        addRoosterTail(root, "rooster_tail_center", 0.0F, 12.8F, 4.45F, 2.0F, 9.0F, -0.78F, 0.0F);
        addRoosterTail(root, "rooster_tail_left", -1.45F, 13.25F, 4.25F, 1.6F, 8.0F, -0.68F, -0.18F);
        addRoosterTail(root, "rooster_tail_right", 1.45F, 13.25F, 4.25F, 1.6F, 8.0F, -0.68F, 0.18F);
        addRoosterTail(root, "rooster_tail_outer_left", -2.55F, 14.0F, 4.0F, 1.25F, 6.8F, -0.55F, -0.30F);
        addRoosterTail(root, "rooster_tail_outer_right", 2.55F, 14.0F, 4.0F, 1.25F, 6.8F, -0.55F, 0.30F);
        addHenTail(root, "hen_tail_center", 0.0F, 14.3F, 4.3F, 2.4F, -0.46F, 0.0F);
        addHenTail(root, "hen_tail_left", -1.65F, 14.65F, 4.15F, 1.8F, -0.40F, -0.20F);
        addHenTail(root, "hen_tail_right", 1.65F, 14.65F, 4.15F, 1.8F, -0.40F, 0.20F);
        root.addOrReplaceChild("silkie_tail", CubeListBuilder.create().texOffs(40, 38)
                        .addBox(-2.7F, -2.7F, -1.0F, 5.4F, 5.4F, 2.0F, new CubeDeformation(0.35F)),
                PartPose.offsetAndRotation(0.0F, 15.2F, 4.0F, -0.28F, 0.0F, 0.0F));

        root.addOrReplaceChild("right_spur", CubeListBuilder.create().texOffs(10, 40)
                        .addBox(-0.45F, -0.35F, 0.0F, 0.9F, 0.7F, 2.0F),
                PartPose.offsetAndRotation(-2.0F, 21.1F, 1.2F, -0.42F, 0.0F, 0.0F));
        root.addOrReplaceChild("left_spur", CubeListBuilder.create().texOffs(10, 40).mirror()
                        .addBox(-0.45F, -0.35F, 0.0F, 0.9F, 0.7F, 2.0F),
                PartPose.offsetAndRotation(2.0F, 21.1F, 1.2F, -0.42F, 0.0F, 0.0F));
        root.addOrReplaceChild("right_leg_feathers", CubeListBuilder.create().texOffs(14, 38)
                        .addBox(-1.15F, -1.2F, -1.05F, 2.3F, 2.8F, 2.1F, new CubeDeformation(0.20F)),
                PartPose.offset(-2.0F, 19.2F, 0.75F));
        root.addOrReplaceChild("left_leg_feathers", CubeListBuilder.create().texOffs(14, 38).mirror()
                        .addBox(-1.15F, -1.2F, -1.05F, 2.3F, 2.8F, 2.1F, new CubeDeformation(0.20F)),
                PartPose.offset(2.0F, 19.2F, 0.75F));
        root.addOrReplaceChild("right_toe_feathers", CubeListBuilder.create().texOffs(14, 42)
                        .addBox(-1.35F, -0.35F, -2.45F, 2.4F, 0.75F, 3.35F, new CubeDeformation(0.12F)),
                PartPose.offsetAndRotation(-2.0F, 23.45F, 0.65F, 0.02F, 0.08F, 0.0F));
        root.addOrReplaceChild("left_toe_feathers", CubeListBuilder.create().texOffs(14, 42).mirror()
                        .addBox(-1.05F, -0.35F, -2.45F, 2.4F, 0.75F, 3.35F, new CubeDeformation(0.12F)),
                PartPose.offsetAndRotation(2.0F, 23.45F, 0.65F, 0.02F, -0.08F, 0.0F));
        root.addOrReplaceChild("silkie_body_fluff", CubeListBuilder.create().texOffs(0, 18)
                        .addBox(-4.0F, -4.3F, -4.5F, 8.0F, 8.6F, 9.0F, new CubeDeformation(0.38F)),
                PartPose.offsetAndRotation(0.0F, 15.4F, 0.45F, 1.34F, 0.0F, 0.0F));
        root.addOrReplaceChild("brahma_shoulders", CubeListBuilder.create().texOffs(18, 22)
                        .addBox(-4.15F, -2.7F, -2.7F, 8.3F, 5.4F, 5.4F, new CubeDeformation(0.20F)),
                PartPose.offsetAndRotation(0.0F, 14.0F, -0.9F, 1.15F, 0.0F, 0.0F));
        root.addOrReplaceChild("gamefowl_cape", CubeListBuilder.create().texOffs(18, 22)
                        .addBox(-3.15F, -3.15F, -2.55F, 6.3F, 5.6F, 5.1F, new CubeDeformation(0.12F)),
                PartPose.offsetAndRotation(0.0F, 12.9F, -1.85F, 0.96F, 0.0F, 0.0F));
        root.addOrReplaceChild("heavy_keel", CubeListBuilder.create().texOffs(0, 18)
                        .addBox(-3.25F, -2.9F, -2.8F, 6.5F, 5.8F, 5.6F, new CubeDeformation(0.34F)),
                PartPose.offsetAndRotation(0.0F, 16.0F, -2.75F, 1.08F, 0.0F, 0.0F));
        root.addOrReplaceChild("sussex_collar", CubeListBuilder.create().texOffs(0, 6)
                        .addBox(-2.75F, -1.15F, -2.45F, 5.5F, 2.3F, 4.9F, new CubeDeformation(0.16F)),
                PartPose.offsetAndRotation(0.0F, 11.75F, -3.0F, -0.16F, 0.0F, 0.0F));
        root.addOrReplaceChild("rooster_hackle", CubeListBuilder.create().texOffs(18, 22)
                        .addBox(-2.75F, -3.0F, -2.45F, 5.5F, 2.4F, 4.9F, new CubeDeformation(0.13F))
                        .addBox(-2.45F, -0.95F, -2.20F, 4.9F, 2.1F, 4.4F, new CubeDeformation(0.12F))
                        .addBox(-2.05F, 0.85F, -1.85F, 4.1F, 1.8F, 3.7F, new CubeDeformation(0.10F)),
                PartPose.offsetAndRotation(0.0F, 12.0F, -3.05F, -0.20F, 0.0F, 0.0F));
        root.addOrReplaceChild("saddle_streamers", CubeListBuilder.create().texOffs(24, 38)
                        .addBox(-2.65F, -0.5F, -0.4F, 1.35F, 5.3F, 0.75F, new CubeDeformation(0.05F))
                        .addBox(1.30F, -0.5F, -0.4F, 1.35F, 5.3F, 0.75F, new CubeDeformation(0.05F)),
                PartPose.offsetAndRotation(0.0F, 14.5F, 3.15F, -0.46F, 0.0F, 0.0F));
        root.addOrReplaceChild("rooster_tail_coverts", CubeListBuilder.create().texOffs(24, 38)
                        .addBox(-2.65F, -3.5F, -0.45F, 1.55F, 4.2F, 0.85F, new CubeDeformation(0.07F))
                        .addBox(-0.75F, -4.15F, -0.40F, 1.50F, 4.8F, 0.80F, new CubeDeformation(0.07F))
                        .addBox(1.10F, -3.5F, -0.45F, 1.55F, 4.2F, 0.85F, new CubeDeformation(0.07F)),
                PartPose.offsetAndRotation(0.0F, 14.9F, 4.05F, -0.68F, 0.0F, 0.0F));
        root.addOrReplaceChild("hen_cushion", CubeListBuilder.create().texOffs(18, 22)
                        .addBox(-3.35F, -2.25F, -2.25F, 6.7F, 4.5F, 4.5F, new CubeDeformation(0.22F)),
                PartPose.offsetAndRotation(0.0F, 15.15F, 3.25F, 1.42F, 0.0F, 0.0F));

        addChickParts(root);
        return LayerDefinition.create(mesh, 64, 64);
    }

    private static void addRoosterTail(PartDefinition root, String name, float x, float y, float z,
                                       float width, float height, float xRot, float zRot) {
        float segment = height / 3.0F;
        PartDefinition base = root.addOrReplaceChild(name, CubeListBuilder.create().texOffs(24, 38)
                        .addBox(-width / 2.0F, -segment, 0.0F, width, segment + 0.25F, 0.9F,
                                new CubeDeformation(0.05F)),
                PartPose.offsetAndRotation(x, y, z, xRot, 0.0F, zRot));
        PartDefinition middle = base.addOrReplaceChild("middle", CubeListBuilder.create().texOffs(24, 38)
                        .addBox(-width * 0.46F, -segment, 0.0F, width * 0.92F, segment + 0.2F, 0.82F,
                                new CubeDeformation(0.04F)),
                PartPose.offsetAndRotation(0.0F, -segment + 0.2F, 0.34F, -0.24F, 0.0F, 0.0F));
        middle.addOrReplaceChild("tip", CubeListBuilder.create().texOffs(24, 38)
                        .addBox(-width * 0.39F, -segment + 0.25F, 0.0F, width * 0.78F, segment, 0.72F,
                                new CubeDeformation(0.03F)),
                PartPose.offsetAndRotation(0.0F, -segment + 0.25F, 0.44F, -0.34F, 0.0F, 0.0F));
    }

    private static void addHenTail(PartDefinition root, String name, float x, float y, float z,
                                   float width, float xRot, float zRot) {
        root.addOrReplaceChild(name, CubeListBuilder.create().texOffs(40, 38)
                        .addBox(-width / 2.0F, -3.2F, 0.0F, width, 4.2F, 1.0F,
                                new CubeDeformation(0.06F)),
                PartPose.offsetAndRotation(x, y, z, xRot, 0.0F, zRot));
    }

    private static void addChickParts(PartDefinition root) {
        root.addOrReplaceChild("chick_body", CubeListBuilder.create().texOffs(0, 18)
                        .addBox(-2.65F, -2.6F, -3.0F, 5.3F, 5.2F, 6.0F, new CubeDeformation(0.22F)),
                PartPose.offsetAndRotation(0.0F, 18.35F, 0.6F, 1.34F, 0.0F, 0.0F));
        root.addOrReplaceChild("chick_down_fluff", CubeListBuilder.create().texOffs(0, 24)
                        .addBox(-2.78F, -2.45F, -2.82F, 5.56F, 4.90F, 5.64F, new CubeDeformation(0.24F))
                        .texOffs(12, 26).addBox(-2.38F, 1.62F, -2.42F, 4.76F, 1.20F, 4.84F,
                                new CubeDeformation(0.14F)),
                PartPose.offsetAndRotation(0.0F, 18.35F, 0.58F, 1.34F, 0.0F, 0.0F));
        root.addOrReplaceChild("chick_head", CubeListBuilder.create().texOffs(0, 0)
                        .addBox(-1.9F, -2.25F, -1.9F, 3.8F, 4.0F, 3.8F, new CubeDeformation(0.10F))
                        .texOffs(18, 0).addBox(-1.05F, -0.55F, -3.1F, 2.1F, 1.0F, 1.35F),
                PartPose.offset(0.0F, 15.05F, -2.85F));
        root.addOrReplaceChild("chick_right_wing", CubeListBuilder.create().texOffs(34, 18)
                        .addBox(-0.6F, -1.8F, -1.9F, 0.7F, 3.6F, 3.8F),
                PartPose.offset(-2.65F, 18.1F, 0.45F));
        root.addOrReplaceChild("chick_left_wing", CubeListBuilder.create().texOffs(34, 18).mirror()
                        .addBox(-0.1F, -1.8F, -1.9F, 0.7F, 3.6F, 3.8F),
                PartPose.offset(2.65F, 18.1F, 0.45F));
        root.addOrReplaceChild("chick_right_leg", CubeListBuilder.create().texOffs(0, 38)
                        .addBox(-0.4F, 0.0F, -0.4F, 0.8F, 2.4F, 0.8F)
                        .texOffs(6, 38).addBox(-0.65F, 2.1F, -1.05F, 1.3F, 0.45F, 1.5F),
                PartPose.offset(-1.35F, 21.4F, 0.55F));
        root.addOrReplaceChild("chick_left_leg", CubeListBuilder.create().texOffs(0, 38).mirror()
                        .addBox(-0.4F, 0.0F, -0.4F, 0.8F, 2.4F, 0.8F)
                        .texOffs(6, 38).addBox(-0.65F, 2.1F, -1.05F, 1.3F, 0.45F, 1.5F),
                PartPose.offset(1.35F, 21.4F, 0.55F));
        root.addOrReplaceChild("chick_tail", CubeListBuilder.create().texOffs(40, 38)
                        .addBox(-1.25F, -0.4F, 0.0F, 2.5F, 2.2F, 0.8F),
                PartPose.offsetAndRotation(0.0F, 18.0F, 3.15F, -0.45F, 0.0F, 0.0F));
    }

    @Override
    public void setupAnim(HeritageChicken chicken, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        boolean chick = chicken.isBaby();
        boolean rooster = !chick && chicken.isRooster();
        boolean hen = !chick && chicken.isHen();
        FowlBreed breed = chicken.getBreed();
        boolean silkie = !chick && breed == FowlBreed.SILKIE;
        boolean brahma = !chick && breed == FowlBreed.BRAHMA;
        boolean leghorn = !chick && breed == FowlBreed.LEGHORN;
        boolean gamefowl = !chick && (breed == FowlBreed.CRIOLLO_DOMINICANO
                || breed == FowlBreed.AYAM_CEMANI);
        boolean heavyBreed = !chick && (breed == FowlBreed.RHODE_ISLAND_RED
                || breed == FowlBreed.PLYMOUTH_ROCK
                || breed == FowlBreed.BRAHMA
                || breed == FowlBreed.SUSSEX);
        boolean featheredLegs = silkie || brahma;

        setAdultVisible(!chick);
        setChickVisible(chick);
        roosterBodyContour.visible = rooster;
        roosterBreastContour.visible = rooster;
        roosterFeatherSkirt.visible = rooster;
        henBodyContour.visible = hen;
        henBellyContour.visible = hen;
        henFeatherSkirt.visible = hen;
        silkieBodyFluff.visible = silkie;
        brahmaShoulders.visible = brahma;
        silkieCrest.visible = silkie;
        silkieFaceMuffs.visible = silkie;
        peaComb.visible = brahma;
        leghornComb.visible = leghorn;
        leghornComb.xScale = hen ? 0.74F : 1.0F;
        leghornComb.yScale = hen ? 0.68F : 1.0F;
        leghornComb.zScale = hen ? 0.80F : 1.0F;
        walnutComb.visible = silkie;
        walnutComb.xScale = hen ? 0.78F : 1.0F;
        walnutComb.yScale = hen ? 0.70F : 1.0F;
        walnutComb.zScale = hen ? 0.82F : 1.0F;
        whiteEarlobes.visible = leghorn;
        largeComb.visible = rooster && !silkie && !brahma && !leghorn;
        smallComb.visible = hen && !silkie && !brahma && !leghorn;
        wattles.visible = rooster && !silkie;
        gamefowlCape.visible = gamefowl;
        heavyKeel.visible = heavyBreed;
        sussexCollar.visible = !chick && breed == FowlBreed.SUSSEX;
        roosterHackle.visible = rooster && !silkie;
        saddleStreamers.visible = rooster && !silkie;
        roosterTailCoverts.visible = rooster && !silkie;
        henCushion.visible = hen && heavyBreed;
        rightSpur.visible = rooster;
        leftSpur.visible = rooster;
        rightLegFeathers.visible = featheredLegs;
        leftLegFeathers.visible = featheredLegs;
        rightToeFeathers.visible = featheredLegs;
        leftToeFeathers.visible = featheredLegs;
        setRoosterTailVisible(rooster && !silkie, breed);
        setHenTailVisible(hen && !silkie);
        silkieTail.visible = silkie;
        applyBreedPose(breed, chick, rooster);

        float walkRight = Mth.cos(limbSwing * 0.72F) * 1.15F * limbSwingAmount;
        float walkLeft = Mth.cos(limbSwing * 0.72F + Mth.PI) * 1.15F * limbSwingAmount;
        float idle = Mth.sin(ageInTicks * 0.16F) * 0.045F;
        float flap = chicken.onGround()
                ? 0.05F + Mth.sin(ageInTicks * 0.12F) * 0.025F
                : 0.82F + Mth.sin(ageInTicks * 1.8F) * 0.38F;

        if (chick) {
            chickHead.xRot = headPitch * Mth.DEG_TO_RAD + idle;
            chickHead.yRot = netHeadYaw * Mth.DEG_TO_RAD;
            chickRightLeg.xRot = walkRight;
            chickLeftLeg.xRot = walkLeft;
            chickRightWing.zRot = flap * 0.75F;
            chickLeftWing.zRot = -flap * 0.75F;
            chickTail.yRot = Mth.sin(ageInTicks * 0.22F) * 0.08F;
            return;
        }

        head.xRot = headPitch * Mth.DEG_TO_RAD + idle;
        head.yRot = netHeadYaw * Mth.DEG_TO_RAD;
        neck.xRot = neckBaseRotation(breed, rooster) + head.xRot * 0.22F;
        neck.yRot = head.yRot * 0.30F;
        neckMantle.xRot = 0.58F + head.xRot * 0.08F;
        neckMantle.yRot = head.yRot * 0.12F;
        neckFeatherFringe.xRot = neckMantle.xRot;
        neckFeatherFringe.yRot = neckMantle.yRot;
        roosterHackle.xRot = neck.xRot;
        roosterHackle.yRot = neck.yRot * 0.72F;
        rightLeg.xRot = walkRight;
        leftLeg.xRot = walkLeft;
        rightWing.zRot = 0.08F + flap;
        leftWing.zRot = -0.08F - flap;
        rightWingCoverts.zRot = rightWing.zRot;
        leftWingCoverts.zRot = leftWing.zRot;

        float tailSway = Mth.sin(ageInTicks * 0.11F) * 0.055F;
        roosterTailCenter.yRot = tailSway;
        roosterTailLeft.yRot = tailSway - 0.10F;
        roosterTailRight.yRot = tailSway + 0.10F;
        roosterTailOuterLeft.yRot = tailSway - 0.16F;
        roosterTailOuterRight.yRot = tailSway + 0.16F;
        henTailCenter.yRot = tailSway;
        henTailLeft.yRot = tailSway - 0.08F;
        henTailRight.yRot = tailSway + 0.08F;
        silkieTail.yRot = tailSway;
        saddleStreamers.yRot = tailSway * 0.65F;
        roosterTailCoverts.yRot = tailSway * 0.78F;
        roosterBodyContour.yRot = body.yRot;
        roosterBreastContour.yRot = breast.yRot;
        roosterFeatherSkirt.yRot = body.yRot;
        henBodyContour.yRot = body.yRot;
        henBellyContour.yRot = breast.yRot;
        henFeatherSkirt.yRot = body.yRot;
        applyBehaviorAnimations(chicken, ageInTicks, limbSwingAmount);
    }

    private void applyBreedPose(FowlBreed breed, boolean chick, boolean rooster) {
        if (chick) {
            chickHead.y = 15.05F;
            chickBody.y = 18.35F;
            chickDownFluff.y = 18.35F;
            resetChickScale();
            if (breed == FowlBreed.BRAHMA || breed == FowlBreed.SILKIE) {
                scale(chickBody, 1.06F, 1.02F, 1.08F);
                scale(chickDownFluff, 1.10F, 1.06F, 1.12F);
            } else if (breed == FowlBreed.LEGHORN || breed == FowlBreed.AYAM_CEMANI) {
                scale(chickBody, 0.94F, 1.02F, 0.96F);
                scale(chickDownFluff, 0.96F, 1.03F, 0.98F);
            }
            return;
        }
        resetAdultScale();
        body.y = 15.2F;
        breast.y = 15.3F;
        saddle.y = 14.7F;
        neck.y = 12.0F;
        head.y = 8.8F;
        rightLeg.y = 18.6F;
        leftLeg.y = 18.6F;
        body.xRot = 1.34F;
        breast.xRot = 1.14F;
        saddle.xRot = 1.43F;
        switch (breed) {
            case CRIOLLO_DOMINICANO -> {
                head.y = 8.25F;
                neck.y = 11.55F;
                rightLeg.y = 18.1F;
                leftLeg.y = 18.1F;
                applyAthleticProfile(1.00F, 1.08F, 1.02F);
            }
            case RHODE_ISLAND_RED, PLYMOUTH_ROCK, SUSSEX -> {
                body.y = 15.55F;
                breast.y = 15.65F;
                head.y = 9.0F;
                applyRobustProfile(breed == FowlBreed.PLYMOUTH_ROCK ? 1.04F : 1.0F);
            }
            case LEGHORN, AYAM_CEMANI -> {
                head.y = 8.15F;
                neck.y = 11.45F;
                breast.y = 15.0F;
                applyAthleticProfile(0.93F, 1.13F, breed == FowlBreed.AYAM_CEMANI ? 1.08F : 1.03F);
            }
            case BRAHMA -> {
                body.y = 15.75F;
                breast.y = 15.8F;
                head.y = 9.15F;
                rightLeg.y = 19.0F;
                leftLeg.y = 19.0F;
                applyGiantProfile();
            }
            case SILKIE -> {
                body.y = 15.8F;
                breast.y = 15.9F;
                head.y = 9.45F;
                rightLeg.y = 19.15F;
                leftLeg.y = 19.15F;
                applySilkieProfile();
            }
        }

        // Keep the independent feather shells locked to the animated skeleton after
        // each breed changes the body's height and stance.
        roosterBodyContour.y = body.y - 0.35F;
        roosterBreastContour.y = breast.y - 0.30F;
        roosterFeatherSkirt.y = body.y + 2.25F;
        henBodyContour.y = body.y + 0.18F;
        henBellyContour.y = breast.y + 0.35F;
        henFeatherSkirt.y = body.y + 2.62F;
        neckFeatherFringe.y = neck.y + 1.55F;
        neckMantle.y = neck.y + 0.90F;
        rightWing.y = body.y - 0.55F;
        leftWing.y = body.y - 0.55F;
        rightWingCoverts.y = body.y - 0.65F;
        leftWingCoverts.y = body.y - 0.65F;

        saddleStreamers.xRot = -0.46F;
        roosterTailCoverts.xRot = -0.68F;
        applyTailProfile(breed, rooster);

        if (rooster) {
            head.y -= 0.35F;
            neck.y -= 0.20F;
            breast.y -= 0.10F;
        } else {
            body.xRot += 0.05F;
            breast.xRot += 0.04F;
        }
    }

    private void resetAdultScale() {
        scale(body, 1.0F, 1.0F, 1.0F);
        scale(breast, 1.0F, 1.0F, 1.0F);
        scale(saddle, 1.0F, 1.0F, 1.0F);
        scale(neck, 1.0F, 1.0F, 1.0F);
        scale(neckMantle, 1.0F, 1.0F, 1.0F);
        scale(neckFeatherFringe, 1.0F, 1.0F, 1.0F);
        scale(head, 1.0F, 1.0F, 1.0F);
        scale(roosterBodyContour, 1.0F, 1.0F, 1.0F);
        scale(roosterBreastContour, 1.0F, 1.0F, 1.0F);
        scale(roosterFeatherSkirt, 1.0F, 1.0F, 1.0F);
        scale(henBodyContour, 1.0F, 1.0F, 1.0F);
        scale(henBellyContour, 1.0F, 1.0F, 1.0F);
        scale(henFeatherSkirt, 1.0F, 1.0F, 1.0F);
        scale(rightWing, 1.0F, 1.0F, 1.0F);
        scale(leftWing, 1.0F, 1.0F, 1.0F);
        scale(rightWingCoverts, 1.0F, 1.0F, 1.0F);
        scale(leftWingCoverts, 1.0F, 1.0F, 1.0F);
    }

    private void resetChickScale() {
        scale(chickBody, 1.0F, 1.0F, 1.0F);
        scale(chickDownFluff, 1.0F, 1.0F, 1.0F);
        scale(chickHead, 1.0F, 1.0F, 1.0F);
    }

    private void applyAthleticProfile(float width, float bodyHeight, float bodyLength) {
        // Adult torso parts are pitched almost ninety degrees: local Y controls
        // front-to-back length, while local Z controls visible standing height.
        scale(body, width, bodyLength, bodyHeight);
        scale(breast, width * 0.98F, bodyLength * 0.96F, bodyHeight * 1.04F);
        scale(roosterBodyContour, width, bodyLength, bodyHeight);
        scale(roosterBreastContour, width * 0.98F, bodyLength * 0.96F, bodyHeight * 1.04F);
        scale(roosterFeatherSkirt, width * 0.96F, bodyLength, bodyHeight * 0.96F);
        scale(henBodyContour, width * 1.02F, bodyLength * 0.98F, bodyHeight * 0.98F);
        scale(henBellyContour, width, bodyLength * 0.94F, bodyHeight);
        scale(henFeatherSkirt, width, bodyLength * 0.96F, bodyHeight * 0.94F);
        scale(neck, 0.94F, 1.12F, 0.94F);
        scale(neckFeatherFringe, 0.94F, 1.05F, 0.96F);
        scale(head, 0.92F, 0.95F, 0.94F);
        scaleWings(0.94F, 1.06F, 1.04F);
    }

    private void applyRobustProfile(float extraWidth) {
        scale(body, 1.08F * extraWidth, 1.08F, 1.04F);
        scale(breast, 1.10F * extraWidth, 1.06F, 1.08F);
        scale(roosterBodyContour, 1.08F * extraWidth, 1.08F, 1.04F);
        scale(roosterBreastContour, 1.10F * extraWidth, 1.06F, 1.08F);
        scale(roosterFeatherSkirt, 1.08F * extraWidth, 1.06F, 1.04F);
        scale(henBodyContour, 1.13F * extraWidth, 1.12F, 1.08F);
        scale(henBellyContour, 1.14F * extraWidth, 1.08F, 1.10F);
        scale(henFeatherSkirt, 1.12F * extraWidth, 1.08F, 1.06F);
        scale(neck, 1.02F, 0.98F, 1.04F);
        scale(neckFeatherFringe, 1.04F, 1.03F, 1.06F);
        scale(head, 1.01F, 1.0F, 1.02F);
        scaleWings(1.06F, 1.02F, 1.08F);
    }

    private void applyGiantProfile() {
        applyRobustProfile(1.08F);
        scale(body, 1.20F, 1.17F, 1.12F);
        scale(breast, 1.22F, 1.14F, 1.16F);
        scale(roosterBodyContour, 1.20F, 1.17F, 1.12F);
        scale(roosterBreastContour, 1.22F, 1.14F, 1.16F);
        scale(henBodyContour, 1.24F, 1.20F, 1.15F);
        scale(henBellyContour, 1.25F, 1.16F, 1.18F);
        scaleWings(1.16F, 1.08F, 1.14F);
    }

    private void applySilkieProfile() {
        scale(body, 1.10F, 1.10F, 1.08F);
        scale(breast, 1.13F, 1.08F, 1.10F);
        scale(roosterBodyContour, 1.11F, 1.10F, 1.08F);
        scale(roosterBreastContour, 1.13F, 1.08F, 1.10F);
        scale(henBodyContour, 1.16F, 1.14F, 1.12F);
        scale(henBellyContour, 1.18F, 1.12F, 1.14F);
        scale(head, 1.05F, 1.02F, 1.04F);
        scale(neck, 1.07F, 0.91F, 1.08F);
        scale(neckFeatherFringe, 1.12F, 1.0F, 1.12F);
        scaleWings(1.10F, 0.96F, 1.06F);
    }

    private void scaleWings(float width, float height, float length) {
        scale(rightWing, width, height, length);
        scale(leftWing, width, height, length);
        scale(rightWingCoverts, width, height, length);
        scale(leftWingCoverts, width, height, length);
    }

    private void applyTailProfile(FowlBreed breed, boolean rooster) {
        scale(roosterTailCenter, 1.0F, 1.0F, 1.0F);
        scale(roosterTailLeft, 1.0F, 1.0F, 1.0F);
        scale(roosterTailRight, 1.0F, 1.0F, 1.0F);
        scale(roosterTailOuterLeft, 1.0F, 1.0F, 1.0F);
        scale(roosterTailOuterRight, 1.0F, 1.0F, 1.0F);
        scale(henTailCenter, 1.0F, 1.0F, 1.0F);
        scale(henTailLeft, 1.0F, 1.0F, 1.0F);
        scale(henTailRight, 1.0F, 1.0F, 1.0F);

        boolean athletic = breed == FowlBreed.CRIOLLO_DOMINICANO
                || breed == FowlBreed.LEGHORN
                || breed == FowlBreed.AYAM_CEMANI;
        boolean giant = breed == FowlBreed.BRAHMA;

        if (rooster && athletic) {
            scale(roosterTailCenter, 0.92F, 1.20F, 0.92F);
            scale(roosterTailLeft, 0.92F, 1.14F, 0.92F);
            scale(roosterTailRight, 0.92F, 1.14F, 0.92F);
            scale(roosterTailOuterLeft, 0.88F, 1.22F, 0.88F);
            scale(roosterTailOuterRight, 0.88F, 1.22F, 0.88F);
        } else if (rooster && giant) {
            scale(roosterTailCenter, 1.18F, 0.90F, 1.12F);
            scale(roosterTailLeft, 1.16F, 0.88F, 1.10F);
            scale(roosterTailRight, 1.16F, 0.88F, 1.10F);
        } else if (rooster) {
            scale(roosterTailCenter, 1.10F, 0.96F, 1.06F);
            scale(roosterTailLeft, 1.08F, 0.94F, 1.04F);
            scale(roosterTailRight, 1.08F, 0.94F, 1.04F);
        } else if (giant) {
            scale(henTailCenter, 1.20F, 0.90F, 1.12F);
            scale(henTailLeft, 1.18F, 0.88F, 1.10F);
            scale(henTailRight, 1.18F, 0.88F, 1.10F);
        } else if (athletic) {
            scale(henTailCenter, 0.94F, 1.06F, 0.96F);
            scale(henTailLeft, 0.92F, 1.02F, 0.94F);
            scale(henTailRight, 0.92F, 1.02F, 0.94F);
        } else {
            scale(henTailCenter, 1.10F, 0.98F, 1.06F);
            scale(henTailLeft, 1.08F, 0.96F, 1.04F);
            scale(henTailRight, 1.08F, 0.96F, 1.04F);
        }
    }

    private static void scale(ModelPart part, float x, float y, float z) {
        part.xScale = x;
        part.yScale = y;
        part.zScale = z;
    }

    private void applyBehaviorAnimations(HeritageChicken chicken, float ageInTicks, float movement) {
        float phase = ageInTicks + chicken.getId() * 17.0F;
        // Mob's aggressive flag is synchronized, unlike its server-only target reference.
        boolean fighting = chicken.isRooster() && chicken.isAggressive();

        if (fighting) {
            float challenge = 0.08F + Mth.sin(ageInTicks * 0.42F) * 0.035F;
            head.xRot = 0.14F + challenge;
            neck.xRot -= 0.20F;
            neckMantle.xRot -= 0.10F;
            rightWing.zRot = 0.30F + challenge;
            leftWing.zRot = -0.30F - challenge;
            saddleStreamers.xRot = -0.58F;
            roosterTailCoverts.xRot = -0.80F;
            return;
        }

        // A short deterministic pecking window gives every bird independent idle life
        // without synchronizing extra entity data across the network.
        float peckCycle = phase % 118.0F;
        if (movement < 0.08F && peckCycle > 101.0F) {
            float peck = Mth.sin((peckCycle - 101.0F) / 17.0F * Mth.PI);
            head.xRot += peck * 1.10F;
            neck.xRot += peck * 0.62F;
            neckMantle.xRot += peck * 0.18F;
        }

        float shakeCycle = phase % 211.0F;
        if (movement < 0.08F && shakeCycle > 196.0F) {
            float shake = Mth.sin((shakeCycle - 196.0F) * 2.35F) * 0.11F;
            body.yRot = shake;
            breast.yRot = shake * 0.75F;
            roosterBodyContour.yRot = shake;
            roosterBreastContour.yRot = shake * 0.75F;
            roosterFeatherSkirt.yRot = shake;
            henBodyContour.yRot = shake;
            henBellyContour.yRot = shake * 0.75F;
            henFeatherSkirt.yRot = shake;
            rightWing.zRot += 0.18F + Mth.abs(shake);
            leftWing.zRot -= 0.18F + Mth.abs(shake);
            roosterTailCoverts.yRot += shake * 1.4F;
            henCushion.yRot = shake;
        } else {
            body.yRot = 0.0F;
            breast.yRot = 0.0F;
            roosterBodyContour.yRot = 0.0F;
            roosterBreastContour.yRot = 0.0F;
            roosterFeatherSkirt.yRot = 0.0F;
            henBodyContour.yRot = 0.0F;
            henBellyContour.yRot = 0.0F;
            henFeatherSkirt.yRot = 0.0F;
            henCushion.yRot = 0.0F;
        }
    }

    private static float neckBaseRotation(FowlBreed breed, boolean rooster) {
        float breedAngle = switch (breed) {
            case CRIOLLO_DOMINICANO, LEGHORN, AYAM_CEMANI -> -0.29F;
            case BRAHMA, SILKIE -> -0.12F;
            default -> -0.20F;
        };
        return rooster ? breedAngle - 0.035F : breedAngle + 0.035F;
    }

    private void setAdultVisible(boolean visible) {
        // The compact cores remain animation anchors. Sex-specific feather shells
        // provide the rendered outer silhouette and avoid double-drawing large cubes.
        body.visible = false;
        breast.visible = false;
        saddle.visible = visible;
        neck.visible = visible;
        neckMantle.visible = visible;
        neckFeatherFringe.visible = visible;
        head.visible = visible;
        rightLeg.visible = visible;
        leftLeg.visible = visible;
        rightWing.visible = visible;
        leftWing.visible = visible;
        rightWingCoverts.visible = visible;
        leftWingCoverts.visible = visible;
    }

    private void setChickVisible(boolean visible) {
        chickBody.visible = false;
        chickDownFluff.visible = visible;
        chickHead.visible = visible;
        chickRightWing.visible = visible;
        chickLeftWing.visible = visible;
        chickRightLeg.visible = visible;
        chickLeftLeg.visible = visible;
        chickTail.visible = visible;
    }

    private void setRoosterTailVisible(boolean visible, FowlBreed breed) {
        roosterTailCenter.visible = visible;
        roosterTailLeft.visible = visible;
        roosterTailRight.visible = visible;
        boolean longTail = breed == FowlBreed.CRIOLLO_DOMINICANO
                || breed == FowlBreed.LEGHORN
                || breed == FowlBreed.AYAM_CEMANI;
        roosterTailOuterLeft.visible = visible && longTail;
        roosterTailOuterRight.visible = visible && longTail;
    }

    private void setHenTailVisible(boolean visible) {
        henTailCenter.visible = visible;
        henTailLeft.visible = visible;
        henTailRight.visible = visible;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer consumer, int light, int overlay, int color) {
        root.render(poseStack, consumer, light, overlay, color);
    }
}
