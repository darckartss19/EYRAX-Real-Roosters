package com.eyrax.realroosters.client;

import com.eyrax.fowlapi.api.PlumagePattern;
import com.eyrax.realroosters.EyraxRealRoosters;
import com.eyrax.realroosters.entity.HeritageChicken;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.renderer.GeoRenderer;
import software.bernie.geckolib.renderer.layer.GeoRenderLayer;

/** Shared transparent genetics layer, preserving the five-overlay texture architecture. */
public final class HeritagePlumageGeoLayer extends GeoRenderLayer<HeritageChicken> {
    public HeritagePlumageGeoLayer(GeoRenderer<HeritageChicken> renderer) {
        super(renderer);
    }

    @Override
    public void render(PoseStack poseStack, HeritageChicken chicken, BakedGeoModel bakedModel,
                       RenderType renderType, MultiBufferSource buffers, VertexConsumer buffer,
                       float partialTick, int packedLight, int packedOverlay) {
        PlumagePattern pattern = chicken.getPlumage();
        if (pattern == PlumagePattern.SOLID || chicken.isInvisible()) {
            return;
        }

        ResourceLocation texture = ResourceLocation.fromNamespaceAndPath(
                EyraxRealRoosters.MOD_ID,
                "textures/entity/overlay/" + pattern.serializedName() + ".png");
        RenderType overlayType = RenderType.entityTranslucent(texture);
        getRenderer().reRender(bakedModel, poseStack, buffers, chicken, overlayType,
                buffers.getBuffer(overlayType), partialTick, packedLight,
                LivingEntityRenderer.getOverlayCoords(chicken, 0.0F), -1);
    }
}
