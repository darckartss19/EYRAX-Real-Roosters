package com.eyrax.realroosters.client;

import com.eyrax.fowlapi.api.PlumagePattern;
import com.eyrax.realroosters.EyraxRealRoosters;
import com.eyrax.realroosters.entity.HeritageChicken;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.resources.ResourceLocation;

/** Reusable genetics overlay: five textures replace 120 duplicated breed variants. */
public final class HeritagePlumageLayer extends RenderLayer<HeritageChicken, HeritageChickenModel> {
    public HeritagePlumageLayer(RenderLayerParent<HeritageChicken, HeritageChickenModel> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffers, int packedLight,
                       HeritageChicken chicken, float limbSwing, float limbSwingAmount,
                       float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        PlumagePattern pattern = chicken.getPlumage();
        if (pattern == PlumagePattern.SOLID || chicken.isInvisible()) {
            return;
        }

        ResourceLocation texture = ResourceLocation.fromNamespaceAndPath(
                EyraxRealRoosters.MOD_ID,
                "textures/entity/overlay/" + pattern.serializedName() + ".png");
        VertexConsumer consumer = buffers.getBuffer(RenderType.entityTranslucent(texture));
        getParentModel().renderToBuffer(poseStack, consumer, packedLight,
                LivingEntityRenderer.getOverlayCoords(chicken, 0.0F), -1);
    }
}
