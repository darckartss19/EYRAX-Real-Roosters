package com.eyrax.fowlapi;

import com.mojang.logging.LogUtils;
import net.neoforged.fml.common.Mod;
import org.slf4j.Logger;

/** Shared public contracts for the EYRAX poultry ecosystem. */
@Mod(EyraxFowlApi.MOD_ID)
public final class EyraxFowlApi {
    public static final String MOD_ID = "eyrax_fowl_api";
    public static final Logger LOGGER = LogUtils.getLogger();

    public EyraxFowlApi() {
        LOGGER.info("EYRAX Fowl API is loading");
    }
}
