package com.eyrax.fowlapi.api;

/** Read-only genetics contract for analyzers, armor, quests and add-ons. */
public interface FowlGeneticsView {
    FowlSex getSex();
    FowlBreed getBreed();
    PlumagePattern getPlumage();
    int getVitality();
    int getAgility();
    int getPower();
    int getFertility();
    int getTemperament();
}
