# EYRAX Real Roosters — 0.3.0-alpha.6

Visual-polish checkpoint v15, based on the Y-up/head-attachment v14 fixes.
Minecraft 1.21.1 · NeoForge 21.1.248 · Java 21 · Gradle 9.2.1.

## Dependencies and build

Both clients and the dedicated server need EYRAX Fowl API 1.0.0 and GeckoLib
4.9.2 (NeoForge / 1.21.1), plus the Real Roosters JAR.

Run `gradle build` with Java 21 and Gradle 9.2.1. Outputs:
- `build/libs/eyrax-fowl-api-1.0.0.jar`
- `build/libs/eyrax_real_roosters-0.3.0-alpha.6.jar`

The API is a separate source set/JAR, never shaded into the main mod.

## This visual pass

- Independent eye meshes with iris/pupil UVs, no painted eyes on the beak.
- Refined beak, symmetric thicker shanks and shorter front/rear toes.
- Preserved upright orientation and head-attached combs/crests.
- Separate 0.48-second visual attack controller, alongside locomotion.
- Dynamic breed/sex/age names, preserving names set by players.
- Bilingual read-only analyzer: breed, biological sex, life stage, plumage,
  five genetic scores (1–100), breed specialty and applicable combat stance.
- Analyzer wraps long descriptions, scrolls at small GUI resolutions, supports
  narration, a close button and Esc. Data is a snapshot taken at opening.

Preserved: eight breeds, six plumages, API, entity IDs, genes, attributes,
combat goals/damage, food and reproduction. No new gameplay systems.

## Checks and regeneration

```sh
python3 tools/validate_gecko_assets.py
python3 tools/validate_model_uv.py
python3 tools/validate_render_budget.py
python3 tools/validate_release_structure.py
python3 tools/validate_visual_polish.py
```

The 12 static regression tests include hashes of v14 gameplay files and methods.
Counts: 43 bones, 152 cubes, four animations, 29 physical 128x128 textures.
Per-visible-entity limits: rooster 69/70, hen 62/65, chick 27/30.

To regenerate this pass deterministically:
```sh
python3 tools/polish_visual_assets.py
python3 tools/generate_textures.py
```

These scripts operate on the corrected Y-up geometry. Do not rerun the legacy
orientation flip on an already converted model. Historical migration scripts
are retained for reference, not as the alpha.6 regeneration pipeline.

`render_static_breed_preview.py` makes structural QA views using median texture
colors; it does not replicate Minecraft rendering or certify animations.

## Controls and verification

Seeds retain their existing taming/breeding behavior. Right-click an animal
with the analyzer to open its record. Use the whistle on adult roosters for
Passive/Defend/Guard Owner. Sneak + empty hand orders a tamed bird to sit.

See INSTALLATION.txt for the manual ES/EN, GUI-scale, multiplayer and update
checklist. Compiling, dedicated-server startup, and actual client visual
approval are separate gates. This source checkpoint is not a certified release.
