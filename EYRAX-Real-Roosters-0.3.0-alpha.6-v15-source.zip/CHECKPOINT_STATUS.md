# EYRAX Real Roosters — checkpoint v15 / 0.3.0-alpha.6

Date: 2026-09-06
Base: recovered v14 / alpha.5, with Y-up orientation and head attachments preserved.

Implemented: independent eye meshes and UVs, isolated/reproportioned beak,
symmetric reinforced feet and rear toes, separate one-shot combat animation,
breed-aware entity names, bilingual read-only analyzer with responsive scrolling.

Local checks: 12 regression tests; all geometry, atlas, texture set, hierarchy,
render budget and release structure validators pass.
43 bones / 152 cubes / 4 animations / 29 physical 128x128 textures.
Visible maxima: rooster 69/70; hen 62/65; chick 27/30.

The v14 gameplay contract preserves all pre-existing entity methods except
animation-controller registration, plus the API, config, registries, whistle
and gameplay data. Added doHurtTarget delegates once to vanilla and returns
its result; the only extra effect is the server-triggered visual animation.

Validation boundary:
- Static previews are geometry/median-texture-color checks, not Minecraft captures.
- Java compilation and dedicated-server test await the GitHub Actions run.
- GitHub denied branch creation on 2026-09-06 with 403
  'Resource not accessible by integration'. No branch or workflow run was created.
  Repository write access must be enabled before compilation can continue there.
- In-game analyzer, camera angles, gait/attack transitions and modpack compatibility
  remain pending. No server installation has been performed.

This is a source checkpoint, not a certified release or a compiled JAR.
