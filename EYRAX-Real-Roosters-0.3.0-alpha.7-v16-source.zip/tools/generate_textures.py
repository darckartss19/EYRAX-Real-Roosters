#!/usr/bin/env python3
"""Generate the original EYRAX 128x128 breed/sex/plumage texture set."""

from __future__ import annotations

import colorsys
import hashlib
import random
from pathlib import Path

from PIL import Image, ImageDraw


ROOT = Path(__file__).resolve().parents[1]
TEXTURES = ROOT / "src/main/resources/assets/eyrax_real_roosters/textures/entity"
SCALE = 2
SIZE = 64 * SCALE

BREEDS = {
    "criollo_dominicano": ((132, 68, 34), (194, 120, 40), (30, 43, 34)),
    "rhode_island_red": ((126, 35, 25), (177, 64, 35), (42, 29, 26)),
    "leghorn": ((224, 219, 196), (247, 242, 218), (120, 114, 99)),
    "plymouth_rock": ((113, 116, 118), (188, 190, 187), (42, 45, 48)),
    "brahma": ((196, 185, 155), (226, 218, 191), (53, 50, 46)),
    "silkie": ((178, 181, 180), (221, 222, 216), (72, 77, 82)),
    "ayam_cemani": ((25, 29, 31), (43, 54, 51), (10, 13, 15)),
    "sussex": ((217, 207, 178), (241, 234, 207), (49, 47, 43)),
}
PATTERNS = ("pinto", "manilo", "giro", "cenizo", "jabao")
SEXES = ("rooster", "hen", "chick")

FEATHER_REGIONS = (
    (0, 10, 28, 37),   # head, neck and body maps
    (18, 18, 43, 37),  # saddle and breast maps
    (34, 16, 63, 37),  # wing maps
    (18, 38, 63, 63),  # tail and extra plumage maps
)


class ScaledDraw:
    """Draw in the established 64px UV coordinate space on a 128px canvas."""

    def __init__(self, draw: ImageDraw.ImageDraw) -> None:
        self.raw = draw

    @staticmethod
    def _coords(values: tuple[int, ...]) -> tuple[int, ...]:
        return tuple(value * SCALE for value in values)

    def rectangle(self, values: tuple[int, int, int, int], **kwargs: object) -> None:
        self.raw.rectangle(self._coords(values), **kwargs)

    def line(self, values: tuple[int, int, int, int], **kwargs: object) -> None:
        self.raw.line(self._coords(values), width=SCALE, **kwargs)

    def point(self, values: tuple[int, int], **kwargs: object) -> None:
        x, y = self._coords(values)
        self.raw.rectangle((x, y, x + SCALE - 1, y + SCALE - 1), **kwargs)


def mix(a: tuple[int, int, int], b: tuple[int, int, int], amount: float) -> tuple[int, int, int]:
    return tuple(round(x + (y - x) * amount) for x, y in zip(a, b))


def adjust(color: tuple[int, int, int], factor: float, saturation: float = 1.0) -> tuple[int, int, int]:
    r, g, b = (channel / 255 for channel in color)
    h, s, v = colorsys.rgb_to_hsv(r, g, b)
    r, g, b = colorsys.hsv_to_rgb(h, max(0.0, min(1.0, s * saturation)), max(0.0, min(1.0, v * factor)))
    return tuple(round(channel * 255) for channel in (r, g, b))


def feather_scales(draw: ScaledDraw, region: tuple[int, int, int, int],
                   base: tuple[int, int, int], rng: random.Random, density: int = 1) -> None:
    x0, y0, x1, y1 = region
    shadow = adjust(base, 0.72)
    light = adjust(base, 1.16, 0.88)
    for y in range(y0 + 2, y1, 4 * density):
        offset = 0 if ((y - y0) // (4 * density)) % 2 == 0 else 2
        for x in range(x0 + offset, x1, 5 * density):
            if rng.random() < 0.12:
                continue
            draw.line((x, y, x + 2, y + 1), fill=shadow)
            draw.point((x + 1, y), fill=light)


def apply_pattern(draw: ScaledDraw, pattern: str, regions: tuple[tuple[int, int, int, int], ...],
                  primary: tuple[int, int, int], accent: tuple[int, int, int],
                  dark: tuple[int, int, int], rng: random.Random) -> None:
    if pattern == "solid":
        return
    if pattern == "pinto":
        spot = adjust(accent, 1.08, 0.72)
        for x0, y0, x1, y1 in regions:
            for _ in range(max(3, (x1 - x0) * (y1 - y0) // 85)):
                x = rng.randint(x0, max(x0, x1 - 3))
                y = rng.randint(y0, max(y0, y1 - 3))
                w, h = rng.randint(2, 5), rng.randint(2, 4)
                draw.rectangle((x, y, min(x1, x + w), min(y1, y + h)), fill=spot)
    elif pattern == "manilo":
        gold = mix(accent, (210, 138, 47), 0.55)
        draw.rectangle((0, 10, 31, 25), fill=gold)
        draw.rectangle((18, 22, 35, 35), fill=adjust(gold, 0.90))
    elif pattern == "giro":
        copper = mix(primary, (185, 71, 31), 0.58)
        draw.rectangle((0, 10, 33, 30), fill=copper)
        draw.rectangle((24, 38, 63, 63), fill=adjust(dark, 0.80, 1.20))
    elif pattern == "cenizo":
        ash = mix(primary, (132, 139, 145), 0.68)
        for region in regions:
            draw.rectangle(region, fill=ash)
    elif pattern == "jabao":
        bar = adjust(dark, 0.88)
        for x0, y0, x1, y1 in regions:
            for y in range(y0 + 1, y1, 4):
                draw.rectangle((x0, y, x1, min(y1, y + 1)), fill=bar)


def create_texture(breed: str, sex: str) -> Image.Image:
    primary, accent, dark = BREEDS[breed]
    seed = int.from_bytes(hashlib.sha256(f"{breed}:{sex}".encode()).digest()[:8], "big")
    rng = random.Random(seed)

    if sex == "hen":
        primary = mix(primary, (137, 118, 94), 0.20)
        accent = mix(accent, primary, 0.35)
    elif sex == "chick":
        primary = mix(accent, (220, 185, 92), 0.35)
        accent = adjust(primary, 1.14, 0.76)
        dark = adjust(primary, 0.64)
    else:
        primary = adjust(primary, 1.02, 1.10)
        accent = adjust(accent, 1.08, 1.12)

    image = Image.new("RGBA", (SIZE, SIZE), (*primary, 255))
    physical_draw = ImageDraw.Draw(image)
    draw = ScaledDraw(physical_draw)

    # Separate mapped body groups to produce readable wings, breast and tails.
    draw.rectangle((0, 10, 33, 37), fill=primary)
    draw.rectangle((34, 16, 63, 37), fill=adjust(primary, 0.86))
    draw.rectangle((18, 22, 42, 37), fill=mix(primary, accent, 0.30))
    tail_color = dark if sex == "rooster" else mix(dark, primary, 0.42)
    draw.rectangle((18, 38, 63, 63), fill=tail_color)

    # Breed signatures remain visible even with inherited plumage patterns.
    if breed == "plymouth_rock":
        for y in range(10, 64, 4):
            draw.rectangle((0, y, 63, min(63, y + 1)), fill=adjust(dark, 1.18))
    elif breed == "sussex":
        draw.rectangle((0, 10, 27, 18), fill=dark)
        draw.rectangle((24, 38, 63, 63), fill=dark)
    elif breed == "brahma":
        draw.rectangle((34, 28, 63, 37), fill=mix(primary, dark, 0.52))
        draw.rectangle((18, 38, 63, 49), fill=mix(primary, dark, 0.62))
    elif breed == "ayam_cemani":
        iridescent = (28, 59, 54) if sex != "chick" else (35, 48, 46)
        draw.rectangle((34, 16, 63, 37), fill=iridescent)
        draw.rectangle((24, 38, 63, 63), fill=(16, 35, 34))
    elif breed == "leghorn":
        draw.rectangle((34, 16, 63, 37), fill=adjust(accent, 1.02, 0.45))

    for region in FEATHER_REGIONS:
        sample_x = min(63, region[0] + 2) * SCALE
        sample_y = min(63, region[1] + 2) * SCALE
        region_base = image.getpixel((sample_x, sample_y))[:3]
        feather_scales(draw, region, region_base, rng, 1 if sex != "chick" else 2)

    # Eyes and beak have their own reserved islands in alpha.6. No eye pixels
    # remain on the head's shared box UVs or on either mandible.
    beak = (216, 167, 55) if breed != "ayam_cemani" else (66, 70, 65)
    comb = (165, 30, 32) if breed != "ayam_cemani" else (47, 31, 38)
    draw.rectangle((28, 0, 47, 7), fill=comb)
    draw.rectangle((28, 8, 39, 9), fill=adjust(comb, 0.78))
    leg = (207, 161, 52)
    if breed in {"silkie", "ayam_cemani"}:
        leg = (47, 56, 58)
    elif breed == "brahma":
        leg = (181, 168, 125)
    draw.rectangle((0, 38, 16, 47), fill=leg)
    draw.rectangle((48, 0, 63, 7), fill=beak)
    draw.rectangle((48, 4, 63, 7), fill=adjust(beak, 0.83))
    # Native 8x8 eye face: iris, dark pupil, a single-pixel highlight.
    iris = (177, 99, 33) if breed != "ayam_cemani" else (113, 58, 35)
    physical_draw.rectangle((104, 20, 111, 27), fill=(38, 23, 19, 255))
    physical_draw.rectangle((105, 21, 110, 26), fill=(*iris, 255))
    physical_draw.rectangle((106, 22, 109, 25), fill=(10, 11, 13, 255))
    physical_draw.point((106, 22), fill=(247, 233, 196, 255))

    # Native 128px micro-feathers add information between the original UV pixels.
    # Their direction and contrast vary deterministically per individual texture.
    micro_count = 280 if sex != "chick" else 135
    for _ in range(micro_count):
        region = rng.choice(FEATHER_REGIONS)
        x = rng.randrange(region[0] * SCALE, min(SIZE, (region[2] + 1) * SCALE))
        y = rng.randrange(region[1] * SCALE, min(SIZE, (region[3] + 1) * SCALE))
        current = image.getpixel((x, y))[:3]
        highlight = adjust(current, rng.uniform(1.07, 1.16), 0.92)
        shadow = adjust(current, rng.uniform(0.72, 0.86), 1.04)
        length = rng.choice((2, 3, 4))
        physical_draw.line((x, y, min(SIZE - 1, x + length), min(SIZE - 1, y + 1)), fill=(*shadow, 255))
        physical_draw.point((x + 1 if x + 1 < SIZE else x, y), fill=(*highlight, 255))

    # Sparse edge glints make layered wing and tail feathers readable at gameplay distance.
    for region in FEATHER_REGIONS:
        x0, y0, x1, y1 = (value * SCALE for value in region)
        for y in range(y0 + 3, y1, 7):
            start = x0 + ((y // 7) % 2) * 3
            for x in range(start, x1, 9):
                current = image.getpixel((x, y))[:3]
                physical_draw.line((x, y, min(x1, x + 3), min(y1, y + 1)),
                                   fill=(*adjust(current, 1.12, 0.88), 255))
    return image


def create_overlay(pattern: str) -> Image.Image:
    """Create a reusable transparent genetics layer shared by every breed and sex."""
    image = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    physical = ImageDraw.Draw(image)
    draw = ScaledDraw(physical)
    rng = random.Random(int.from_bytes(hashlib.sha256(pattern.encode()).digest()[:8], "big"))

    if pattern == "pinto":
        for x0, y0, x1, y1 in FEATHER_REGIONS:
            for _ in range(max(6, (x1 - x0) * (y1 - y0) // 55)):
                x = rng.randint(x0, max(x0, x1 - 4))
                y = rng.randint(y0, max(y0, y1 - 4))
                w, h = rng.randint(2, 5), rng.randint(2, 4)
                draw.rectangle((x, y, min(x1, x + w), min(y1, y + h)), fill=(240, 226, 190, 205))
    elif pattern == "manilo":
        draw.rectangle((0, 10, 31, 25), fill=(205, 128, 39, 188))
        draw.rectangle((18, 22, 35, 35), fill=(158, 82, 28, 175))
    elif pattern == "giro":
        draw.rectangle((0, 10, 33, 30), fill=(174, 66, 28, 178))
        draw.rectangle((24, 38, 63, 63), fill=(16, 25, 24, 184))
    elif pattern == "cenizo":
        for region in FEATHER_REGIONS:
            draw.rectangle(region, fill=(135, 145, 154, 172))
    elif pattern == "jabao":
        for x0, y0, x1, y1 in FEATHER_REGIONS:
            for y in range(y0 + 1, y1, 4):
                draw.rectangle((x0, y, x1, min(y1, y + 1)), fill=(29, 32, 35, 205))

    # Feather-edge breakup prevents overlays from reading as flat painted rectangles.
    for x0, y0, x1, y1 in FEATHER_REGIONS:
        for _ in range(42):
            x = rng.randrange(x0 * SCALE, min(SIZE, (x1 + 1) * SCALE))
            y = rng.randrange(y0 * SCALE, min(SIZE, (y1 + 1) * SCALE))
            pixel = image.getpixel((x, y))
            if pixel[3] > 0:
                physical.line((x, y, min(SIZE - 1, x + rng.choice((2, 3))), y),
                              fill=(pixel[0], pixel[1], pixel[2], min(235, pixel[3] + 24)))
    return image


def main() -> None:
    # Write only the 29 known outputs; never delete unrelated texture assets.
    count = 0
    for sex in SEXES:
        directory = TEXTURES / sex
        directory.mkdir(parents=True, exist_ok=True)
        for breed in BREEDS:
            create_texture(breed, sex).save(directory / f"{breed}.png", optimize=True)
            count += 1

    overlay_directory = TEXTURES / "overlay"
    overlay_directory.mkdir(parents=True, exist_ok=True)
    for pattern in PATTERNS:
        create_overlay(pattern).save(overlay_directory / f"{pattern}.png", optimize=True)
        count += 1
    print(f"Generated {count} original EYRAX 128x128 textures (24 base + 5 overlays)")


if __name__ == "__main__":
    main()
