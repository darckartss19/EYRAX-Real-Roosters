#!/usr/bin/env python3
"""Idempotent alpha.6 geometry/animation pass over the corrected Y-up v14.

Only the mapped anatomical parts below are changed. Gameplay is not involved.
Run generate_textures.py after this script to regenerate the reserved UV islands.
"""
import copy
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'src/main/resources/assets/eyrax_real_roosters'
GEO = ASSETS / 'geo/heritage_chicken.geo.json'
ANIM = ASSETS / 'animations/heritage_chicken.animation.json'


def eye(origin):
    # Explicit face UVs avoid subpixel box-UV rounding on a very thin eye cube.
    return {'origin': origin, 'size': [0.20, 0.85, 0.85], 'uv': {
        face: {'uv': [52, 10], 'uv_size': [4, 4]}
        for face in ('north', 'south', 'east', 'west', 'up', 'down')
    }}


def mirror(cubes):
    out = copy.deepcopy(cubes)
    for cube in out:
        cube['origin'][0] = round(-cube['origin'][0] - cube['size'][0], 4)
        if 'pivot' in cube:
            cube['pivot'][0] *= -1
        if 'rotation' in cube:
            cube['rotation'][1] *= -1
            cube['rotation'][2] *= -1
        cube['mirror'] = True
    return out


def keys(*frames):
    return {str(t): values for t, values in frames}


def main():
    geo = json.loads(GEO.read_text())
    bones = geo['minecraft:geometry'][0]['bones']
    by_name = {b['name']: b for b in bones}
    assert by_name['root']['pivot'][1] == 0, 'Apply to Y-up v14, never legacy v12'

    for name, parent, cubes in (
        ('eyes', 'head', [eye([2.58, 20.25, -6.95]), eye([-2.78, 20.25, -6.95])]),
        ('chick_eyes', 'chick_head', [eye([2.32, 11.70, -4.95]), eye([-2.52, 11.70, -4.95])]),
    ):
        bone = by_name.get(name)
        if bone is None:
            bone = {'name': name}
            bones.append(bone)
        bone.update(parent=parent, pivot=by_name[parent]['pivot'][:], cubes=cubes)

    # Replace juvenile cheek blocks with eyes, retaining the same chick budget.
    head = by_name['chick_head']
    head['cubes'] = [c for c in head['cubes'] if c['size'] != [0.65, 2.4, 3.2]]
    by_name['beak']['cubes'] = [
        {'origin': [-1.50, 18.15, -10.55], 'size': [3.0, 1.35, 2.30], 'uv': [48, 0]},
        {'origin': [-1.15, 17.58, -10.02], 'size': [2.3, 0.70, 1.75], 'uv': [48, 4]},
    ]
    head['cubes'][1]['uv'] = [48, 0]

    # Full bilateral mirroring: thicker shanks, short splayed toes and a real
    # rear hallux. The v14 hallux rotated 180 degrees back into the front toes.
    left = [
        {'origin': [1.50, 1.25, -0.65], 'size': [1.40, 5.55, 1.35], 'uv': [0, 38],
         'pivot': [2.2, 5.0, 0], 'rotation': [-4, 0, 0]},
        {'origin': [1.72, 1.25, -2.55], 'size': [0.96, 0.72, 3.15], 'uv': [6, 38]},
        {'origin': [1.22, 1.25, -2.00], 'size': [0.76, 0.65, 2.45], 'uv': [6, 38],
         'pivot': [1.94, 1.6, 0.25], 'rotation': [0, 18, 0]},
        {'origin': [2.42, 1.25, -2.00], 'size': [0.76, 0.65, 2.45], 'uv': [6, 38],
         'pivot': [2.46, 1.6, 0.25], 'rotation': [0, -18, 0]},
        {'origin': [1.77, 1.25, 0.15], 'size': [0.86, 0.65, 1.55], 'uv': [10, 40]},
    ]
    by_name['leg_left']['cubes'] = left
    by_name['leg_right']['cubes'] = mirror(left)
    chick_left = [
        {'origin': [1.08, 1.20, -0.52], 'size': [1.04, 2.80, 1.04], 'uv': [0, 38]},
        {'origin': [0.96, 1.25, -1.48], 'size': [1.28, 0.62, 1.98], 'uv': [6, 38]},
        {'origin': [1.22, 1.25, 0.15], 'size': [0.76, 0.58, 1.08], 'uv': [10, 40]},
    ]
    by_name['chick_leg_left']['cubes'] = chick_left
    by_name['chick_leg_right']['cubes'] = mirror(chick_left)
    GEO.write_text(json.dumps(geo, indent=2, ensure_ascii=False) + '\n')

    animations = json.loads(ANIM.read_text())
    # Y-up keyframes. The combat controller owns these channels only while the
    # one-shot runs; the earlier locomotion controller continues on its clock.
    animations['animations']['animation.heritage_chicken.attack'] = {
        'loop': False, 'animation_length': 0.48, 'bones': {
            'body': {'rotation': keys((0, [0, 0, 0]), (.08, [8, 0, 0]), (.18, [-6, 0, 0]), (.48, [0, 0, 0]))},
            'neck': {
                'rotation': keys((0, [10, 0, 0]), (.06, [-12, 0, 0]), (.16, [34, 0, 0]), (.48, [10, 0, 0])),
                'position': keys((0, [0, 0, 0]), (.16, [0, 0, -1.0]), (.48, [0, 0, 0]))},
            'head': {'rotation': keys((0, [0, 0, 0]), (.06, [12, 0, 0]), (.16, [-28, 0, 0]), (.48, [0, 0, 0]))},
            'wing_left': {'rotation': keys((0, [0, 0, 5]), (.10, [0, 0, 42]), (.30, [0, 0, 18]), (.48, [0, 0, 5]))},
            'wing_right': {'rotation': keys((0, [0, 0, -5]), (.10, [0, 0, -42]), (.30, [0, 0, -18]), (.48, [0, 0, -5]))},
            'leg_left': {'rotation': keys((0, [0, 0, 0]), (.12, [-30, 0, 0]), (.28, [10, 0, 0]), (.48, [0, 0, 0]))},
            'leg_right': {'rotation': keys((0, [0, 0, 0]), (.12, [12, 0, 0]), (.28, [-22, 0, 0]), (.48, [0, 0, 0]))},
        },
    }
    ANIM.write_text(json.dumps(animations, indent=2, ensure_ascii=False) + '\n')
    print('Applied alpha.6 eye/beak/leg UV geometry and one-shot attack')


if __name__ == '__main__':
    main()
