package com.eyrax.visualqa;

import com.eyrax.fowlapi.api.FowlBreed;
import com.eyrax.fowlapi.api.FowlSex;
import com.eyrax.fowlapi.api.PlumagePattern;
import com.eyrax.realroosters.client.BreedAnalyzerScreen;
import com.eyrax.realroosters.entity.HeritageChicken;
import com.eyrax.realroosters.registry.ModEntities;
import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.gui.screens.Screen;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.ScreenEvent;
import net.neoforged.neoforge.common.NeoForge;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Runs only in the opt-in visualQa source set, never in a delivered EYRAX JAR. */
@Mod(value = "eyrax_visual_qa", dist = Dist.CLIENT)
public final class AnalyzerVisualQa {
    private static final String[] NAMES = {"00-alpha6-blurred", "01-alpha7-fixed",
            "02-alpha7-compact", "03-alpha7-compact-scrolled"};
    private HeritageChicken specimen;
    private Screen testedScreen;
    private int stage = -1, frames, backgroundPasses, readyTicks;
    private boolean advance, finished;

    public AnalyzerVisualQa() {
        NeoForge.EVENT_BUS.addListener(this::tick);
        NeoForge.EVENT_BUS.addListener(this::beforeRender);
        NeoForge.EVENT_BUS.addListener(this::backgroundRendered);
        NeoForge.EVENT_BUS.addListener(this::afterRender);
    }

    private void tick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (finished || mc.level == null || mc.player == null) return;
        if (stage < 0) {
            if (mc.screen != null || ++readyTicks < 40) return;
            specimen = new HeritageChicken(ModEntities.HERITAGE_CHICKEN.get(), mc.level);
            specimen.setBreed(FowlBreed.LEGHORN);
            specimen.setSex(FowlSex.ROOSTER);
            specimen.setPlumage(PlumagePattern.SOLID);
            specimen.setVitality(67);
            stage = 0;
            open(mc);
        } else if (advance) {
            advance = false;
            stage++;
            if (stage == NAMES.length) {
                finished = true;
                System.out.println("EYRAX_VISUAL_QA_SUCCESS: baseline=2 background passes; fixed=1; 4 screenshots");
                mc.stop();
            } else if (stage == 3) {
                if (!testedScreen.keyPressed(GLFW.GLFW_KEY_PAGE_DOWN, 0, 0)) {
                    throw new AssertionError("Compact analyzer did not handle Page Down");
                }
                frames = 0;
            } else {
                open(mc);
            }
        }
    }

    private void open(Minecraft mc) {
        mc.options.guiScale().set(stage < 2 ? 2 : 4);
        mc.resizeDisplay();
        testedScreen = stage == 0 ? new BlurredBaselineScreen(specimen) : new BreedAnalyzerScreen(specimen);
        mc.setScreen(testedScreen);
        frames = 0;
    }

    private void beforeRender(ScreenEvent.Render.Pre event) {
        if (event.getScreen() == testedScreen) backgroundPasses = 0;
    }

    @SuppressWarnings("removal")
    private void backgroundRendered(ScreenEvent.BackgroundRendered event) {
        if (event.getScreen() == testedScreen) backgroundPasses++;
    }

    private void afterRender(ScreenEvent.Render.Post event) {
        if (event.getScreen() != testedScreen || finished || advance || ++frames < 30) return;
        int expected = stage == 0 ? 2 : 1;
        if (backgroundPasses != expected) {
            throw new AssertionError("Stage " + stage + " expected " + expected
                    + " background passes, found " + backgroundPasses);
        }
        Minecraft mc = Minecraft.getInstance();
        Path directory = mc.gameDirectory.toPath().resolve("visual-qa");
        event.getGuiGraphics().flush();
        try (NativeImage image = Screenshot.takeScreenshot(mc.getMainRenderTarget())) {
            Files.createDirectories(directory);
            image.writeToFile(directory.resolve(NAMES[stage] + ".png"));
        } catch (IOException error) {
            throw new RuntimeException("Cannot save visual QA screenshot", error);
        }
        System.out.println("EYRAX_VISUAL_QA_STAGE " + NAMES[stage] + " backgroundPasses=" + backgroundPasses);
        advance = true;
    }
}
