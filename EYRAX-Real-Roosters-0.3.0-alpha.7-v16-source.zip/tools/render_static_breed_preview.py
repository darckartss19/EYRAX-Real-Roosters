#!/usr/bin/env python3
"""Render static QA sheets directly from the Gecko geometry and real textures.

This is deliberately not a replacement for an in-game test. It catches silhouette,
visibility, pivot and detached-part mistakes before a test JAR leaves development.
"""

from __future__ import annotations

import json
import math
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Patch
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
GEO = ROOT / "src/main/resources/assets/eyrax_real_roosters/geo/heritage_chicken.geo.json"
TEXTURES = ROOT / "src/main/resources/assets/eyrax_real_roosters/textures/entity"
OUTPUT = ROOT / "build/visual-qa"

BREEDS = [
    "criollo_dominicano", "leghorn", "ayam_cemani", "rhode_island_red",
    "plymouth_rock", "sussex", "brahma", "silkie",
]
DISPLAY = {
    "criollo_dominicano": "Criollo Dominicano", "leghorn": "Leghorn",
    "ayam_cemani": "Ayam Cemani", "rhode_island_red": "Rhode Island Red",
    "plymouth_rock": "Plymouth Rock", "sussex": "Sussex",
    "brahma": "Brahma", "silkie": "Silkie",
}
SCALES = {
    "criollo_dominicano": (.98, 1.06, .98), "rhode_island_red": (1.08, .99, 1.06),
    "leghorn": (.91, 1.08, .93), "plymouth_rock": (1.09, .98, 1.07),
    "brahma": (1.18, 1.13, 1.17), "silkie": (.96, .91, .99),
    "ayam_cemani": (.95, 1.06, .95), "sussex": (1.06, 1.0, 1.05),
}


def rotation_matrix(rotation):
    x, y, z = [math.radians(value) for value in rotation or (0, 0, 0)]
    rx = np.array([[1, 0, 0], [0, math.cos(x), -math.sin(x)], [0, math.sin(x), math.cos(x)]])
    ry = np.array([[math.cos(y), 0, math.sin(y)], [0, 1, 0], [-math.sin(y), 0, math.cos(y)]])
    rz = np.array([[math.cos(z), -math.sin(z), 0], [math.sin(z), math.cos(z), 0], [0, 0, 1]])
    return rz @ ry @ rx


def apply_pivot(points, pivot, rotation):
    pivot = np.asarray((0, 0, 0) if pivot is None else pivot, dtype=float)
    return (points - pivot) @ rotation_matrix(rotation).T + pivot


def cube_vertices(cube):
    origin = np.asarray(cube["origin"], dtype=float)
    size = np.asarray(cube["size"], dtype=float)
    inflate = float(cube.get("inflate", 0))
    low = origin - inflate
    high = origin + size + inflate
    vertices = np.array([
        [low[0], low[1], low[2]], [high[0], low[1], low[2]],
        [high[0], high[1], low[2]], [low[0], high[1], low[2]],
        [low[0], low[1], high[2]], [high[0], low[1], high[2]],
        [high[0], high[1], high[2]], [low[0], high[1], high[2]],
    ])
    return apply_pivot(vertices, cube.get("pivot", origin + size / 2), cube.get("rotation"))


FACES = ((0, 1, 2, 3), (4, 7, 6, 5), (0, 4, 5, 1),
         (3, 2, 6, 7), (1, 5, 6, 2), (0, 3, 7, 4))


def uv_color(image, cube):
    if isinstance(cube['uv'], dict):
        face = cube['uv']['east']
        u, v = face['uv']
        w, h = face['uv_size']
        crop = np.asarray(image.crop((u*2, v*2, (u+w)*2, (v+h)*2)))
        return np.median(crop[:, :, :3].reshape(-1, 3), axis=0) / 255
    u, v = cube["uv"]
    x, y, z = cube["size"]
    logical_w = max(1, math.ceil(2 * (x + z)))
    logical_h = max(1, math.ceil(y + z))
    scale_x = image.width / 64
    scale_y = image.height / 64
    crop = np.asarray(image.crop((
        int(u * scale_x), int(v * scale_y),
        min(image.width, int((u + logical_w) * scale_x)),
        min(image.height, int((v + logical_h) * scale_y)),
    )).convert("RGBA"), dtype=float)
    pixels = crop.reshape(-1, 4)
    pixels = pixels[pixels[:, 3] > 20]
    if not len(pixels):
        return np.array([.55, .45, .35])
    return np.median(pixels[:, :3], axis=0) / 255


def visible(name, breed, sex):
    if sex == "chick":
        return (name == "chick" or name.startswith("chick_")
                or name == f"{breed}_chick_details")
    if name == "chick" or name.startswith("chick_"):
        return False
    if name == "rooster_details":
        return sex == "rooster"
    if name == "hen_details":
        return sex == "hen"
    if name == "criollo_details":
        return sex == "rooster" and breed == "criollo_dominicano"
    if name == "silkie_head_details":
        return breed == "silkie"
    if name.endswith("_rooster_details"):
        return sex == "rooster" and name == f"{breed}_rooster_details"
    if name.endswith("_hen_details"):
        return sex == "hen" and name == f"{breed}_hen_details"
    if name.endswith("_details") and name not in {"rooster_details", "hen_details"}:
        return name == f"{breed}_details"
    if name == "comb_rooster":
        return sex == "rooster" and breed not in {"silkie", "leghorn", "brahma"}
    if name == "comb_hen":
        return sex == "hen" and breed not in {"silkie", "leghorn", "brahma"}
    if name == "tail_rooster":
        return sex == "rooster" and breed != "silkie"
    if name == "tail_hen":
        return sex == "hen" and breed != "silkie"
    if name == "wattles":
        return breed != "silkie"
    return name not in {"root"}


def render_one(ax, bones, by_name, breed, sex, *, view=(8, -35), title=True):
    texture = Image.open(TEXTURES / sex / f"{breed}.png")
    sx, sy, sz = SCALES[breed]
    rendered = []
    for bone in bones:
        if not visible(bone["name"], breed, sex):
            continue
        for cube in bone.get("cubes", []):
            points = cube_vertices(cube)
            current = bone
            while True:
                points = apply_pivot(points, current.get('pivot'), current.get('rotation'))
                if not current.get('parent'):
                    break
                current = by_name[current['parent']]
            points *= np.array([sx, sy, sz])
            # Bedrock/Gecko and this model use positive Y upward. Matplotlib's
            # 3D vertical axis is Z, so only reorder XYZ -> XZY.
            points = points[:, [0, 2, 1]]
            base = uv_color(texture, cube)
            rendered.append((points, base))
    # Sort faces together, not one opaque collection per cube: otherwise a
    # large head cube can incorrectly paint over a correctly external eye.
    polygons, face_colors = [], []
    for points, base in rendered:
        face_colors.extend(np.clip(base * shade, 0, 1) for shade in (0.82, 1.0, .72, .92, .78, .68))
        polygons.extend([[points[index] for index in face] for face in FACES])
    ax.add_collection3d(Poly3DCollection(polygons, facecolors=face_colors,
                                        edgecolors=(0.08, 0.08, 0.08, .55), linewidths=.18))
    all_points = np.concatenate([points for points, _ in rendered])
    low = all_points.min(axis=0)
    high = all_points.max(axis=0)
    center = (low + high) / 2
    extent = np.maximum(high - low, 1)
    radius = max(extent) * .62
    ax.set_xlim(center[0] - radius, center[0] + radius)
    ax.set_ylim(center[1] - radius, center[1] + radius)
    ax.set_zlim(center[2] - radius, center[2] + radius)
    ax.set_box_aspect((1, 1, 1))
    # Three-quarter view exposes breast, wing, both legs and tail attachment.
    # A near-perfect side view made valid geometry overlap and look detached.
    ax.view_init(elev=view[0], azim=view[1])
    ax.set_axis_off()
    if title:
        sex_name = {"rooster": "Gallo", "hen": "Gallina", "chick": "Pollito"}[sex]
        ax.set_title(f"{DISPLAY[breed]} · {sex_name}", fontsize=9, color="#f3e4bd")


def main():
    data = json.loads(GEO.read_text(encoding="utf-8"))
    bones = data["minecraft:geometry"][0]["bones"]
    by_name = {bone["name"]: bone for bone in bones}
    fig = plt.figure(figsize=(18, 15), facecolor="#151515")
    for index, breed in enumerate(BREEDS):
        row = index // 2
        breed_column = (index % 2) * 2
        for column, sex in enumerate(("rooster", "hen")):
            slot = row * 4 + breed_column + column + 1
            ax = fig.add_subplot(4, 4, slot, projection="3d", facecolor="#202020")
            render_one(ax, bones, by_name, breed, sex)
    fig.suptitle("EYRAX Real Roosters · revisión estática de siluetas", color="#f4c15d", fontsize=18)
    fig.legend(handles=[Patch(color="#444", label="Vista de QA; no sustituye la prueba dentro de Minecraft")],
               loc="lower center", frameon=False, labelcolor="#cccccc")
    OUTPUT.mkdir(parents=True, exist_ok=True)
    destination = OUTPUT / "adult-breed-silhouettes.png"
    fig.tight_layout(rect=(0, .025, 1, .975))
    fig.savefig(destination, dpi=180, facecolor=fig.get_facecolor())
    print(destination)

    focus = plt.figure(figsize=(14, 7), facecolor="#151515")
    views = ((7, 0), (8, -35), (8, 35), (7, 180))
    labels = ("perfil izquierdo", "tres cuartos izquierdo", "tres cuartos derecho", "perfil derecho")
    for index, (view, label) in enumerate(zip(views, labels, strict=True), start=1):
        ax = focus.add_subplot(1, 4, index, projection="3d", facecolor="#202020")
        render_one(ax, bones, by_name, "criollo_dominicano", "rooster", view=view, title=False)
        ax.set_title(label, fontsize=10, color="#f3e4bd")
    focus.suptitle("Criollo Dominicano · control anatómico", color="#f4c15d", fontsize=17)
    focus_destination = OUTPUT / "criollo-anatomy-views.png"
    focus.tight_layout(rect=(0, 0, 1, .95))
    focus.savefig(focus_destination, dpi=190, facecolor=focus.get_facecolor())
    print(focus_destination)

    chicks = plt.figure(figsize=(14, 7), facecolor="#151515")
    for index, breed in enumerate(BREEDS, start=1):
        ax = chicks.add_subplot(2, 4, index, projection="3d", facecolor="#202020")
        render_one(ax, bones, by_name, breed, "chick")
    chicks.suptitle("Pollitos · revisión por raza", color="#f4c15d", fontsize=17)
    chick_destination = OUTPUT / "chick-breed-silhouettes.png"
    chicks.tight_layout(rect=(0, 0, 1, .95))
    chicks.savefig(chick_destination, dpi=190, facecolor=chicks.get_facecolor())
    print(chick_destination)


if __name__ == "__main__":
    main()
