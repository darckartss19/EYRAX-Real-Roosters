# EYRAX Real Roosters — checkpoint v16 / 0.3.0-alpha.7

Base: compiled v15 / alpha.6, commit 0c8753db6379d5fde44cb5e8b26668274ea74f17.
The user approved the feet in v15 after testing in Minecraft.

Confirmed issue: Minecraft 1.21.1 Screen.render calls renderBackground.
Drawing the panel before calling super.render blurred its text and bars,
while the Close button was drawn after the second background pass.

Fix: draw the panel inside renderBackground, after the vanilla world blur.
Screen.render performs the one background pass and renders its widgets;
the analyzer render override only delegates and adds the name tooltip.

All v15 geometry, textures, animations, entity code and API are preserved.
43 bones / 152 cubes / 4 animations / 29 physical 128x128 textures.
Visible maxima: rooster 69/70; hen 62/65; chick 27/30.

Client verification is opt-in through tools/client_visual_qa.gradle and a
separate visualQa mod/source set. It uses a disposable Minecraft world,
checks real background pass counts, and captures the v15 baseline and v16
at normal/compact GUI scales with scrolling. QA classes are not packaged.

The source checkpoint precedes its CI run. Compilation, client screenshots
and server startup results are recorded in the resulting build artifacts.
Compatibility with the user's complete modpack still requires an in-game test.
