package com.eyrax.realroosters.client;

import com.eyrax.realroosters.entity.HeritageChicken;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.util.Mth;
import org.lwjgl.glfw.GLFW;

/** Read-only snapshot of already synchronized data. No inventory or server mutations. */
public final class BreedAnalyzerScreen extends Screen {
    private static final String PREFIX = "screen.eyrax_real_roosters.analyzer.";
    private static final String[] TRAITS = {"vitality", "agility", "power", "fertility", "temperament"};
    private static final int[] COLORS = {0xFFCF655C, 0xFF63B985, 0xFFE1A255, 0xFFD888BC, 0xFF8B9BD8};
    private static final int CREAM = 0xFFF2E8CF, MUTED = 0xFFB9AA8B, GOLD = 0xFFE2B84D;
    private final Component specimenName, breed, sex, age, plumage, specialty, stance;
    private final int[] stats;
    private int panelX, panelY, panelWidth, panelHeight, viewportTop, viewportBottom, contentHeight;
    private double scroll;

    public BreedAnalyzerScreen(HeritageChicken bird) {
        super(tr("title"));
        specimenName = bird.getName().copy();
        breed = Component.translatable("breed.eyrax_real_roosters." + bird.getBreed().serializedName());
        // Sex and age are separate: a chick still has a synchronized biological sex.
        sex = tr("sex." + bird.getSex().serializedName());
        age = tr("age." + (bird.isBaby() ? "chick" : "adult"));
        plumage = Component.translatable("plumage.eyrax_real_roosters." + bird.getPlumage().serializedName());
        specialty = Component.translatable("specialty.eyrax_real_roosters." + bird.getBreed().serializedName());
        stance = bird.isRooster() && !bird.isBaby()
                ? Component.translatable("stance.eyrax_real_roosters." + bird.getStance().serializedName())
                : tr("not_applicable");
        stats = new int[]{bird.getVitality(), bird.getAgility(), bird.getPower(),
                bird.getFertility(), bird.getTemperament()};
    }

    private static Component tr(String key) {
        return Component.translatable(PREFIX + key);
    }

    @Override
    protected void init() {
        panelWidth = Math.min(340, width - 16);
        panelHeight = Math.min(332, height - 16);
        panelX = (width - panelWidth) / 2;
        panelY = (height - panelHeight) / 2;
        viewportTop = panelY + 46;
        viewportBottom = panelY + panelHeight - 38;
        contentHeight = 4 * 15 + 12 + 5 * 25 + 18 + 14
                + font.split(specialty, contentWidth()).size() * 10 + 8;
        scroll = Mth.clamp(scroll, 0, maxScroll());
        addRenderableWidget(Button.builder(tr("close"), button -> onClose())
                .bounds(panelX + panelWidth - 98, panelY + panelHeight - 28, 84, 20).build());
    }

    private int contentWidth() {
        return Math.max(1, panelWidth - 40);
    }

    private int maxScroll() {
        return Math.max(0, contentHeight - (viewportBottom - viewportTop));
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        // Screen.render calls this before rendering its widgets in 1.21.1.
        // Draw the panel after the world blur, so no later blur pass can blur
        // the text/bars or leave the Close button as the only sharp element.
        super.renderBackground(g, mouseX, mouseY, partialTick);
        g.fill(panelX, panelY, panelX + panelWidth, panelY + panelHeight, 0xFF795C2E);
        g.fill(panelX + 2, panelY + 2, panelX + panelWidth - 2, panelY + panelHeight - 2, 0xF21B1712);
        g.drawCenteredString(font, title, width / 2, panelY + 10, GOLD);
        g.drawCenteredString(font, ellipsize(specimenName, panelWidth - 30), width / 2, panelY + 25, CREAM);
        g.fill(panelX + 10, viewportTop - 3, panelX + panelWidth - 10, viewportBottom + 2, 0xFF2A241C);

        int x = panelX + 16, y = viewportTop - (int) scroll;
        g.enableScissor(panelX + 12, viewportTop, panelX + panelWidth - 12, viewportBottom);
        field(g, x, y, "breed", breed);
        field(g, x, y + 15, "sex", sex);
        field(g, x, y + 30, "age", age);
        field(g, x, y + 45, "plumage", plumage);
        y += 72;
        for (int i = 0; i < stats.length; i++) {
            bar(g, x, y, TRAITS[i], stats[i], COLORS[i]);
            y += 25;
        }
        field(g, x, y, "stance", stance);
        y += 18;
        g.drawString(font, tr("specialty"), x, y, GOLD, false);
        y += 14;
        for (var line : font.split(specialty, contentWidth())) {
            g.drawString(font, line, x, y, CREAM, false);
            y += 10;
        }
        g.disableScissor();

        if (maxScroll() > 0) {
            int track = viewportBottom - viewportTop;
            int thumb = Math.max(12, track * track / contentHeight);
            int thumbY = viewportTop + (int) ((track - thumb) * scroll / maxScroll());
            int trackX = panelX + panelWidth - 16;
            g.fill(trackX, viewportTop, trackX + 3, viewportBottom, 0xFF493C28);
            g.fill(trackX, thumbY, trackX + 3, thumbY + thumb, GOLD);
        }
        g.drawString(font, ellipsize(tr("snapshot"), panelWidth - 122),
                panelX + 14, panelY + panelHeight - 23, MUTED, false);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        if (mouseY >= panelY + 24 && mouseY < panelY + 37
                && mouseX >= panelX && mouseX < panelX + panelWidth
                && font.width(specimenName) > panelWidth - 30) {
            g.renderTooltip(font, specimenName, mouseX, mouseY);
        }
    }

    private String ellipsize(Component component, int available) {
        String text = component.getString();
        return font.width(text) <= available ? text
                : font.plainSubstrByWidth(text, Math.max(0, available - font.width("…"))) + "…";
    }

    private void field(GuiGraphics g, int x, int y, String key, Component value) {
        Component label = tr(key);
        int labelWidth = Math.min(84, contentWidth() / 3);
        g.drawString(font, ellipsize(label, labelWidth), x, y, MUTED, false);
        g.drawString(font, ellipsize(value, contentWidth() - labelWidth - 6),
                x + labelWidth + 6, y, CREAM, false);
    }

    private void bar(GuiGraphics g, int x, int y, String key, int rawValue, int color) {
        int value = Mth.clamp(rawValue, 0, 100);
        String number = value + " / 100";
        // Label sits above the full-width bar, not underneath it.
        g.drawString(font, ellipsize(tr(key), contentWidth() - font.width(number) - 8), x, y, CREAM, false);
        g.drawString(font, number, x + contentWidth() - font.width(number), y, MUTED, false);
        g.fill(x, y + 12, x + contentWidth(), y + 18, 0xFF453B2E);
        g.fill(x, y + 12, x + Math.round(contentWidth() * value / 100.0F), y + 18, color);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
        if (mouseX >= panelX && mouseX < panelX + panelWidth
                && mouseY >= viewportTop && mouseY < viewportBottom && maxScroll() > 0) {
            scroll = Mth.clamp(scroll - vertical * 20, 0, maxScroll());
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontal, vertical);
    }

    @Override
    public boolean keyPressed(int key, int scanCode, int modifiers) {
        if (key == GLFW.GLFW_KEY_PAGE_DOWN || key == GLFW.GLFW_KEY_PAGE_UP) {
            int direction = key == GLFW.GLFW_KEY_PAGE_DOWN ? 1 : -1;
            scroll = Mth.clamp(scroll + direction * (viewportBottom - viewportTop - 10), 0, maxScroll());
            return true;
        }
        return super.keyPressed(key, scanCode, modifiers);
    }

    @Override
    public Component getNarrationMessage() {
        MutableComponent text = title.copy().append(". ").append(specimenName);
        text.append(". ").append(tr("sex")).append(" ").append(sex);
        text.append(". ").append(tr("age")).append(" ").append(age);
        text.append(". ").append(tr("plumage")).append(" ").append(plumage);
        for (int i = 0; i < stats.length; i++) {
            text.append(". ").append(tr(TRAITS[i])).append(" " + stats[i] + " / 100");
        }
        return text.append(". ").append(specialty).append(". ").append(stance);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
