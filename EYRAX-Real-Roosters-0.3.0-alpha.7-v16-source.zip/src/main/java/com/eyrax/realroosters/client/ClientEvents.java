package com.eyrax.realroosters.client;

import com.eyrax.realroosters.EyraxRealRoosters;
import com.eyrax.realroosters.registry.ModEntities;
import com.eyrax.realroosters.item.BreedAnalyzerItem;
import com.eyrax.realroosters.entity.HeritageChicken;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

@EventBusSubscriber(modid = EyraxRealRoosters.MOD_ID, value = Dist.CLIENT)
public final class ClientEvents {
    /** Kept registered while the native renderer remains available as a rollback path. */
    public static final ModelLayerLocation HERITAGE_CHICKEN_LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(EyraxRealRoosters.MOD_ID, "heritage_chicken"), "main");

    @SubscribeEvent
    public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(HERITAGE_CHICKEN_LAYER, HeritageChickenModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.HERITAGE_CHICKEN.get(), HeritageChickenGeoRenderer::new);
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void openAnalyzer(PlayerInteractEvent.EntityInteract event) {
        // Dist.CLIENT includes an integrated server. Never touch Minecraft on
        // that logical server thread or open a screen for a different player.
        if (!event.getLevel().isClientSide) return;
        Minecraft minecraft = Minecraft.getInstance();
        if (event.getEntity() != minecraft.player || minecraft.screen != null) return;
        if (event.getTarget() instanceof HeritageChicken chicken
                && chicken.isAlive()
                && event.getItemStack().getItem() instanceof BreedAnalyzerItem
                && !event.getEntity().isSpectator()) {
            minecraft.setScreen(new BreedAnalyzerScreen(chicken));
        }
    }

    private ClientEvents() {}
}
