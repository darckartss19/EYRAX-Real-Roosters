package com.eyrax.realroosters.item;

import com.eyrax.realroosters.entity.HeritageChicken;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public class BreedAnalyzerItem extends Item {
    public BreedAnalyzerItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (target instanceof HeritageChicken chicken) {
            return analyze(player, chicken);
        }
        return InteractionResult.PASS;
    }

    public InteractionResult analyze(Player player, HeritageChicken chicken) {
        // Client-only screen opening is handled by ClientEvents.
        return InteractionResult.sidedSuccess(player.level().isClientSide);
    }
}
