#!/usr/bin/env python3
"""Attach combs and breed-specific facial geometry to the animated head."""

from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
GEO = ROOT / "src/main/resources/assets/eyrax_real_roosters/geo/heritage_chicken.geo.json"


def main() -> None:
    geometry = json.loads(GEO.read_text(encoding="utf-8"))
    bones = geometry["minecraft:geometry"][0]["bones"]
    by_name = {bone["name"]: bone for bone in bones}

    for name in (
        "comb_rooster", "comb_hen", "brahma_rooster_details",
        "brahma_hen_details", "leghorn_rooster_details", "leghorn_hen_details",
    ):
        by_name[name]["parent"] = "head"

    silkie = by_name["silkie_details"]
    face_cubes = silkie["cubes"][:3]
    silkie["cubes"] = silkie["cubes"][3:]
    silkie_index = bones.index(silkie)
    bones.insert(silkie_index + 1, {
        "name": "silkie_head_details",
        "parent": "head",
        "pivot": [0, 11, 0],
        "cubes": face_cubes,
    })

    GEO.write_text(json.dumps(geometry, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
