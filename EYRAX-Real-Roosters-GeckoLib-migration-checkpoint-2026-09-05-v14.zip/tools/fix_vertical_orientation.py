#!/usr/bin/env python3
"""Convert the legacy Y-down bird assets to GeckoLib's Y-up coordinates."""

from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
GEO = ROOT / "src/main/resources/assets/eyrax_real_roosters/geo/heritage_chicken.geo.json"
ANIM = ROOT / "src/main/resources/assets/eyrax_real_roosters/animations/heritage_chicken.animation.json"
MODEL_HEIGHT = 24.0


def flip_rotation(value: list[float]) -> list[float]:
    """Conjugate a rotation by a reflection across the horizontal plane."""
    return [-value[0], value[1], -value[2]]


def flip_keyframes(value, transform):
    if isinstance(value, list):
        return transform(value)
    if isinstance(value, dict):
        return {time: transform(frame) for time, frame in value.items()}
    return value


def main() -> None:
    geometry = json.loads(GEO.read_text(encoding="utf-8"))
    bones = geometry["minecraft:geometry"][0]["bones"]
    for bone in bones:
        if "pivot" in bone:
            bone["pivot"][1] = MODEL_HEIGHT - bone["pivot"][1]
        if "rotation" in bone:
            bone["rotation"] = flip_rotation(bone["rotation"])
        for cube in bone.get("cubes", []):
            cube["origin"][1] = MODEL_HEIGHT - cube["origin"][1] - cube["size"][1]
            if "pivot" in cube:
                cube["pivot"][1] = MODEL_HEIGHT - cube["pivot"][1]
            if "rotation" in cube:
                cube["rotation"] = flip_rotation(cube["rotation"])
    GEO.write_text(json.dumps(geometry, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    animations = json.loads(ANIM.read_text(encoding="utf-8"))
    for animation in animations.get("animations", {}).values():
        for channel_set in animation.get("bones", {}).values():
            if "rotation" in channel_set:
                channel_set["rotation"] = flip_keyframes(channel_set["rotation"], flip_rotation)
            if "position" in channel_set:
                channel_set["position"] = flip_keyframes(
                    channel_set["position"], lambda value: [value[0], -value[1], value[2]]
                )
    ANIM.write_text(json.dumps(animations, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
