#!/usr/bin/env python3
"""Validate EYRAX GeckoLib geometry/animation references before packaging."""

from __future__ import annotations

import json
import re
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
GEO = ROOT / "src/main/resources/assets/eyrax_real_roosters/geo/heritage_chicken.geo.json"
ANIM = ROOT / "src/main/resources/assets/eyrax_real_roosters/animations/heritage_chicken.animation.json"
MODEL_JAVA = ROOT / "src/main/java/com/eyrax/realroosters/client/HeritageChickenGeoModel.java"
TEXTURES = ROOT / "src/main/resources/assets/eyrax_real_roosters/textures/entity"
BREEDS = {
    "criollo_dominicano", "rhode_island_red", "leghorn", "plymouth_rock",
    "brahma", "silkie", "ayam_cemani", "sussex",
}
SEXES = {"rooster", "hen", "chick"}
OVERLAYS = {"pinto", "manilo", "giro", "cenizo", "jabao"}

def main() -> None:
    geometry = json.loads(GEO.read_text(encoding="utf-8"))
    animations = json.loads(ANIM.read_text(encoding="utf-8"))
    definitions = geometry.get("minecraft:geometry", [])
    if len(definitions) != 1:
        raise SystemExit(f"Expected one geometry definition, found {len(definitions)}")
    definition = definitions[0]
    description = definition["description"]
    width = int(description["texture_width"])
    height = int(description["texture_height"])
    bones = definition.get("bones", [])
    names = [bone["name"] for bone in bones]
    if len(names) != len(set(names)):
        raise SystemExit("Duplicate bone names found")
    known = set(names)
    for bone in bones:
        parent = bone.get("parent")
        if parent is not None and parent not in known:
            raise SystemExit(f"Unknown parent {parent!r} for bone {bone['name']!r}")
        for cube in bone.get("cubes", []):
            uv = cube.get("uv")
            if not isinstance(uv, list) or len(uv) != 2:
                raise SystemExit(f"Invalid box UV in bone {bone['name']!r}: {uv!r}")
            if not (0 <= uv[0] < width and 0 <= uv[1] < height):
                raise SystemExit(f"UV origin outside {width}x{height} atlas in {bone['name']!r}: {uv}")
            size = cube.get("size")
            if not isinstance(size, list) or len(size) != 3:
                raise SystemExit(f"Invalid cube size in bone {bone['name']!r}: {size!r}")
            # Bedrock box UVs unwrap to two side/depth pairs horizontally and
            # one depth strip plus the cube height vertically.
            uv_width = 2 * (size[0] + size[2])
            uv_height = size[1] + size[2]
            if uv[0] + uv_width > width or uv[1] + uv_height > height:
                raise SystemExit(
                    f"Box UV footprint exceeds {width}x{height} atlas in {bone['name']!r}: "
                    f"origin={uv}, footprint={uv_width}x{uv_height}"
                )
    animation_count = 0
    for animation_name, animation in animations.get("animations", {}).items():
        animation_count += 1
        unknown = set(animation.get("bones", {})) - known
        if unknown:
            raise SystemExit(f"{animation_name} references unknown bones: {sorted(unknown)}")
    required = {
        "root", "adult", "chick", "rooster_details", "hen_details", "criollo_details",
        "brahma_details", "silkie_details", "leghorn_details", "ayam_cemani_details",
        "rhode_island_red_details", "plymouth_rock_details", "sussex_details",
        "brahma_rooster_details", "brahma_hen_details", "silkie_head_details",
        "leghorn_rooster_details", "leghorn_hen_details",
        "ayam_cemani_rooster_details", "brahma_chick_details", "silkie_chick_details",
    }
    missing = required - known
    if missing:
        raise SystemExit(f"Missing required bones: {sorted(missing)}")

    # GeckoLib entity geometry is Y-up: feet must remain below the body and
    # heads above it. This rejects the legacy Y-down export that rendered every
    # bird upside down in Minecraft while still looking plausible in static QA.
    def vertical_bounds(name: str) -> tuple[float, float]:
        bone = next(item for item in bones if item["name"] == name)
        values = [
            coordinate
            for cube in bone.get("cubes", [])
            for coordinate in (cube["origin"][1], cube["origin"][1] + cube["size"][1])
        ]
        if not values:
            raise SystemExit(f"Orientation sentinel bone has no cubes: {name}")
        return min(values), max(values)

    if vertical_bounds("head")[0] <= vertical_bounds("leg_left")[1]:
        raise SystemExit("Adult geometry is not Y-up: head must be above the legs")
    if vertical_bounds("chick_head")[0] <= vertical_bounds("chick_leg_left")[1]:
        raise SystemExit("Chick geometry is not Y-up: head must be above the legs")

    by_name = {bone["name"]: bone for bone in bones}
    head_attachments = {
        "comb_rooster", "comb_hen", "brahma_rooster_details",
        "brahma_hen_details", "leghorn_rooster_details", "leghorn_hen_details",
        "silkie_head_details",
    }
    detached = sorted(name for name in head_attachments if by_name[name].get("parent") != "head")
    if detached:
        raise SystemExit(f"Facial geometry is detached from the animated head: {detached}")

    java = MODEL_JAVA.read_text(encoding="utf-8")
    selected_bones = set(re.findall(r'setHidden\("([^"]+)"', java))
    unknown_selectors = selected_bones - known
    if unknown_selectors:
        raise SystemExit(f"Java selects unknown bones: {sorted(unknown_selectors)}")
    unselected_detail_groups = {name for name in known if name.endswith("_details")} - selected_bones
    if unselected_detail_groups:
        raise SystemExit(f"Detail bones never selected by Java: {sorted(unselected_detail_groups)}")

    expected_textures = {
        TEXTURES / sex / f"{breed}.png"
        for sex in SEXES for breed in BREEDS
    } | {TEXTURES / "overlay" / f"{overlay}.png" for overlay in OVERLAYS}
    actual_textures = set(TEXTURES.rglob("*.png"))
    if actual_textures != expected_textures:
        missing_textures = expected_textures - actual_textures
        extra_textures = actual_textures - expected_textures
        raise SystemExit(
            f"Texture set mismatch; missing={sorted(map(str, missing_textures))}, "
            f"extra={sorted(map(str, extra_textures))}"
        )
    for texture in sorted(actual_textures):
        with Image.open(texture) as image:
            if image.size != (128, 128):
                raise SystemExit(f"Texture is not 128x128: {texture} -> {image.size}")

    cube_count = sum(len(bone.get("cubes", [])) for bone in bones)
    print(
        f"Validated {len(bones)} bones, {cube_count} cubes, {animation_count} animations, "
        f"{len(actual_textures)} physical 128x128 textures and logical atlas {width}x{height}."
    )

if __name__ == "__main__":
    main()
