# EYRAX Real Roosters — visual migration checkpoint v14

Date: 2026-09-05

## Verified

- Corrected the legacy Y-down Gecko geometry to Y-up coordinates after the
  first in-game alpha.4 test revealed every bird rendering upside down.
- Adult and chick orientation sentinels now require heads above their legs.
- Generic, Brahma and Leghorn combs now inherit head and neck animation.
- Silkie crest and facial fluff now use a dedicated head-attached detail bone.

- The pre-HD Gecko migration compiled cleanly on Java 21 and NeoForge 21.1.248.
- EYRAX Fowl API 1.0.0 builds as an independent JAR/source set.
- EYRAX Real Roosters requires EYRAX Fowl API and GeckoLib 4.9.2.
- Dedicated development server loads all three modules and reaches `Done` on a new world.
- Main JAR contains no duplicated `com.eyrax.fowlapi` classes.
- Gecko geometry validates 40 unique bones, 150 cubes and three animations.
- Entity textures remain 29 shared assets: 24 breed/sex/age bases and five plumage overlays.
- Entity textures are physical 128x128 images using a logical 64x64 Gecko atlas.
- Shared anatomy now separates rooster and hen silhouettes: slimmer common torso,
  tapered neck/head, longer shanks, layered wings, hackles, saddle and hen belly.
- All eight breeds use thin silhouette detail groups instead of duplicate full-body boxes.
- Static QA renderer consumes the actual Gecko geometry and real breed textures.
- Static QA now converts Bedrock Y-up/down authoring coordinates correctly into
  Matplotlib's Z-up view; earlier sideways silhouette reports are obsolete.
- Rooster tails use paired rising/falling segments to form visible sickle arcs.
- Shared wings and flanks include thin layered feather plates.
- Criollo Dominicano no longer carries the obsolete duplicate body shell.
- All 29 textures were regenerated and confirmed as physical 128x128 PNGs.
- Leghorn, Brahma and Ayam Cemani now use sex-specific visual groups where required.
- Brahma uses a low pea comb; the Leghorn hen has a smaller leaning comb.
- Ayam Cemani hens no longer inherit male sickles or spurs.
- Chicks use layered bodies, cheeks, wings and juvenile tails instead of two large boxes.
- Brahma and Silkie chicks have distinct feathered feet/crest geometry.
- Static render budgets are enforced at 70 rooster, 65 hen and 30 chick cubes;
  current maximums are 67, 60 and 27 respectively.
- Silkie and Leghorn replace incompatible generic comb/tail parts at render time.
- Public Gradle repositories are now the default; the restricted localhost mirror is opt-in.
- GitHub Actions provisions Java 21 and Gradle 9.2.1 without relying on the absent wrapper JAR.
- Release validation now protects the stable entity ID, legacy egg, eight breed eggs,
  bilingual names, API separation and required API/GeckoLib metadata.
- The exact `0.3.0-alpha.4` source compiled successfully on GitHub Actions with
  Java 21 and Gradle 9.2.1; both generated JARs passed ZIP-integrity checks.
- Compiled output contains a separate 6.1 KB API JAR and 346 KB main mod JAR,
  with no duplicated `com.eyrax.fowlapi` classes in the main artifact.
- Empty `examplemod` and Minecraft placeholder resource directories were removed,
  and the release validator now rejects their return.
- Client event registration uses NeoForge's automatic event-bus selection,
  removing the deprecated explicit `Bus.MOD` annotation setting.

## Still pending before a public/test release

- Review and refine all eight breed silhouettes from real in-game captures.
- Client-side visual test: all breeds, sexes, chicks, overlays, animation transitions and spawn eggs.
- Save/reload, breeding and update-from-0.2.1 regression tests.
- Compatibility check with Critter Armory and the target modpack.
- Performance/entity-density tests at 25, 50 and 100 birds.

This checkpoint is source-only and is not a release candidate.
