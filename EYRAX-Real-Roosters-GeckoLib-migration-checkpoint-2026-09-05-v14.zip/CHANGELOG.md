# Changelog

## 0.3.0-alpha.5

- Corrected the complete GeckoLib geometry from legacy Y-down coordinates to
  Y-up coordinates so roosters, hens and chicks render upright in Minecraft.
- Converted bone pivots, cube pivots and rotations without changing anatomy,
  textures, breeds or gameplay.
- Converted animation rotations and vertical movement to preserve the intended
  idle, walking and airborne motion after the orientation correction.
- Added automated adult and chick orientation checks to prevent regression.
- Attached generic and breed-specific combs, crests and facial plumage to the
  animated head so they cannot remain floating during head movement.
- Added a hierarchy check that rejects detached facial geometry.

## 0.3.0-alpha.4

- Added physical 128×128 entity textures over the correct logical 64×64 model
  atlas, providing true 2× texture density without shrinking UV islands.
- Replaced 144 duplicated textures with 24 breed/sex bases and five shared plumage overlays.
- Added a translucent genetics render layer for Pinto, Manilo, Giro, Cenizo and Jabao.
- Preserved Solid plumage through the unmodified breed base.
- Added native micro-feather strokes and edge highlights instead of nearest-neighbor upscaling.
- Reduced future breed cost from eighteen textures to three.
- Preserved the alpha 3 animations and all gameplay behavior.

## 0.3.0-alpha.3

- Rebuilt adult wings with a tapered shoulder and four layered primary-feather lengths.
- Added a neck mantle to smooth the transition between head, neck and breast.
- Increased rooster sickle-feather curvature and segment separation.
- Added deterministic idle pecking so nearby birds do not animate in unison.
- Added occasional feather-shaking movement while resting.
- Added a synchronized challenge posture for aggressive adult roosters.
- Kept gameplay, genetics, feeding and reproduction unchanged.

## 0.3.0-alpha.2

- Added one color-coded spawn egg for each of the eight breeds.
- Breed eggs preserve random sex, plumage and genetics while guaranteeing the selected breed.
- Retained the old generic egg internally so existing worlds and inventories remain compatible.
- Reduced the adult head volume for a more natural body-to-head ratio.
- Added Silkie facial muffs, rooster tail coverts and rounded cushions for heavy hens.
- Extended Brahma and Silkie feathering over the toes.

## 0.3.0-alpha.1

- Split shared poultry contracts into the required EYRAX Fowl API 1.0.0 JAR.
- Added 144 original 64×64 entity textures.
- Added layered primary feathers and articulated toes.
- Added segmented curved rooster tails, hackles and saddle streamers.
- Added Leghorn and walnut combs, white earlobes, gamefowl cape, heavy keel and Sussex collar.
- Improved sex- and breed-specific posture, proportions and silhouette.
- Preserved the existing breeding, combat and genetics mechanics for focused visual testing.

## 0.2.2

- Fixed a `ClassCastException` during natural flock generation.
- Restored reliable creation and loading of worlds with natural spawning enabled.

## 0.2.1

- Natural flocks now spawn as a consistent breed.
- Natural sex distribution adjusted to 68% hens and 32% roosters.
- Breed Analyzer now describes each breed's practical specialty.
- Corrected the startup version reported in the log.

## 0.2.0

- Rebuilt the heritage chicken model with separate body, breast, saddle and neck volumes.
- Added a dedicated chick mesh instead of shrinking the adult model.
- Added articulated feet, split wattles, layered combs, spurs and multi-feather tails.
- Added distinct proportions and posture for all eight breeds.
- Added Brahma shoulders and leg feathering.
- Added Silkie crest, body fluff, leg feathering and pom tail.
- Added subtler idle head, wing and tail movement.

## 0.1.0

- Initial playable release.
- Added heritage chicken entity, breeds, plumage inheritance and genetic traits.
- Added sex-specific reproduction, egg laying and rooster combat behavior.
- Added analyzer, training whistle, recipes, natural spawning and bilingual text.
